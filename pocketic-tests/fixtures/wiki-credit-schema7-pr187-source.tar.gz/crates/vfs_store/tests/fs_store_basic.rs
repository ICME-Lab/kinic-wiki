mod common;

use common::{ensure_parent_folders, new_store, write_file};
use rusqlite::Connection;
use tempfile::tempdir;
use vfs_store::FsStore;
use vfs_types::{
    DeleteNodeRequest, ExportSnapshotRequest, FetchUpdatesRequest, ListChildrenRequest,
    ListNodesRequest, MkdirNodeRequest, MoveNodeRequest, MutateNodesBatchRequest, NodeEntryKind,
    NodeKind, NodeMutation, NodeMutationErrorCode, OutgoingLinksRequest, SearchNodePathsRequest,
    SearchNodesRequest, SearchPreviewField, SearchPreviewMode, WriteNodeItem, WriteNodeRequest,
    WriteNodesRequest,
};

fn assert_v5_snapshot_revision_without_state_hash(snapshot_revision: &str) {
    let parts = snapshot_revision.split(':').collect::<Vec<_>>();
    assert_eq!(parts.len(), 3);
    assert_eq!(parts[0], "v5");
    assert!(parts[1].parse::<i64>().expect("revision should parse") >= 0);
    assert!(!parts[2].is_empty());
}

#[test]
fn logical_size_bytes_rejects_missing_database_without_creating_file() {
    let dir = tempdir().expect("temp dir should exist");
    let database_path = dir.path().join("missing.sqlite3");
    let store = FsStore::new(database_path.clone());

    let error = store
        .logical_size_bytes()
        .expect_err("missing database should fail");

    assert!(!error.is_empty());
    assert!(!database_path.exists());
}

#[test]
fn source_capture_request_is_stored_as_opaque_vfs_content() {
    let (_dir, store) = new_store();
    let path = "/Sources/source-capture-requests/opaque.md";
    ensure_parent_folders(&store, path, 1);
    let content = "---\nkind: kinic.source_capture_request\noutput_language: klingon\n---\n";

    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: path.to_string(),
                kind: NodeKind::File,
                content: content.to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            2,
        )
        .expect("VFS must not interpret source capture output_language");

    let stored = store
        .read_node(path)
        .expect("node should load")
        .expect("node should exist");
    assert_eq!(stored.content, content);
}

#[test]
fn logical_size_bytes_uses_sqlite_page_size() {
    let (_dir, store) = new_store();
    let database_path = store.database_path().to_path_buf();
    let empty_size = store
        .logical_size_bytes()
        .expect("empty logical size should load");

    assert!(empty_size > 0);
    assert_eq!(
        empty_size,
        std::fs::metadata(&database_path)
            .expect("database file should exist")
            .len()
    );

    write_file(&store, "/Knowledge/size.md", None, 10);
    let written_size = store
        .logical_size_bytes()
        .expect("written logical size should load");

    assert!(written_size >= empty_size);
    assert_eq!(
        written_size,
        std::fs::metadata(database_path)
            .expect("database file should exist")
            .len()
    );
}

#[test]
fn fs_migrations_create_tables() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    let tables = [
        "fs_nodes",
        "fs_nodes_fts",
        "fs_change_log",
        "fs_path_state",
        "schema_migrations",
    ];
    for table in tables {
        let exists = conn
            .query_row(
                "SELECT 1 FROM sqlite_master WHERE name = ?1 LIMIT 1",
                [table],
                |row| row.get::<_, i64>(0),
            )
            .expect("table lookup should succeed");
        assert_eq!(exists, 1);
    }

    let fs_nodes_columns: Vec<(String, String, i64)> = conn
        .prepare("PRAGMA table_info(fs_nodes)")
        .expect("pragma should prepare")
        .query_map([], |row| Ok((row.get(1)?, row.get(2)?, row.get(5)?)))
        .expect("pragma should query")
        .collect::<Result<Vec<_>, _>>()
        .expect("pragma rows should collect");
    assert!(
        fs_nodes_columns.iter().any(|(name, ty, pk)| {
            name == "id" && ty.eq_ignore_ascii_case("INTEGER") && *pk == 1
        })
    );
    assert!(fs_nodes_columns.iter().any(|(name, _, _)| name == "path"));

    let fts_sql: String = conn
        .query_row(
            "SELECT sql FROM sqlite_master WHERE name = 'fs_nodes_fts'",
            [],
            |row| row.get(0),
        )
        .expect("fts sql lookup should succeed");
    assert!(fts_sql.contains("fts5(\n    path,"));
    assert!(fts_sql.contains("title,"));
    assert!(fts_sql.contains("content,"));
    assert!(fts_sql.contains("trigram"));

    let versions: Vec<String> = conn
        .prepare("SELECT version FROM schema_migrations ORDER BY version ASC")
        .expect("version query should prepare")
        .query_map([], |row| row.get(0))
        .expect("version query should run")
        .collect::<Result<Vec<_>, _>>()
        .expect("versions should collect");
    assert_eq!(
        versions,
        vec![
            "vfs_store:001_initial".to_string(),
            "vfs_store:002_publication_mutation_commits".to_string(),
            "vfs_store:003_fts_trigram".to_string(),
            "vfs_store:004_node_revisions".to_string(),
            "vfs_store:005_evidence_storage".to_string(),
        ]
    );

    {
        let table = "fs_links";
        let exists = conn
            .query_row(
                "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?1 LIMIT 1",
                [table],
                |row| row.get::<_, i64>(0),
            )
            .expect("snapshot table lookup should succeed");
        assert_eq!(exists, 1);
    }

    for index in [
        "fs_nodes_path_covering_idx",
        "fs_nodes_recent_covering_idx",
        "fs_links_target_path_idx",
        "fs_links_source_path_idx",
    ] {
        let exists = conn
            .query_row(
                "SELECT 1 FROM sqlite_master WHERE type = 'index' AND name = ?1 LIMIT 1",
                [index],
                |row| row.get::<_, i64>(0),
            )
            .expect("index lookup should succeed");
        assert_eq!(exists, 1);
    }
}

#[test]
fn current_fs_schema_missing_links_column_is_rejected() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_links;
         CREATE TABLE fs_links (
             source_path TEXT NOT NULL,
             target_path TEXT NOT NULL,
             raw_href TEXT NOT NULL,
             link_text TEXT NOT NULL,
             link_kind TEXT NOT NULL,
             PRIMARY KEY (source_path, target_path, raw_href)
         );
         CREATE INDEX fs_links_target_path_idx
             ON fs_links (target_path, source_path);
         CREATE INDEX fs_links_source_path_idx
             ON fs_links (source_path, target_path);",
    )
    .expect("malformed links table should create");
    drop(conn);

    let error = store
        .run_fs_migrations()
        .expect_err("missing links column should reject");

    assert!(error.contains("missing column fs_links.updated_at"));
}

#[test]
fn current_fs_schema_missing_change_log_column_is_rejected() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_change_log;
         CREATE TABLE fs_change_log (
             revision INTEGER PRIMARY KEY AUTOINCREMENT,
             path TEXT NOT NULL
         );",
    )
    .expect("malformed change log table should create");
    drop(conn);

    let error = store
        .run_fs_migrations()
        .expect_err("missing change log column should reject");

    assert!(error.contains("missing column fs_change_log.change_kind"));
}

#[test]
fn current_fs_schema_missing_path_state_column_is_rejected() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_path_state;
         CREATE TABLE fs_path_state (
             path TEXT PRIMARY KEY
         );",
    )
    .expect("malformed path state table should create");
    drop(conn);

    let error = store
        .run_fs_migrations()
        .expect_err("missing path state column should reject");

    assert!(error.contains("missing column fs_path_state.last_change_revision"));
}

#[test]
fn current_fs_schema_rejects_wrong_fts_column_order() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_nodes_fts;
         CREATE VIRTUAL TABLE fs_nodes_fts USING fts5(
             title,
             path,
             content
         );",
    )
    .expect("malformed fts table should create");
    drop(conn);

    let error = store
        .run_fs_migrations()
        .expect_err("wrong fts column order should reject");

    assert!(error.contains("invalid fs_nodes_fts shape"));
}

#[test]
fn current_fs_schema_rejects_extra_fts_column() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_nodes_fts;
         CREATE VIRTUAL TABLE fs_nodes_fts USING fts5(
             path,
             title,
             content,
             extra
         );",
    )
    .expect("malformed fts table should create");
    drop(conn);

    let error = store
        .run_fs_migrations()
        .expect_err("extra fts column should reject");

    assert!(error.contains("invalid fs_nodes_fts shape"));
}

#[test]
fn list_queries_use_covering_indexes() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/indexed.md", None, 10);
    let conn = Connection::open(store.database_path()).expect("db should open");

    let list_plan = explain_query_plan(
        &conn,
        "SELECT path, kind, updated_at, etag
         FROM fs_nodes
         WHERE path = ?1 OR path LIKE ?2 ESCAPE '\\'
         ORDER BY path ASC",
        ["/Knowledge", "/Knowledge/%"],
    );
    assert!(
        list_plan.contains("COVERING INDEX fs_nodes_path_covering_idx"),
        "list should avoid table lookups: {list_plan}"
    );
}

#[test]
fn list_children_queries_use_parent_indexes() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/indexed.md", None, 10);
    write_file(&store, "/Knowledge/nested/child.md", None, 11);
    let conn = Connection::open(store.database_path()).expect("db should open");
    let wiki_id = conn
        .query_row(
            "SELECT id FROM fs_nodes WHERE path = '/Knowledge'",
            [],
            |row| row.get::<_, i64>(0),
        )
        .expect("wiki id should exist");

    let folder_plan = explain_query_plan_dynamic(
        &conn,
        "SELECT child.path, child.kind, child.updated_at, child.etag, length(CAST(child.content AS BLOB))
         FROM fs_nodes child
         WHERE child.parent_id = ?1
         ORDER BY child.name ASC",
        &[&wiki_id as &dyn rusqlite::ToSql],
    );
    assert!(
        folder_plan.contains("USING INDEX fs_nodes_parent_name_idx")
            || folder_plan.contains("USING INDEX fs_nodes_parent_idx"),
        "folder child query should use parent index: {folder_plan}"
    );

    let root_plan = explain_query_plan_dynamic(
        &conn,
        "SELECT child.path, child.kind, child.updated_at, child.etag, length(CAST(child.content AS BLOB))
         FROM fs_nodes child
         WHERE child.parent_id IS NULL
         ORDER BY child.name ASC",
        &[],
    );
    assert!(
        root_plan.contains("USING INDEX fs_nodes_parent_name_idx")
            || root_plan.contains("USING INDEX fs_nodes_parent_idx"),
        "root child query should use parent index: {root_plan}"
    );
}

#[test]
fn folder_move_subtree_query_uses_path_range_scan() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/move/a.md", None, 10);
    write_file(&store, "/Knowledge/move/deep/b.md", None, 11);
    let conn = Connection::open(store.database_path()).expect("db should open");
    let prefix = "/Knowledge/move/".to_string();
    let upper = "/Knowledge/move/\u{10ffff}".to_string();

    let plan = explain_query_plan_dynamic(
        &conn,
        "SELECT path FROM fs_nodes
         WHERE path = ?1 OR (path >= ?2 AND path < ?3)
         ORDER BY length(path), path",
        &[&"/Knowledge/move" as &dyn rusqlite::ToSql, &prefix, &upper],
    );
    assert!(
        plan.contains("path>? AND path<?") || plan.contains("MULTI-INDEX OR"),
        "folder move subtree query should use path range scan: {plan}"
    );
}

#[test]
fn prefix_filters_escape_sql_like_wildcards() {
    assert_prefix_scope_with_wildcards(
        "/Knowledge/a_b",
        "/Knowledge/a_b/page.md",
        "/Knowledge/axb/page.md",
        100,
    );
    assert_prefix_scope_with_wildcards(
        "/Knowledge/a%b",
        "/Knowledge/a%b/page.md",
        "/Knowledge/azzzb/page.md",
        200,
    );
}

fn assert_prefix_scope_with_wildcards(
    prefix: &str,
    expected_path: &str,
    lookalike_path: &str,
    now_base: i64,
) {
    let (_dir, store) = new_store();
    let expected_etag = write_searchable_file(&store, expected_path, now_base);
    let lookalike_etag = write_searchable_file(&store, lookalike_path, now_base + 1);
    write_searchable_file(&store, "/Knowledge/a_b/other.md", now_base + 2);
    write_searchable_file(&store, "/Knowledge/a%b/other.md", now_base + 3);

    let list_paths = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: prefix.to_string(),
            recursive: true,
            limit: 100,
        })
        .expect("list should succeed")
        .into_iter()
        .map(|entry| entry.path)
        .collect::<Vec<_>>();
    assert!(list_paths.contains(&expected_path.to_string()));
    assert!(!list_paths.contains(&lookalike_path.to_string()));

    let search_paths = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "wildcard-token".to_string(),
            prefix: Some(prefix.to_string()),
            top_k: 100,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed")
        .into_iter()
        .map(|hit| hit.path)
        .collect::<Vec<_>>();
    assert!(search_paths.contains(&expected_path.to_string()));
    assert!(!search_paths.contains(&lookalike_path.to_string()));

    let path_search_paths = store
        .search_node_paths(SearchNodePathsRequest {
            database_id: "default".to_string(),
            query_text: "page".to_string(),
            prefix: Some(prefix.to_string()),
            top_k: 100,
            preview_mode: None,
        })
        .expect("path search should succeed")
        .into_iter()
        .map(|hit| hit.path)
        .collect::<Vec<_>>();
    assert!(path_search_paths.contains(&expected_path.to_string()));
    assert!(!path_search_paths.contains(&lookalike_path.to_string()));

    let snapshot = store
        .export_snapshot(ExportSnapshotRequest {
            database_id: "default".to_string(),
            prefix: Some(prefix.to_string()),
            limit: 100,
            cursor: None,
            snapshot_revision: None,
            snapshot_session_id: None,
        })
        .expect("snapshot should succeed");
    let snapshot_paths = snapshot
        .nodes
        .iter()
        .map(|node| node.path.clone())
        .collect::<Vec<_>>();
    assert!(snapshot_paths.contains(&expected_path.to_string()));
    assert!(!snapshot_paths.contains(&lookalike_path.to_string()));

    update_searchable_file(&store, expected_path, &expected_etag, now_base + 10);
    update_searchable_file(&store, lookalike_path, &lookalike_etag, now_base + 11);
    let updates = store
        .fetch_updates(FetchUpdatesRequest {
            database_id: "default".to_string(),
            known_snapshot_revision: snapshot.snapshot_revision,
            prefix: Some(prefix.to_string()),
            limit: 100,
            cursor: None,
            target_snapshot_revision: None,
        })
        .expect("updates should succeed");
    let update_paths = updates
        .changed_nodes
        .into_iter()
        .map(|node| node.path)
        .collect::<Vec<_>>();
    assert!(update_paths.contains(&expected_path.to_string()));
    assert!(!update_paths.contains(&lookalike_path.to_string()));
}

fn write_searchable_file(store: &FsStore, path: &str, now: i64) -> String {
    ensure_parent_folders(store, path, now - 1);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: path.to_string(),
                kind: NodeKind::File,
                content: "wildcard-token body".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            now,
        )
        .expect("write should succeed")
        .node
        .etag
}

fn update_searchable_file(store: &FsStore, path: &str, etag: &str, now: i64) {
    ensure_parent_folders(store, path, now - 1);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: path.to_string(),
                kind: NodeKind::File,
                content: format!("wildcard-token updated {now}"),
                metadata_json: "{}".to_string(),
                expected_etag: Some(etag.to_string()),
            },
            now,
        )
        .expect("update should succeed");
}

fn explain_query_plan(conn: &Connection, sql: &str, params: [&str; 2]) -> String {
    explain_query_plan_dynamic(conn, sql, &[&params[0] as &dyn rusqlite::ToSql, &params[1]])
}

fn explain_query_plan_dynamic(
    conn: &Connection,
    sql: &str,
    params: &[&dyn rusqlite::ToSql],
) -> String {
    conn.prepare(&format!("EXPLAIN QUERY PLAN {sql}"))
        .expect("explain should prepare")
        .query_map(params, |row| row.get::<_, String>(3))
        .expect("explain should run")
        .collect::<Result<Vec<_>, _>>()
        .expect("explain rows should collect")
        .join("\n")
}

#[test]
fn status_counts_live_files_and_sources() {
    let (_dir, store) = new_store();
    let file = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/file.md".to_string(),
                kind: NodeKind::File,
                content: "alpha".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("file write should succeed");
    ensure_parent_folders(&store, "/Sources/source/source.md", 10);
    let source = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Sources/source/source.md".to_string(),
                kind: NodeKind::Source,
                content: "source".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            11,
        )
        .expect("source write should succeed");
    store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/file.md".to_string(),
                expected_etag: Some(file.node.etag),
                expected_folder_index_etag: None,
            },
            12,
        )
        .expect("delete should succeed");

    let status = store.status().expect("status should succeed");
    assert_eq!(status.file_count, 0);
    assert_eq!(status.source_count, 1);
    assert_eq!(source.node.kind, NodeKind::Source);
}

#[test]
fn write_nodes_creates_files_and_sources_atomically() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Sources/source/source.md", 9);

    let results = store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".to_string(),
                nodes: vec![
                    WriteNodeItem {
                        path: "/Knowledge/batch-a.md".to_string(),
                        kind: NodeKind::File,
                        content: "alpha link [[batch-b]]".to_string(),
                        metadata_json: "{}".to_string(),
                        expected_etag: None,
                    },
                    WriteNodeItem {
                        path: "/Sources/source/source.md".to_string(),
                        kind: NodeKind::Source,
                        content: "source alpha".to_string(),
                        metadata_json: "{}".to_string(),
                        expected_etag: None,
                    },
                ],
            },
            10,
        )
        .expect("batch write should succeed");

    assert_eq!(results.len(), 2);
    assert!(results.iter().all(|result| result.created));
    assert!(
        store
            .read_node("/Knowledge/batch-a.md")
            .expect("read should succeed")
            .is_some()
    );
    assert!(
        store
            .read_node("/Sources/source/source.md")
            .expect("read should succeed")
            .is_some()
    );
}

#[test]
fn full_replacement_preserves_explicit_source_kind_and_metadata_across_write_apis() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Sources/preserved/source.md", 9);
    let metadata = r#"{"source_url":"https://example.com"}"#;
    let created = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Sources/preserved/source.md".to_string(),
                kind: NodeKind::Source,
                content: "one".to_string(),
                metadata_json: metadata.to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("source should create");
    let batch = store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".to_string(),
                nodes: vec![WriteNodeItem {
                    path: "/Sources/preserved/source.md".to_string(),
                    kind: NodeKind::Source,
                    content: "two".to_string(),
                    metadata_json: metadata.to_string(),
                    expected_etag: Some(created.node.etag),
                }],
            },
            11,
        )
        .expect("source should be replaced");
    let mutation = store
        .mutate_nodes_batch(
            MutateNodesBatchRequest {
                database_id: "default".to_string(),
                operations: vec![NodeMutation::Write(WriteNodeItem {
                    path: "/Sources/preserved/source.md".to_string(),
                    kind: NodeKind::Source,
                    content: "three".to_string(),
                    metadata_json: metadata.to_string(),
                    expected_etag: Some(batch[0].node.etag.clone()),
                })],
            },
            12,
        )
        .expect("batch mutation should replace source");

    assert_eq!(mutation.len(), 1);
    let node = store
        .read_node("/Sources/preserved/source.md")
        .expect("source should read")
        .expect("source should exist");
    assert_eq!(node.kind, NodeKind::Source);
    assert_eq!(node.metadata_json, metadata);
    assert_eq!(node.content, "three");
}

#[test]
fn mutation_errors_do_not_classify_expected_etag_from_a_missing_path() {
    let (_dir, store) = new_store();
    let error = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Memory/expected_etag.md".to_string(),
                kind: NodeKind::File,
                content: "missing".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: Some("stale".to_string()),
            },
            10,
        )
        .expect_err("a conditional write cannot create a missing node");

    assert_eq!(error.code, NodeMutationErrorCode::NotFound);
    assert_eq!(error.conflict_path, None);
}

#[test]
fn session_folder_batch_rolls_back_if_source_write_fails() {
    let (_dir, store) = new_store();
    let item = |path: &str, kind, expected_etag| WriteNodeItem {
        path: path.into(),
        kind,
        content: String::new(),
        metadata_json: "{}".into(),
        expected_etag,
    };
    let error = store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".into(),
                nodes: vec![
                    item("/Sources/batch-rollback-test", NodeKind::Folder, None),
                    item("/Sources/batch-rollback-test/codex", NodeKind::Folder, None),
                    item(
                        "/Sources/batch-rollback-test/codex/failed.md",
                        NodeKind::Source,
                        Some("stale".into()),
                    ),
                ],
            },
            10,
        )
        .unwrap_err();
    assert_eq!(error.failed_index, Some(2));
    assert!(
        store
            .read_node("/Sources/batch-rollback-test")
            .unwrap()
            .is_none()
    );
    assert!(
        store
            .read_node("/Sources/batch-rollback-test/codex")
            .unwrap()
            .is_none()
    );
    assert!(
        store
            .read_node("/Sources/batch-rollback-test/codex/failed.md")
            .unwrap()
            .is_none()
    );
}

#[test]
fn write_nodes_rolls_back_when_later_item_fails() {
    let (_dir, store) = new_store();
    let existing = write_file(&store, "/Knowledge/existing.md", None, 9);

    let error = store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".to_string(),
                nodes: vec![
                    WriteNodeItem {
                        path: "/Knowledge/new-before-error.md".to_string(),
                        kind: NodeKind::File,
                        content: "new content".to_string(),
                        metadata_json: "{}".to_string(),
                        expected_etag: None,
                    },
                    WriteNodeItem {
                        path: "/Knowledge/existing.md".to_string(),
                        kind: NodeKind::File,
                        content: "stale update".to_string(),
                        metadata_json: "{}".to_string(),
                        expected_etag: Some("stale".to_string()),
                    },
                ],
            },
            10,
        )
        .expect_err("stale item should fail");

    assert_eq!(error.failed_index, Some(1));
    assert!(error.message.contains("expected_etag"));
    assert!(
        store
            .read_node("/Knowledge/new-before-error.md")
            .expect("read should succeed")
            .is_none()
    );
    assert_eq!(
        store
            .read_node("/Knowledge/existing.md")
            .expect("read should succeed")
            .expect("existing node should remain")
            .etag,
        existing
    );
}

#[test]
fn write_nodes_creates_folder_items() {
    let (_dir, store) = new_store();

    let results = store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".to_string(),
                nodes: vec![
                    WriteNodeItem {
                        path: "/Knowledge/new-before-folder.md".to_string(),
                        kind: NodeKind::File,
                        content: "new content".to_string(),
                        metadata_json: "{}".to_string(),
                        expected_etag: None,
                    },
                    WriteNodeItem {
                        path: "/Knowledge/folder".to_string(),
                        kind: NodeKind::Folder,
                        content: String::new(),
                        metadata_json: "{}".to_string(),
                        expected_etag: None,
                    },
                ],
            },
            10,
        )
        .expect("folder item should create");

    assert_eq!(results.len(), 2);
    assert!(results[1].created);
    assert_eq!(results[1].node.path, "/Knowledge/folder");
    assert_eq!(results[1].node.kind, NodeKind::Folder);
    assert_eq!(
        store
            .read_node("/Knowledge/folder")
            .expect("read should succeed")
            .expect("folder should exist")
            .kind,
        NodeKind::Folder
    );
}

#[test]
fn write_node_creates_folder_idempotently() {
    let (_dir, store) = new_store();

    let created = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/write-node-folder".to_string(),
                kind: NodeKind::Folder,
                content: String::new(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("folder write should create");
    let replay = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/write-node-folder".to_string(),
                kind: NodeKind::Folder,
                content: String::new(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            11,
        )
        .expect("existing folder write should replay");

    assert!(created.created);
    assert_eq!(created.node.kind, NodeKind::Folder);
    assert!(!replay.created);
    assert_eq!(replay.node.path, "/Knowledge/write-node-folder");
}

#[test]
fn write_node_rejects_invalid_folder_requests() {
    let (_dir, store) = new_store();
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/existing.md".to_string(),
                kind: NodeKind::File,
                content: "file".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("file should create");

    let non_empty = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/non-empty-folder".to_string(),
                kind: NodeKind::Folder,
                content: "not empty".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            11,
        )
        .expect_err("folder content should reject");
    let metadata = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/metadata-folder".to_string(),
                kind: NodeKind::Folder,
                content: String::new(),
                metadata_json: r#"{"a":1}"#.to_string(),
                expected_etag: None,
            },
            12,
        )
        .expect_err("folder metadata should reject");
    let etag = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/etag-folder".to_string(),
                kind: NodeKind::Folder,
                content: String::new(),
                metadata_json: "{}".to_string(),
                expected_etag: Some("etag".to_string()),
            },
            13,
        )
        .expect_err("folder etag should reject");
    let collision = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/existing.md".to_string(),
                kind: NodeKind::Folder,
                content: String::new(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            14,
        )
        .expect_err("folder over file should reject");

    assert!(
        non_empty
            .message
            .contains("folder item content must be empty")
    );
    assert!(
        metadata
            .message
            .contains("folder item metadata_json must be empty object")
    );
    assert!(
        etag.message
            .contains("expected_etag must be None for folder item")
    );
    assert!(
        collision
            .message
            .contains("node already exists and is not a folder")
    );
}

#[test]
fn write_nodes_updates_search_and_links() {
    let (_dir, store) = new_store();

    store
        .write_nodes(
            WriteNodesRequest {
                database_id: "default".to_string(),
                nodes: vec![WriteNodeItem {
                    path: "/Knowledge/linking.md".to_string(),
                    kind: NodeKind::File,
                    content: "batch-token links to [[target]]".to_string(),
                    metadata_json: "{}".to_string(),
                    expected_etag: None,
                }],
            },
            10,
        )
        .expect("batch write should succeed");

    let hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "batch-token".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 10,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed");
    assert!(hits.iter().any(|hit| hit.path == "/Knowledge/linking.md"));
    let links = store
        .outgoing_links(OutgoingLinksRequest {
            database_id: "default".to_string(),
            path: "/Knowledge/linking.md".to_string(),
            limit: 10,
        })
        .expect("links should load");
    assert!(
        links
            .iter()
            .any(|link| link.target_path == "/Knowledge/target")
    );
}

#[test]
fn change_log_retains_all_recorded_revisions() {
    let (_dir, store) = new_store();
    for now in 10..=270 {
        let path = format!("/Knowledge/history-{now}.md");
        write_file(&store, &path, None, now);
    }

    let conn = Connection::open(store.database_path()).expect("db should open");
    let revision_count = conn
        .query_row("SELECT COUNT(*) FROM fs_change_log", [], |row| {
            row.get::<_, i64>(0)
        })
        .expect("count should succeed");
    let oldest_revision = conn
        .query_row("SELECT MIN(revision) FROM fs_change_log", [], |row| {
            row.get::<_, i64>(0)
        })
        .expect("min revision should succeed");
    let newest_revision = conn
        .query_row("SELECT MAX(revision) FROM fs_change_log", [], |row| {
            row.get::<_, i64>(0)
        })
        .expect("max revision should succeed");

    assert_eq!(revision_count, 269);
    assert_eq!(oldest_revision, 1);
    assert_eq!(newest_revision, 269);
}

#[test]
fn fs_path_state_tracks_latest_change_revision() {
    let (_dir, store) = new_store();
    let first = write_file(&store, "/Knowledge/file.md", None, 10);
    let second = write_file(&store, "/Knowledge/file.md", Some(&first), 11);
    store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/file.md".to_string(),
                expected_etag: Some(second),
                expected_folder_index_etag: None,
            },
            12,
        )
        .expect("delete should succeed");

    let conn = Connection::open(store.database_path()).expect("db should open");
    let revision = conn
        .query_row(
            "SELECT last_change_revision FROM fs_path_state WHERE path = '/Knowledge/file.md'",
            [],
            |row| row.get::<_, i64>(0),
        )
        .expect("path state should exist");
    assert_eq!(revision, 11);
}

#[test]
fn delete_folder_with_index_deletes_both_nodes() {
    let (_dir, store) = new_store();
    store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
            },
            10,
        )
        .expect("folder should create");
    let folder = store
        .read_node("/Knowledge/topic")
        .expect("folder should read")
        .expect("folder should exist");
    let index_etag = write_file(&store, "/Knowledge/topic/index.md", None, 11);

    store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
                expected_etag: Some(folder.etag),
                expected_folder_index_etag: Some(index_etag),
            },
            12,
        )
        .expect("folder delete should succeed");

    assert!(
        store
            .read_node("/Knowledge/topic")
            .expect("folder read should succeed")
            .is_none()
    );
    assert!(
        store
            .read_node("/Knowledge/topic/index.md")
            .expect("index read should succeed")
            .is_none()
    );
}

#[test]
fn delete_folder_with_index_and_visible_child_keeps_all_nodes() {
    let (_dir, store) = new_store();
    store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
            },
            10,
        )
        .expect("folder should create");
    let folder = store
        .read_node("/Knowledge/topic")
        .expect("folder should read")
        .expect("folder should exist");
    let index_etag = write_file(&store, "/Knowledge/topic/index.md", None, 11);
    write_file(&store, "/Knowledge/topic/child.md", None, 12);

    let error = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
                expected_etag: Some(folder.etag),
                expected_folder_index_etag: Some(index_etag),
            },
            13,
        )
        .expect_err("visible child should block folder delete");

    assert!(error.message.contains("folder is not empty"));
    for path in [
        "/Knowledge/topic",
        "/Knowledge/topic/index.md",
        "/Knowledge/topic/child.md",
    ] {
        assert!(
            store
                .read_node(path)
                .expect("node read should succeed")
                .is_some(),
            "{path} should remain"
        );
    }
}

#[test]
fn delete_folder_with_stale_index_etag_keeps_folder_and_index() {
    let (_dir, store) = new_store();
    store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
            },
            10,
        )
        .expect("folder should create");
    let folder = store
        .read_node("/Knowledge/topic")
        .expect("folder should read")
        .expect("folder should exist");
    write_file(&store, "/Knowledge/topic/index.md", None, 11);

    let error = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
                expected_etag: Some(folder.etag),
                expected_folder_index_etag: Some("stale".to_string()),
            },
            12,
        )
        .expect_err("stale index etag should fail");

    assert!(error.message.contains("expected_folder_index_etag"));
    assert_eq!(error.code, NodeMutationErrorCode::EtagConflict);
    assert_eq!(
        error.conflict_path.as_deref(),
        Some("/Knowledge/topic/index.md")
    );
    assert!(
        store
            .read_node("/Knowledge/topic")
            .expect("folder read should succeed")
            .is_some()
    );
    assert!(
        store
            .read_node("/Knowledge/topic/index.md")
            .expect("index read should succeed")
            .is_some()
    );
}

#[test]
fn delete_empty_folder_without_index_still_succeeds() {
    let (_dir, store) = new_store();
    store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
            },
            10,
        )
        .expect("folder should create");
    let folder = store
        .read_node("/Knowledge/topic")
        .expect("folder should read")
        .expect("folder should exist");

    store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
                expected_etag: Some(folder.etag),
                expected_folder_index_etag: None,
            },
            11,
        )
        .expect("empty folder delete should succeed");

    assert!(
        store
            .read_node("/Knowledge/topic")
            .expect("folder read should succeed")
            .is_none()
    );
}

#[test]
fn delete_file_rejects_folder_index_etag() {
    let (_dir, store) = new_store();
    let etag = write_file(&store, "/Knowledge/file.md", None, 10);

    let error = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/file.md".to_string(),
                expected_etag: Some(etag),
                expected_folder_index_etag: Some("index".to_string()),
            },
            11,
        )
        .expect_err("file delete should reject folder index etag");

    assert!(error.message.contains("expected_folder_index_etag"));
    assert!(
        store
            .read_node("/Knowledge/file.md")
            .expect("file read should succeed")
            .is_some()
    );
}

#[test]
fn fs_migrations_are_idempotent() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/alpha.md", None, 10);
    write_file(&store, "/Knowledge/beta.md", None, 11);

    store
        .run_fs_migrations()
        .expect("rerunning migrations should be a no-op");

    let conn = Connection::open(store.database_path()).expect("db should open");
    let versions = conn
        .prepare("SELECT version FROM schema_migrations ORDER BY version ASC")
        .expect("version query should prepare")
        .query_map([], |row| row.get::<_, String>(0))
        .expect("version query should run")
        .collect::<Result<Vec<_>, _>>()
        .expect("versions should collect");
    assert_eq!(
        versions,
        vec![
            "vfs_store:001_initial".to_string(),
            "vfs_store:002_publication_mutation_commits".to_string(),
            "vfs_store:003_fts_trigram".to_string(),
            "vfs_store:004_node_revisions".to_string(),
            "vfs_store:005_evidence_storage".to_string(),
        ]
    );

    let tracked_paths = conn
        .query_row("SELECT COUNT(*) FROM fs_path_state", [], |row| {
            row.get::<_, i64>(0)
        })
        .expect("path state count should succeed");
    assert_eq!(tracked_paths, 10);
}

#[test]
fn fs_migration_003_rebuilds_fts_with_trigram() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Knowledge/日本語/検索改善メモ.md", 1_799);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/日本語/検索改善メモ.md".to_string(),
                kind: NodeKind::File,
                content: "検索精度改善の作業メモ".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            1_800,
        )
        .expect("write should succeed");

    // Simulate the pre-003 state: the FTS index is the old unicode61 shape and
    // the 003 marker is absent, so the next migration run must rebuild it with
    // the trigram tokenizer and preserve searchable content.
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute_batch(
        "DROP TABLE fs_nodes_fts;
         CREATE VIRTUAL TABLE fs_nodes_fts USING fts5(path, title, content);
         INSERT INTO fs_nodes_fts(rowid, path, title, content)
            SELECT id, path, COALESCE(name, ''), content FROM fs_nodes;
         DELETE FROM schema_migrations WHERE version = 'vfs_store:003_fts_trigram';",
    )
    .expect("old schema setup should succeed");
    drop(conn);

    store
        .run_fs_migrations()
        .expect("003 fts trigram migration should apply");

    let conn = Connection::open(store.database_path()).expect("db should reopen");
    let versions: Vec<String> = conn
        .prepare("SELECT version FROM schema_migrations ORDER BY version ASC")
        .expect("version query should prepare")
        .query_map([], |row| row.get(0))
        .expect("version query should run")
        .collect::<Result<Vec<_>, _>>()
        .expect("versions should collect");
    assert_eq!(
        versions,
        vec![
            "vfs_store:001_initial".to_string(),
            "vfs_store:002_publication_mutation_commits".to_string(),
            "vfs_store:003_fts_trigram".to_string(),
            "vfs_store:004_node_revisions".to_string(),
            "vfs_store:005_evidence_storage".to_string(),
        ]
    );

    // "精度改善" is a 4-char substring of the node content. The unicode61
    // tokenizer treated the whole CJK run as one token and could not match it;
    // trigram matches substrings, so content search must work after migration.
    let hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "精度改善".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 5,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed");
    assert!(
        hits.iter()
            .any(|hit| hit.path == "/Knowledge/日本語/検索改善メモ.md"),
        "trigram migration should restore Japanese content substring search"
    );
}

#[test]
fn search_matches_short_ascii_terms_in_content_case_insensitively() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Knowledge/AI-agent-notes.md", 1_799);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/AI-agent-notes.md".to_string(),
                kind: NodeKind::File,
                content: "AI agent memory design notes".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            1_800,
        )
        .expect("write should succeed");

    for query in ["ai", "AI", "ai agent"] {
        let hits = store
            .search_nodes(SearchNodesRequest {
                database_id: "default".to_string(),
                query_text: query.to_string(),
                prefix: Some("/Knowledge".to_string()),
                top_k: 5,
                preview_mode: Some(SearchPreviewMode::None),
            })
            .expect("search should succeed");
        assert!(
            hits.iter()
                .any(|hit| hit.path == "/Knowledge/AI-agent-notes.md"),
            "query {query:?} should match content case-insensitively"
        );
    }

    let hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "ai".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 5,
            preview_mode: Some(SearchPreviewMode::Light),
        })
        .expect("search should succeed");
    let hit = hits
        .iter()
        .find(|hit| hit.path == "/Knowledge/AI-agent-notes.md")
        .expect("hit should exist");
    assert!(
        hit.match_reasons
            .iter()
            .any(|reason| reason == "content_substring"),
        "short ascii term should match via content substring fallback"
    );
}

#[test]
fn search_scores_are_negative_and_sorted_best_first() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Knowledge/score/note-00.md", 999);
    for index in 0..50 {
        let path = format!("/Knowledge/score/note-{index:02}.md");
        let content = if index == 0 {
            "needle appears exactly once here".to_string()
        } else if index % 5 == 0 {
            format!("needle repeated in note {index} to increase frequency")
        } else {
            format!("unrelated note body {index}")
        };
        store
            .write_node(
                WriteNodeRequest {
                    database_id: "default".to_string(),
                    path,
                    kind: NodeKind::File,
                    content,
                    metadata_json: "{}".to_string(),
                    expected_etag: None,
                },
                1_000 + index as i64,
            )
            .expect("write should succeed");
    }

    let hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "needle".to_string(),
            prefix: Some("/Knowledge/score".to_string()),
            top_k: 5,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed");
    assert!(!hits.is_empty());
    // Every canister hit score must be finite and negative. Consumers such as
    // the Wiki Clipper recall feature rank by this value and must not assume a
    // fixed magnitude floor, because bm25 magnitude shrinks as a term becomes
    // common in the store.
    for hit in &hits {
        assert!(
            hit.score.is_finite() && hit.score < 0.0,
            "score must be negative: {hit:?}"
        );
    }
    let mut sorted = hits.clone();
    sorted.sort_by(|left, right| left.score.total_cmp(&right.score));
    assert_eq!(
        hits, sorted,
        "search results should already be sorted by score"
    );
}

#[test]
fn fs_migrations_apply_publication_commit_marker_once() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute("DROP TABLE publication_mutation_commits", [])
        .expect("publication commit table should drop");
    conn.execute(
        "DELETE FROM schema_migrations WHERE version = ?1",
        ["vfs_store:002_publication_mutation_commits"],
    )
    .expect("publication commit migration marker should delete");
    drop(conn);

    store
        .run_fs_migrations()
        .expect("001 to 002 migration should apply");
    store
        .run_fs_migrations()
        .expect("002 migration should apply only once");

    let conn = Connection::open(store.database_path()).expect("db should reopen");
    let table_count = conn
        .query_row(
            "SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'publication_mutation_commits'",
            [],
            |row| row.get::<_, i64>(0),
        )
        .expect("publication commit table should exist");
    assert_eq!(table_count, 1);
    let marker_count = conn
        .query_row(
            "SELECT COUNT(*) FROM schema_migrations WHERE version = ?1",
            ["vfs_store:002_publication_mutation_commits"],
            |row| row.get::<_, i64>(0),
        )
        .expect("publication commit marker should exist");
    assert_eq!(marker_count, 1);
}

#[test]
fn write_node_creates_missing_store_root_on_current_schema() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute("DELETE FROM fs_nodes WHERE path = '/Knowledge'", [])
        .expect("knowledge root should delete");
    drop(conn);

    let written = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/lazy.md".to_string(),
                kind: NodeKind::File,
                content: "lazy root".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            40,
        )
        .expect("write should create missing store root");

    assert!(written.created);
    let root = store
        .read_node("/Knowledge")
        .expect("root should read")
        .expect("root should exist");
    assert_eq!(root.kind, NodeKind::Folder);
    let child = store
        .read_node("/Knowledge/lazy.md")
        .expect("child should read")
        .expect("child should exist");
    assert_eq!(child.kind, NodeKind::File);
}

#[test]
fn mkdir_node_creates_missing_skills_root_on_current_schema() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute("DELETE FROM fs_nodes WHERE path = '/Skills'", [])
        .expect("skills root should delete");
    drop(conn);

    let created = store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Skills/package".to_string(),
            },
            40,
        )
        .expect("mkdir should create missing store root");

    assert!(created.created);
    let root = store
        .read_node("/Skills")
        .expect("root should read")
        .expect("root should exist");
    assert_eq!(root.kind, NodeKind::Folder);
    let child = store
        .read_node("/Skills/package")
        .expect("child should read")
        .expect("child should exist");
    assert_eq!(child.kind, NodeKind::Folder);
}

#[test]
fn move_node_creates_missing_store_root_on_current_schema() {
    let (_dir, store) = new_store();
    let source_etag = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Memory/move-source.md".to_string(),
                kind: NodeKind::File,
                content: "move root".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            40,
        )
        .expect("source should write")
        .node
        .etag;
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute("DELETE FROM fs_nodes WHERE path = '/Knowledge'", [])
        .expect("knowledge root should delete");
    drop(conn);

    let moved = store
        .move_node(
            MoveNodeRequest {
                database_id: "default".to_string(),
                from_path: "/Memory/move-source.md".to_string(),
                to_path: "/Knowledge/moved.md".to_string(),
                expected_etag: Some(source_etag),
                expected_target_etag: None,
                overwrite: false,
            },
            41,
        )
        .expect("move should create missing store root");

    assert_eq!(moved.node.path, "/Knowledge/moved.md");
    let root = store
        .read_node("/Knowledge")
        .expect("root should read")
        .expect("root should exist");
    assert_eq!(root.kind, NodeKind::Folder);
}

#[test]
fn search_nodes_returns_error_for_invalid_stored_kind() {
    let (_dir, store) = new_store();
    let conn = Connection::open(store.database_path()).expect("db should open");
    conn.execute(
        "INSERT INTO fs_nodes (id, path, kind, content, created_at, updated_at, etag, metadata_json)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
        rusqlite::params![
            100_i64,
            "/Knowledge/broken.md",
            "broken",
            "searchable broken content",
            10_i64,
            10_i64,
            "etag-broken",
            "{}",
        ],
    )
    .expect("invalid kind row should insert");
    conn.execute(
        "INSERT INTO fs_nodes_fts (rowid, path, title, content) VALUES (?1, ?2, ?3, ?4)",
        rusqlite::params![
            100_i64,
            "/Knowledge/broken.md",
            "broken",
            "searchable broken content"
        ],
    )
    .expect("fts row should insert");

    let error = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "searchable".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 10,
            preview_mode: None,
        })
        .expect_err("invalid kind should return error");
    assert!(error.contains("Invalid column type"));
}

#[test]
fn fs_nodes_fts_stores_title_using_current_basename_rule() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Knowledge/nested/archive.tar.gz", 19);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/nested/archive.tar.gz".to_string(),
                kind: NodeKind::File,
                content: "payload".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            20,
        )
        .expect("write should succeed");
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/nested/.env".to_string(),
                kind: NodeKind::File,
                content: "payload".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            21,
        )
        .expect("write should succeed");
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/nested/trailing.".to_string(),
                kind: NodeKind::File,
                content: "payload".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            22,
        )
        .expect("write should succeed");

    let conn = Connection::open(store.database_path()).expect("db should open");
    let rows = conn
        .prepare("SELECT path, title FROM fs_nodes_fts ORDER BY path ASC")
        .expect("query should prepare")
        .query_map([], |row| {
            Ok((row.get::<_, String>(0)?, row.get::<_, String>(1)?))
        })
        .expect("query should run")
        .collect::<Result<Vec<_>, _>>()
        .expect("rows should collect");
    assert_eq!(
        rows,
        vec![
            ("/Knowledge/nested/.env".to_string(), ".env".to_string()),
            (
                "/Knowledge/nested/archive.tar.gz".to_string(),
                "archive.tar".to_string()
            ),
            (
                "/Knowledge/nested/trailing.".to_string(),
                "trailing.".to_string()
            ),
        ]
    );
}

#[test]
fn write_update_delete_and_recreate_follow_etag_rules() {
    let (_dir, store) = new_store();
    let first = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                kind: NodeKind::File,
                content: "alpha".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("first write should succeed");
    assert!(first.created);
    assert_eq!(
        store
            .read_node("/Knowledge/foo.md")
            .expect("read should succeed"),
        Some(vfs_types::Node {
            path: first.node.path.clone(),
            kind: first.node.kind.clone(),
            content: "alpha".to_string(),
            created_at: 10,
            updated_at: 10,
            etag: first.node.etag.clone(),
            metadata_json: "{}".to_string(),
        })
    );

    let stale_error = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                kind: NodeKind::File,
                content: "beta".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: Some("stale".to_string()),
            },
            11,
        )
        .expect_err("stale write should fail");
    assert!(stale_error.message.contains("expected_etag"));
    assert_eq!(stale_error.code, NodeMutationErrorCode::EtagConflict);
    assert_eq!(
        stale_error.conflict_path.as_deref(),
        Some("/Knowledge/foo.md")
    );

    let second = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                kind: NodeKind::File,
                content: "beta".to_string(),
                metadata_json: "{\"v\":2}".to_string(),
                expected_etag: Some(first.node.etag.clone()),
            },
            12,
        )
        .expect("update should succeed");
    assert!(!second.created);
    assert_ne!(first.node.etag, second.node.etag);
    let second_node = store
        .read_node("/Knowledge/foo.md")
        .expect("read should succeed")
        .expect("node should exist");
    assert_eq!(second_node.created_at, 10);

    let _deleted = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                expected_etag: Some(second.node.etag.clone()),
                expected_folder_index_etag: None,
            },
            13,
        )
        .expect("delete should succeed");
    let stale_delete = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                expected_etag: Some(second.node.etag),
                expected_folder_index_etag: None,
            },
            14,
        )
        .expect_err("stale delete should fail");
    assert!(stale_delete.message.contains("node does not exist"));
    assert!(
        store
            .read_node("/Knowledge/foo.md")
            .expect("read after delete should succeed")
            .is_none()
    );

    let recreated = store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/foo.md".to_string(),
                kind: NodeKind::File,
                content: "gamma".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            15,
        )
        .expect("recreate should succeed");
    let recreated_node = store
        .read_node("/Knowledge/foo.md")
        .expect("read should succeed")
        .expect("node should exist");
    assert_eq!(recreated_node.created_at, 15);
    assert_eq!(recreated.node.updated_at, 15);
}

#[test]
fn list_search_and_export_respect_deleted_and_prefix() {
    let (_dir, store) = new_store();
    let alpha = write_file(&store, "/Knowledge/alpha.md", None, 10);
    let beta = write_file(&store, "/Knowledge/nested/beta.md", None, 11);
    write_file(&store, "/Knowledge/tree/leaf.md", None, 12);
    write_file(&store, "/Knowledge/deleted/leaf.md", None, 13);
    let root_entries = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: false,
            limit: 100,
        })
        .expect("root list should succeed");
    assert_eq!(root_entries.len(), 4);
    assert!(
        root_entries
            .iter()
            .any(|entry| entry.path == "/Knowledge/alpha.md" && !entry.has_children)
    );
    assert!(root_entries.iter().any(|entry| {
        entry.path == "/Knowledge/nested"
            && entry.kind == NodeEntryKind::Folder
            && !entry.etag.is_empty()
            && entry.has_children
    }));
    assert!(root_entries.iter().any(|entry| {
        entry.path == "/Knowledge/deleted"
            && entry.kind == NodeEntryKind::Folder
            && !entry.etag.is_empty()
            && entry.has_children
    }));
    assert!(
        root_entries
            .iter()
            .any(|entry| entry.path == "/Knowledge/tree" && entry.has_children)
    );

    let nested_entries = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge/nested".to_string(),
            recursive: true,
            limit: 100,
        })
        .expect("nested list should succeed");
    assert_eq!(nested_entries.len(), 2);
    assert!(
        nested_entries
            .iter()
            .any(|entry| entry.path == "/Knowledge/nested" && entry.kind == NodeEntryKind::Folder)
    );
    assert!(nested_entries.iter().any(
        |entry| entry.path == "/Knowledge/nested/beta.md" && entry.kind == NodeEntryKind::File
    ));

    store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/alpha.md".to_string(),
                expected_etag: Some(alpha),
                expected_folder_index_etag: None,
            },
            12,
        )
        .expect("delete should succeed");
    let _deleted_leaf = store
        .delete_node(
            DeleteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/deleted/leaf.md".to_string(),
                expected_etag: Some(
                    store
                        .read_node("/Knowledge/deleted/leaf.md")
                        .expect("deleted leaf read should succeed")
                        .expect("deleted leaf should exist")
                        .etag,
                ),
                expected_folder_index_etag: None,
            },
            14,
        )
        .expect("deleted leaf delete should succeed");
    let visible_after_delete = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: true,
            limit: 100,
        })
        .expect("visible list should succeed");
    assert_eq!(visible_after_delete.len(), 6);
    assert!(
        visible_after_delete
            .iter()
            .any(|entry| entry.path == "/Knowledge/nested/beta.md")
    );
    assert!(
        visible_after_delete
            .iter()
            .any(|entry| entry.path == "/Knowledge/tree")
    );
    assert!(
        visible_after_delete
            .iter()
            .any(|entry| entry.path == "/Knowledge/tree/leaf.md")
    );

    let root_after_delete = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: false,
            limit: 100,
        })
        .expect("root list after delete should succeed");
    assert!(root_after_delete.iter().any(|entry| {
        entry.path == "/Knowledge/deleted"
            && entry.kind == NodeEntryKind::Folder
            && !entry.has_children
    }));

    let deleted_entries = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: true,
            limit: 100,
        })
        .expect("deleted list should succeed");
    assert_eq!(deleted_entries.len(), 6);

    let deleted_root_entries = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: false,
            limit: 100,
        })
        .expect("deleted root list should succeed");
    assert!(deleted_root_entries.iter().any(|entry| {
        entry.path == "/Knowledge/deleted"
            && entry.kind == NodeEntryKind::Folder
            && !entry.has_children
    }));

    let search_hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "nested".to_string(),
            prefix: Some("/Knowledge/nested".to_string()),
            top_k: 5,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed");
    let beta_search_hit = search_hits
        .iter()
        .find(|hit| hit.path == "/Knowledge/nested/beta.md")
        .expect("nested file search hit should exist");
    assert_eq!(
        beta_search_hit.snippet.as_deref(),
        Some("/Knowledge/nested/beta.md")
    );
    assert!(
        beta_search_hit
            .match_reasons
            .contains(&"path_substring".to_string())
    );

    let path_hits = store
        .search_node_paths(SearchNodePathsRequest {
            database_id: "default".to_string(),
            query_text: "NeStEd".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 5,
            preview_mode: None,
        })
        .expect("path search should succeed");
    let beta_path_hit = path_hits
        .iter()
        .find(|hit| hit.path == "/Knowledge/nested/beta.md")
        .expect("nested file path hit should exist");
    assert_eq!(
        beta_path_hit.snippet.as_deref(),
        Some("/Knowledge/nested/beta.md")
    );
    assert_eq!(
        beta_path_hit.match_reasons,
        vec!["path_substring".to_string()]
    );

    let missing_hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "alpha".to_string(),
            prefix: Some("/Knowledge".to_string()),
            top_k: 5,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("search should succeed");
    assert!(missing_hits.is_empty());

    let snapshot = store
        .export_snapshot(ExportSnapshotRequest {
            database_id: "default".to_string(),
            prefix: Some("/Knowledge".to_string()),
            limit: 100,
            cursor: None,
            snapshot_revision: None,
            snapshot_session_id: None,
        })
        .expect("snapshot should succeed");
    assert_eq!(snapshot.nodes.len(), 6);
    assert!(
        snapshot
            .nodes
            .iter()
            .any(|node| node.path == "/Knowledge/nested/beta.md")
    );
    assert_v5_snapshot_revision_without_state_hash(&snapshot.snapshot_revision);
    assert!(beta.starts_with("v4h:"));
}

#[test]
fn list_nodes_clamps_and_applies_limit() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/a.md", None, 10);
    write_file(&store, "/Knowledge/b.md", None, 11);
    write_file(&store, "/Knowledge/c/leaf.md", None, 12);

    let direct = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: false,
            limit: 2,
        })
        .expect("direct list should succeed");
    assert_eq!(
        direct
            .iter()
            .map(|entry| entry.path.as_str())
            .collect::<Vec<_>>(),
        vec!["/Knowledge/a.md", "/Knowledge/b.md"]
    );

    let recursive = store
        .list_nodes(ListNodesRequest {
            database_id: "default".to_string(),
            prefix: "/Knowledge".to_string(),
            recursive: true,
            limit: 0,
        })
        .expect("recursive list should succeed");
    assert_eq!(recursive.len(), 1);
    assert_eq!(recursive[0].path, "/Knowledge");
}

#[test]
fn list_children_returns_direct_children_with_folders() {
    let (_dir, store) = new_store();
    let alpha_etag = write_file(&store, "/Knowledge/alpha.md", None, 10);
    write_file(&store, "/Knowledge/zeta.md", None, 11);
    write_file(&store, "/Knowledge/nested/beta.md", None, 12);
    write_file(&store, "/Knowledge/aaa/gamma.md", None, 13);
    write_file(&store, "/Knowledge/tree/leaf.md", None, 14);

    let children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge/".to_string(),
        })
        .expect("children should list");
    let paths = children
        .iter()
        .map(|child| child.path.as_str())
        .collect::<Vec<_>>();
    assert_eq!(
        paths,
        vec![
            "/Knowledge/aaa",
            "/Knowledge/nested",
            "/Knowledge/tree",
            "/Knowledge/alpha.md",
            "/Knowledge/zeta.md"
        ]
    );

    let directory = children
        .iter()
        .find(|child| child.path == "/Knowledge/aaa")
        .expect("folder should exist");
    assert_eq!(directory.kind, NodeEntryKind::Folder);
    assert_eq!(directory.name, "aaa");
    assert!(directory.updated_at.is_some());
    assert!(directory.etag.is_some());
    assert_eq!(directory.size_bytes, Some(0));
    assert!(!directory.is_virtual);

    let alpha = children
        .iter()
        .find(|child| child.path == "/Knowledge/alpha.md")
        .expect("file child should exist");
    assert_eq!(alpha.kind, NodeEntryKind::File);
    assert_eq!(alpha.name, "alpha.md");
    assert_eq!(alpha.updated_at, Some(10));
    assert_eq!(alpha.etag.as_deref(), Some(alpha_etag.as_str()));
    assert_eq!(alpha.size_bytes, Some("content revision 10".len() as u64));
    assert!(!alpha.is_virtual);

    let tree = children
        .iter()
        .find(|child| child.path == "/Knowledge/tree")
        .expect("folder child with descendants should exist");
    assert_eq!(tree.kind, NodeEntryKind::Folder);
    assert_eq!(tree.name, "tree");
    assert!(tree.updated_at.is_some());
    assert!(tree.etag.is_some());
    assert_eq!(tree.size_bytes, Some(0));
    assert!(!tree.is_virtual);
    assert!(tree.has_children);

    let nested = children
        .iter()
        .find(|child| child.path == "/Knowledge/nested")
        .expect("folder child with descendants should exist");
    assert!(nested.has_children);

    assert!(
        !children
            .iter()
            .find(|child| child.path == "/Knowledge/alpha.md")
            .expect("leaf file child should exist")
            .has_children
    );

    let tree_children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge/tree".to_string(),
        })
        .expect("concrete node with descendants should list children");
    assert_eq!(
        tree_children
            .iter()
            .map(|child| child.path.as_str())
            .collect::<Vec<_>>(),
        vec!["/Knowledge/tree/leaf.md"]
    );
    assert!(!tree_children[0].has_children);
}

#[test]
fn list_children_excludes_folder_index_from_has_children() {
    let (_dir, store) = new_store();
    store
        .mkdir_node(
            MkdirNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/topic".to_string(),
            },
            10,
        )
        .expect("folder should create");
    write_file(&store, "/Knowledge/topic/index.md", None, 11);

    let children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge".to_string(),
        })
        .expect("children should list");
    let topic = children
        .iter()
        .find(|child| child.path == "/Knowledge/topic")
        .expect("topic folder should exist");
    assert_eq!(topic.kind, NodeEntryKind::Folder);
    assert!(!topic.has_children);
}

#[test]
fn list_children_reports_missing_directory_paths() {
    let (_dir, store) = new_store();

    let missing_error = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge/no-such-dir".to_string(),
        })
        .expect_err("missing directory should be rejected");
    assert_eq!(missing_error, "path not found: /Knowledge/no-such-dir");

    let root_children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/".to_string(),
        })
        .expect("root directory should list root folders");
    assert_eq!(
        root_children
            .iter()
            .map(|child| child.path.as_str())
            .collect::<Vec<_>>(),
        vec!["/Knowledge", "/Memory", "/Sessions", "/Skills", "/Sources"]
    );
    for path in ["/Memory", "/Sessions", "/Knowledge", "/Skills"] {
        let children = store
            .list_children(ListChildrenRequest {
                database_id: "default".to_string(),
                path: path.to_string(),
            })
            .expect("root-like directory should allow empty listing");
        assert!(children.is_empty());
    }
    let source_children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Sources".to_string(),
        })
        .expect("sources root should list source-kind roots");
    assert_eq!(
        source_children
            .iter()
            .map(|child| child.path.as_str())
            .collect::<Vec<_>>(),
        vec![
            "/Sources/sessions",
            "/Sources/skill-runs",
            "/Sources/source-capture-requests"
        ]
    );
}

#[test]
fn list_children_reports_utf8_content_size_in_bytes() {
    let (_dir, store) = new_store();
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Knowledge/japanese.md".to_string(),
                kind: NodeKind::File,
                content: "こんにちは".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            10,
        )
        .expect("write should succeed");

    let children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge".to_string(),
        })
        .expect("children should list");
    let child = children
        .iter()
        .find(|child| child.path == "/Knowledge/japanese.md")
        .expect("file child should exist");
    assert_eq!(child.size_bytes, Some("こんにちは".len() as u64));
}

#[test]
fn list_children_rejects_non_directory_paths() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/alpha.md", None, 10);

    let file_error = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge/alpha.md".to_string(),
        })
        .expect_err("file path should be rejected");
    assert_eq!(file_error, "not a directory: /Knowledge/alpha.md");

    let relative_error = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "Wiki".to_string(),
        })
        .expect_err("relative path should be rejected");
    assert_eq!(relative_error, "path must start with '/': Wiki");
}

#[test]
fn list_children_collapses_many_descendants_to_direct_entries() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/alpha.md", None, 10);
    for index in 0..300 {
        write_file(
            &store,
            &format!("/Knowledge/bulk-{}/leaf-{}.md", index % 3, index),
            None,
            20 + index,
        );
    }

    let children = store
        .list_children(ListChildrenRequest {
            database_id: "default".to_string(),
            path: "/Knowledge".to_string(),
        })
        .expect("children should list");
    let paths = children
        .iter()
        .map(|child| child.path.as_str())
        .collect::<Vec<_>>();
    assert_eq!(
        paths,
        vec![
            "/Knowledge/bulk-0",
            "/Knowledge/bulk-1",
            "/Knowledge/bulk-2",
            "/Knowledge/alpha.md"
        ]
    );
    assert_eq!(
        children
            .iter()
            .filter(|child| child.kind == NodeEntryKind::Folder)
            .count(),
        3
    );
}

#[test]
fn root_prefix_searches_all_nodes() {
    let (_dir, store) = new_store();
    write_file(&store, "/Knowledge/root-search.md", None, 10);
    write_file(&store, "/Other/root-search.md", None, 11);

    let search_hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "root-search".to_string(),
            prefix: Some("/".to_string()),
            top_k: 10,
            preview_mode: Some(SearchPreviewMode::None),
        })
        .expect("root search should succeed");
    let search_paths = search_hits
        .iter()
        .map(|hit| hit.path.as_str())
        .collect::<Vec<_>>();
    assert!(search_paths.contains(&"/Knowledge/root-search.md"));
    assert!(search_paths.contains(&"/Other/root-search.md"));

    let path_hits = store
        .search_node_paths(SearchNodePathsRequest {
            database_id: "default".to_string(),
            query_text: "root-search".to_string(),
            prefix: Some("/".to_string()),
            top_k: 10,
            preview_mode: None,
        })
        .expect("root path search should succeed");
    let path_search_paths = path_hits
        .iter()
        .map(|hit| hit.path.as_str())
        .collect::<Vec<_>>();
    assert!(path_search_paths.contains(&"/Knowledge/root-search.md"));
    assert!(path_search_paths.contains(&"/Other/root-search.md"));
}

#[test]
fn root_prefix_search_includes_source_nodes() {
    let (_dir, store) = new_store();
    ensure_parent_folders(&store, "/Sources/web/root-search-source.md", 19);
    store
        .write_node(
            WriteNodeRequest {
                database_id: "default".to_string(),
                path: "/Sources/web/root-search-source.md".to_string(),
                kind: NodeKind::Source,
                content: "source evidence includes needle-source-token".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            20,
        )
        .expect("source write should succeed");

    let search_hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "needle-source-token".to_string(),
            prefix: Some("/".to_string()),
            top_k: 10,
            preview_mode: Some(SearchPreviewMode::Light),
        })
        .expect("root search should include source nodes");
    let root_hit = search_hits
        .iter()
        .find(|hit| hit.path == "/Sources/web/root-search-source.md")
        .expect("root search should return the source content hit");
    assert_eq!(root_hit.kind, NodeKind::Source);
    let root_preview = root_hit
        .preview
        .as_ref()
        .expect("source content hit should include a light preview");
    assert_eq!(root_preview.field, SearchPreviewField::Content);
    assert_eq!(root_preview.match_reason, "content_fts");
    assert!(
        root_preview
            .excerpt
            .as_deref()
            .expect("source content preview should include excerpt")
            .contains("needle-source-token")
    );

    let source_hits = store
        .search_nodes(SearchNodesRequest {
            database_id: "default".to_string(),
            query_text: "needle-source-token".to_string(),
            prefix: Some("/Sources".to_string()),
            top_k: 10,
            preview_mode: Some(SearchPreviewMode::Light),
        })
        .expect("sources search should include source nodes");
    assert_eq!(source_hits.len(), 1);
    assert_eq!(source_hits[0].path, "/Sources/web/root-search-source.md");
    assert_eq!(source_hits[0].kind, NodeKind::Source);
    assert!(
        source_hits[0]
            .preview
            .as_ref()
            .and_then(|preview| preview.excerpt.as_deref())
            .is_some_and(|excerpt| excerpt.contains("needle-source-token"))
    );
}

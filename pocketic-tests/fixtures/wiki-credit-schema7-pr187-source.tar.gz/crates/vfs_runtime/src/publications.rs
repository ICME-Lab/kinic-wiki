// Where: crates/vfs_runtime/src/publications.rs
// What: Owner-controlled publication records and anonymous single-node reads.
// Why: Publishing one page must not grant database-wide read access.
use super::*;
use crate::sqlite::{Result as SqliteResult, Row};

const PUBLIC_NODE_ID_HEX_CHARS: usize = 32;

#[cfg(any(test, debug_assertions))]
static TEST_PUBLICATION_DETACH_FAIL_ONCE: LazyLock<Mutex<BTreeSet<String>>> =
    LazyLock::new(|| Mutex::new(BTreeSet::new()));
#[cfg(any(test, debug_assertions))]
static TEST_PUBLICATION_RESTORE_FAIL_ONCE: LazyLock<Mutex<BTreeSet<String>>> =
    LazyLock::new(|| Mutex::new(BTreeSet::new()));
#[cfg(any(test, debug_assertions))]
static TEST_PUBLICATION_RESOLUTION_FAIL_ONCE: LazyLock<Mutex<BTreeSet<String>>> =
    LazyLock::new(|| Mutex::new(BTreeSet::new()));

pub(crate) struct DetachedNodePublications {
    pub(crate) publications: Vec<NodePublication>,
    pub(crate) operation_id: Option<i64>,
}

#[cfg(any(test, debug_assertions))]
pub fn fail_next_publication_detach_for_test(database_id: &str) {
    TEST_PUBLICATION_DETACH_FAIL_ONCE
        .lock()
        .expect("test publication detach failure lock should not poison")
        .insert(database_id.to_string());
}

#[cfg(any(test, debug_assertions))]
pub fn fail_next_publication_restore_for_test(database_id: &str) {
    TEST_PUBLICATION_RESTORE_FAIL_ONCE
        .lock()
        .expect("test publication restore failure lock should not poison")
        .insert(database_id.to_string());
}

#[cfg(any(test, debug_assertions))]
pub fn fail_next_publication_resolution_for_test(database_id: &str) {
    TEST_PUBLICATION_RESOLUTION_FAIL_ONCE
        .lock()
        .expect("test publication resolution failure lock should not poison")
        .insert(database_id.to_string());
}

impl VfsService {
    pub(crate) fn member_visible_direct_node_publication_paths(
        &self,
        database_id: &str,
        caller: &str,
        parent_path: &str,
    ) -> Result<BTreeSet<String>, String> {
        self.recover_pending_publication_mutations()?;
        self.read_index(|conn| {
            if caller == ANONYMOUS_PRINCIPAL
                || load_member_role(conn, database_id, caller)?.is_none()
            {
                return Ok(BTreeSet::new());
            }
            let child_prefix = if parent_path == "/" {
                "/".to_string()
            } else {
                format!("{parent_path}/")
            };
            let mut stmt = conn
                .prepare(
                    "SELECT path
                     FROM node_publications
                     WHERE database_id = ?1
                       AND instr(path, ?2) = 1
                       AND instr(substr(path, length(?2) + 1), '/') = 0",
                )
                .map_err(|error| error.to_string())?;
            crate::sqlite::query_map(&mut stmt, params![database_id, child_prefix], |row| {
                crate::sqlite::row_get(row, 0)
            })
            .map(|paths| paths.into_iter().collect())
            .map_err(|error| error.to_string())
        })
    }

    pub fn publish_node(
        &self,
        caller: &str,
        request: PublishNodeRequest,
        public_id: &str,
        now: i64,
    ) -> Result<NodePublication, String> {
        self.recover_pending_publication_mutations()?;
        self.require_role(&request.database_id, caller, RequiredRole::Owner)?;
        self.require_maintenance_open(&request.database_id)?;
        validate_public_node_id(public_id)?;
        self.require_publishable_node(&request)?;

        self.write_index(|conn| {
            if let Some(publication) =
                load_node_publication(conn, &request.database_id, &request.path)?
            {
                return Ok(publication);
            }
            conn.execute(
                "INSERT INTO node_publications
                   (public_id, database_id, path, published_at_ms)
                 VALUES (?1, ?2, ?3, ?4)",
                params![public_id, request.database_id, request.path, now],
            )
            .map_err(|error| error.to_string())?;
            load_node_publication_by_id(conn, public_id)?
                .ok_or_else(|| "published node record was not persisted".to_string())
        })
    }

    pub fn unpublish_node(&self, caller: &str, request: PublishNodeRequest) -> Result<(), String> {
        self.recover_pending_publication_mutations()?;
        self.require_role(&request.database_id, caller, RequiredRole::Owner)?;
        self.require_maintenance_open(&request.database_id)?;
        self.require_publishable_node(&request)?;
        self.write_index(|conn| {
            conn.execute(
                "DELETE FROM node_publications
                 WHERE database_id = ?1 AND path = ?2",
                params![request.database_id, request.path],
            )
            .map(|_| ())
            .map_err(|error| error.to_string())
        })
    }

    pub fn get_node_publication(
        &self,
        caller: &str,
        request: PublishNodeRequest,
    ) -> Result<Option<NodePublication>, String> {
        self.recover_pending_publication_mutations()?;
        if caller == ANONYMOUS_PRINCIPAL {
            return Err("anonymous caller not allowed".to_string());
        }
        self.require_role(&request.database_id, caller, RequiredRole::Reader)?;
        self.read_index(|conn| load_node_publication(conn, &request.database_id, &request.path))
    }

    pub fn read_public_node(&self, public_id: &str) -> Result<Option<PublicNode>, String> {
        self.recover_pending_publication_mutations()?;
        validate_public_node_id(public_id)?;
        let publication =
            self.read_index(|conn| load_active_node_publication_by_id(conn, public_id))?;
        let Some(publication) = publication else {
            return Ok(None);
        };
        let meta = self.database_meta(&publication.database_id)?;
        let Some(node) = self.database_store(&meta)?.read_node(&publication.path)? else {
            return Ok(None);
        };
        if node.kind != NodeKind::File || !publication.path.ends_with(".md") {
            return Ok(None);
        }
        Ok(Some(PublicNode {
            content: node.content,
            updated_at: node.updated_at,
            published_at_ms: publication.published_at_ms,
        }))
    }

    fn require_publishable_node(&self, request: &PublishNodeRequest) -> Result<(), String> {
        let meta = self.database_meta(&request.database_id)?;
        let node = self
            .database_store(&meta)?
            .read_node(&request.path)?
            .ok_or_else(|| format!("node not found: {}", request.path))?;
        if node.kind != NodeKind::File || !request.path.ends_with(".md") {
            return Err("only Markdown file nodes can be published".to_string());
        }
        Ok(())
    }

    pub(crate) fn detach_node_publications_for_paths(
        &self,
        database_id: &str,
        paths: &[&str],
    ) -> Result<DetachedNodePublications, String> {
        #[cfg(any(test, debug_assertions))]
        if TEST_PUBLICATION_DETACH_FAIL_ONCE
            .lock()
            .map_err(|_| "test publication detach failure lock poisoned".to_string())?
            .remove(database_id)
        {
            return Err(format!(
                "injected publication detach failure: {database_id}"
            ));
        }

        self.write_index(|conn| {
            let mut detached = BTreeMap::<String, NodePublication>::new();
            for path in paths {
                let descendant_prefix = format!("{path}/");
                let mut stmt = conn
                    .prepare(
                        "SELECT public_id, database_id, path, published_at_ms
                         FROM node_publications
                         WHERE database_id = ?1
                           AND (path = ?2 OR instr(path, ?3) = 1)",
                    )
                    .map_err(|error| error.to_string())?;
                for publication in crate::sqlite::query_map(
                    &mut stmt,
                    params![database_id, *path, descendant_prefix],
                    publication_from_row,
                )
                .map_err(|error| error.to_string())?
                {
                    detached.insert(publication.public_id.clone(), publication);
                }
            }
            let publications = detached.into_values().collect::<Vec<_>>();
            #[cfg(not(target_arch = "wasm32"))]
            let operation_id = if publications.is_empty() {
                None
            } else {
                conn.execute(
                    "INSERT INTO publication_mutation_recovery_batches (database_id) VALUES (?1)",
                    params![database_id],
                )
                .map_err(|error| error.to_string())?;
                let operation_id =
                    crate::sqlite::last_insert_rowid(conn).map_err(|error| error.to_string())?;
                for publication in &publications {
                    conn.execute(
                        "INSERT INTO publication_mutation_recovery_items
                           (operation_id, public_id, database_id, path, published_at_ms)
                         VALUES (?1, ?2, ?3, ?4, ?5)",
                        params![
                            operation_id,
                            publication.public_id,
                            publication.database_id,
                            publication.path,
                            publication.published_at_ms
                        ],
                    )
                    .map_err(|error| error.to_string())?;
                }
                Some(operation_id)
            };
            #[cfg(target_arch = "wasm32")]
            let operation_id = None;
            for publication in &publications {
                conn.execute(
                    "DELETE FROM node_publications WHERE public_id = ?1",
                    params![publication.public_id.as_str()],
                )
                .map_err(|error| error.to_string())?;
            }
            Ok(DetachedNodePublications {
                publications,
                operation_id,
            })
        })
    }

    pub(crate) fn resolve_detached_node_publications(
        &self,
        detached: &DetachedNodePublications,
        restore: bool,
    ) -> Result<(), String> {
        #[cfg(any(test, debug_assertions))]
        if detached.publications.first().is_some_and(|publication| {
            TEST_PUBLICATION_RESOLUTION_FAIL_ONCE
                .lock()
                .expect("test publication resolution failure lock should not poison")
                .remove(&publication.database_id)
        }) {
            return Err("injected publication resolution failure".to_string());
        }
        #[cfg(any(test, debug_assertions))]
        if restore
            && detached.publications.first().is_some_and(|publication| {
                TEST_PUBLICATION_RESTORE_FAIL_ONCE
                    .lock()
                    .expect("test publication restore failure lock should not poison")
                    .remove(&publication.database_id)
            })
        {
            return Err("injected publication restore failure".to_string());
        }
        self.write_index(|conn| {
            if restore {
                insert_node_publications(conn, &detached.publications)?;
            }
            if let Some(operation_id) = detached.operation_id {
                delete_publication_mutation_recovery(conn, operation_id)?;
            }
            Ok(())
        })
    }

    pub fn recover_pending_publication_mutations(&self) -> Result<(), String> {
        #[cfg(target_arch = "wasm32")]
        {
            Ok(())
        }
        #[cfg(not(target_arch = "wasm32"))]
        {
            let pending = self.read_index(load_publication_mutation_recovery_batches)?;
            for (operation_id, database_id) in pending {
                let meta = self.database_meta(&database_id)?;
                let store = self.database_store(&meta)?;
                let committed = store.publication_mutation_committed(operation_id)?;
                let publications = self.read_index(|conn| {
                    load_publication_mutation_recovery_items(conn, operation_id)
                })?;
                let detached = DetachedNodePublications {
                    publications,
                    operation_id: Some(operation_id),
                };
                self.resolve_detached_node_publications(&detached, !committed)?;
                if committed {
                    let _ = store.clear_publication_mutation_commit(operation_id);
                }
            }
            Ok(())
        }
    }
}

fn insert_node_publications(
    conn: &Transaction<'_>,
    publications: &[NodePublication],
) -> Result<(), String> {
    for publication in publications {
        conn.execute(
            "INSERT INTO node_publications
               (public_id, database_id, path, published_at_ms)
             VALUES (?1, ?2, ?3, ?4)",
            params![
                publication.public_id,
                publication.database_id,
                publication.path,
                publication.published_at_ms
            ],
        )
        .map_err(|error| error.to_string())?;
    }
    Ok(())
}

fn delete_publication_mutation_recovery(
    conn: &Transaction<'_>,
    operation_id: i64,
) -> Result<(), String> {
    conn.execute(
        "DELETE FROM publication_mutation_recovery_items WHERE operation_id = ?1",
        params![operation_id],
    )
    .map_err(|error| error.to_string())?;
    conn.execute(
        "DELETE FROM publication_mutation_recovery_batches WHERE operation_id = ?1",
        params![operation_id],
    )
    .map(|_| ())
    .map_err(|error| error.to_string())
}

#[cfg(not(target_arch = "wasm32"))]
fn load_publication_mutation_recovery_batches(
    conn: &Connection,
) -> Result<Vec<(i64, String)>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT operation_id, database_id
             FROM publication_mutation_recovery_batches
             ORDER BY operation_id ASC",
        )
        .map_err(|error| error.to_string())?;
    crate::sqlite::query_map(&mut stmt, params![], |row| {
        Ok((
            crate::sqlite::row_get(row, 0)?,
            crate::sqlite::row_get(row, 1)?,
        ))
    })
    .map_err(|error| error.to_string())
}

#[cfg(not(target_arch = "wasm32"))]
fn load_publication_mutation_recovery_items(
    conn: &Connection,
    operation_id: i64,
) -> Result<Vec<NodePublication>, String> {
    let mut stmt = conn
        .prepare(
            "SELECT public_id, database_id, path, published_at_ms
             FROM publication_mutation_recovery_items
             WHERE operation_id = ?1
             ORDER BY public_id ASC",
        )
        .map_err(|error| error.to_string())?;
    crate::sqlite::query_map(&mut stmt, params![operation_id], publication_from_row)
        .map_err(|error| error.to_string())
}

fn load_node_publication(
    conn: &Connection,
    database_id: &str,
    path: &str,
) -> Result<Option<NodePublication>, String> {
    conn.query_row(
        "SELECT public_id, database_id, path, published_at_ms
         FROM node_publications
         WHERE database_id = ?1 AND path = ?2",
        params![database_id, path],
        publication_from_row,
    )
    .optional()
    .map_err(|error| error.to_string())
}

fn load_node_publication_by_id(
    conn: &Connection,
    public_id: &str,
) -> Result<Option<NodePublication>, String> {
    conn.query_row(
        "SELECT public_id, database_id, path, published_at_ms
         FROM node_publications
         WHERE public_id = ?1",
        params![public_id],
        publication_from_row,
    )
    .optional()
    .map_err(|error| error.to_string())
}

fn load_active_node_publication_by_id(
    conn: &Connection,
    public_id: &str,
) -> Result<Option<NodePublication>, String> {
    conn.query_row(
        "SELECT p.public_id, p.database_id, p.path, p.published_at_ms
         FROM node_publications p
         JOIN databases d ON d.database_id = p.database_id
         WHERE p.public_id = ?1 AND d.status = 'active'",
        params![public_id],
        publication_from_row,
    )
    .optional()
    .map_err(|error| error.to_string())
}

fn publication_from_row(row: &Row<'_>) -> SqliteResult<NodePublication> {
    Ok(NodePublication {
        public_id: crate::sqlite::row_get(row, 0)?,
        database_id: crate::sqlite::row_get(row, 1)?,
        path: crate::sqlite::row_get(row, 2)?,
        published_at_ms: crate::sqlite::row_get(row, 3)?,
    })
}

fn validate_public_node_id(public_id: &str) -> Result<(), String> {
    if public_id.len() != PUBLIC_NODE_ID_HEX_CHARS
        || !public_id
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit() && !byte.is_ascii_uppercase())
    {
        return Err("invalid public node id".to_string());
    }
    Ok(())
}

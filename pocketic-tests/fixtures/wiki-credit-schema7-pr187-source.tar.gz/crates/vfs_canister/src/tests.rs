// Where: crates/vfs_canister/src/tests.rs
// What: Entry-point level tests for the FS-first canister surface.
// Why: Phase 3 replaces the public canister contract, so tests must assert the wrapper behavior directly.
use std::future::Future;
use std::task::{Context, Poll, Waker};

use candid::{Encode, Nat, Principal};
use tempfile::tempdir;
use vfs_runtime::{
    DEFAULT_CYCLES_TOP_UP_LAUNCHER_PRINCIPAL, DEFAULT_CYCLES_TOP_UP_THRESHOLD,
    DEFAULT_LLM_WRITER_PRINCIPAL, VfsService,
};
use vfs_types::{
    AppendNodeRequest, CreateDatabaseRequest, CyclesBillingConfig, CyclesBillingConfigUpdate,
    CyclesTopUpConfig, DatabaseCyclesPurchaseRequest, DatabaseRole, DatabaseStatus,
    DeleteDatabaseRequest, DeleteNodeRequest, EditNodeRequest, ExportSnapshotRequest,
    FetchUpdatesRequest, GlobNodeType, GlobNodesRequest, GraphLinksRequest,
    GraphNeighborhoodRequest, IncomingLinksRequest, KINIC_LEDGER_FEE_E8S, ListChildrenRequest,
    ListNodesRequest, MarketCreateListingRequest, MarketListingStatus, MarketPurchaseRequest,
    MemoryManifestRequest, MkdirNodeRequest, MoveNodeRequest, MultiEdit, MultiEditNodeRequest,
    MutateNodesBatchRequest, NodeContextRequest, NodeEntryKind, NodeKind, NodeMutation,
    NodeMutationErrorCode, NodeMutationResult, OutgoingLinksRequest, PublishNodeRequest,
    QueryContextRequest, RenameDatabaseRequest, SearchNodePathsRequest, SearchNodesRequest,
    SearchPreviewMode, SourceEvidenceRequest, StorageBillingBatchRequest,
    UpdateDatabaseMetadataRequest, WriteNodeItem, WriteNodeRequest, WriteNodesRequest,
};

mod fs_entrypoints;
use super::{
    CyclesTopUpCheckStatus, CyclesTopUpLauncherError, CyclesTopUpLauncherResult,
    Icrc21ConsentMessage, Icrc21ConsentMessageMetadata, Icrc21ConsentMessageRequest,
    Icrc21ConsentMessageResponse, Icrc21ConsentMessageSpec, IcrcAccount, LedgerTransferFromOutcome,
    SERVICE, TransferFromError, append_node, check_cycles_top_up, check_database_write_cycles,
    clear_cycles_top_up_state_for_test, clear_last_ledger_memo_for_test,
    clear_ledger_transactions_for_test, create_database,
    cycles_top_up_launcher_call_count_for_test, delete_account, delete_node, edit_node,
    export_snapshot, fail_next_apply_database_cycles_purchase_apply_for_test,
    fail_next_mount_database_file_for_test, fetch_updates, get_cycles_billing_config,
    get_initial_free_database_grant_status, get_node_publication, glob_nodes,
    grant_database_access, graph_links, graph_neighborhood, icrc21_canister_call_consent_message,
    incoming_links, last_ledger_from_for_test, last_ledger_memo_for_test, last_ledger_to_for_test,
    ledger_transfer_fees_for_test, list_children, list_database_cycle_entries,
    list_database_cycles_pending_purchases, list_database_members, list_databases, list_nodes,
    mark_initial_free_database_grant_used_for_test, market_create_listing, market_get_listing,
    market_list_seller_listings, market_pause_listing, market_purchase_access, memory_manifest,
    mkdir_node, move_node, multi_edit_node, mutate_nodes_batch, outgoing_links,
    parse_upgrade_cycles_billing_config_arg, purchase_database_cycles, query_context,
    query_database_sql_json, query_index_sql_json, read_node, read_node_context, rename_database,
    revoke_database_access, search_node_paths, search_nodes, set_cycles_balance_for_test,
    set_cycles_top_up_in_progress_for_test, set_next_cycles_top_up_launcher_result_for_test,
    set_next_ledger_transfer_from_outcome_for_test, set_test_caller_principal_for_test,
    set_update_charge_units_for_test, settle_database_storage_charges_batch, source_evidence,
    status, transfer_from_error_outcome, update_charge_cycles, update_cycles_billing_config,
    update_database_metadata, wiki_metrics, wiki_metrics_series, write_node, write_nodes,
};

fn install_test_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    clear_ledger_transactions_for_test();
    service
        .create_database("default", "2vxsx-fae", 1_700_000_000_000)
        .expect("default database should create");
    service
        .begin_database_cycles_purchase("default", "2vxsx-fae", 1_000_000, 1_700_000_000_001)
        .and_then(|operation_id| {
            let cycles = cycles_for_test_payment(&service, 1_000_000);
            service.complete_database_cycles_purchase_ledger_transfer(
                operation_id,
                "default",
                "2vxsx-fae",
                cycles,
                1,
            )?;
            service.apply_database_cycles_purchase(
                operation_id,
                "default",
                "2vxsx-fae",
                cycles,
                1,
                1_700_000_000_001,
            )
        })
        .expect("default database should have write cycles available");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn delete_database_request(database_id: &str) -> DeleteDatabaseRequest {
    DeleteDatabaseRequest {
        database_id: database_id.to_string(),
    }
}

fn database_status_and_mount(database_id: &str) -> (DatabaseStatus, Option<u16>) {
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .list_database_infos()
            .expect("database infos should load")
            .into_iter()
            .find(|info| info.database_id == database_id)
            .map(|info| (info.status, info.mount_id))
            .expect("database info should exist")
    })
}

fn database_exists(database_id: &str) -> bool {
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .list_database_infos()
            .expect("database infos should load")
            .into_iter()
            .any(|info| info.database_id == database_id)
    })
}

fn pending_cycle_purchase_state(database_id: &str) -> String {
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .query_index_sql_json(
                &format!(
                    "SELECT json_object('status', operation_status, 'block', ledger_block_index) FROM database_cycle_pending_operations WHERE database_id = '{}' AND kind = 'cycles_purchase' LIMIT 1",
                    database_id
                ),
                1,
            )
            .expect("pending operation should query")
            .rows
            .into_iter()
            .next()
            .expect("pending operation should exist")
    })
}

fn pending_database_activation_state(database_id: &str) -> String {
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .query_index_sql_json(
                &format!(
                    "SELECT json_object('status', status, 'mount_id', mount_id, 'active_mount_id', active_mount_id, 'has_db_file_name', db_file_name <> '') FROM databases WHERE database_id = '{}' LIMIT 1",
                    database_id
                ),
                1,
            )
            .expect("database activation state should query")
            .rows
            .into_iter()
            .next()
            .expect("database row should exist")
    })
}

fn cycles_for_test_payment(service: &VfsService, payment_amount_e8s: u64) -> u64 {
    super::cycles_for_payment_amount_e8s(
        payment_amount_e8s,
        &service
            .cycles_billing_config()
            .expect("cycles config should load"),
    )
    .expect("cycles amount should compute")
}

fn install_empty_test_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    clear_ledger_transactions_for_test();
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn block_on_ready<T>(future: impl Future<Output = T>) -> T {
    let waker = Waker::noop();
    let mut context = Context::from_waker(waker);
    let mut future = std::pin::pin!(future);
    match future.as_mut().poll(&mut context) {
        Poll::Ready(value) => value,
        Poll::Pending => panic!("test future unexpectedly pending"),
    }
}

fn cycles_purchase_request(
    database_id: &str,
    payment_amount_e8s: u64,
) -> DatabaseCyclesPurchaseRequest {
    DatabaseCyclesPurchaseRequest {
        database_id: database_id.to_string(),
        payment_amount_e8s,
        min_expected_cycles: 1,
    }
}

fn market_listing_request(database_id: &str, price_e8s: u64) -> MarketCreateListingRequest {
    MarketCreateListingRequest {
        database_id: database_id.to_string(),
        payout_principal: Principal::management_canister().to_text(),
        price_e8s,
    }
}

fn market_purchase_request(
    listing_id: &str,
    price_e8s: u64,
    access_principal: Principal,
) -> MarketPurchaseRequest {
    MarketPurchaseRequest {
        listing_id: listing_id.to_string(),
        price_e8s,
        access_principal: access_principal.to_text(),
    }
}

fn consent_request(method: &str, arg: Vec<u8>) -> Icrc21ConsentMessageRequest {
    Icrc21ConsentMessageRequest {
        arg,
        method: method.to_string(),
        user_preferences: Icrc21ConsentMessageSpec {
            metadata: Icrc21ConsentMessageMetadata {
                language: "en".to_string(),
                utc_offset_minutes: None,
            },
            device_spec: None,
        },
    }
}

fn explicit_cycles_billing_config() -> CyclesBillingConfig {
    CyclesBillingConfig {
        kinic_ledger_canister_id: "aaaaa-aa".to_string(),
        billing_authority_id: "rrkah-fqaaa-aaaaa-aaaaq-cai".to_string(),
        iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
        cycles_per_kinic: 1_000,
        min_update_cycles: 1_000_000,
        top_up: test_cycles_top_up_config(true, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
    }
}

fn test_cycles_top_up_config(enabled: bool, threshold_cycles: u128) -> CyclesTopUpConfig {
    CyclesTopUpConfig {
        enabled,
        launcher_principal: DEFAULT_CYCLES_TOP_UP_LAUNCHER_PRINCIPAL.to_string(),
        threshold_cycles,
    }
}

#[test]
fn cycles_billing_config_rejects_anonymous_principals() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    let mut config = explicit_cycles_billing_config();
    config.billing_authority_id = Principal::anonymous().to_text();

    let error = service
        .run_index_migrations_with_config(config)
        .expect_err("anonymous billing authority should reject");

    assert!(error.contains("principal must not be anonymous"));
}

#[test]
fn controller_can_query_index_sql_json() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    let result = query_index_sql_json(
        "SELECT json_object('cycles_purchase_cycles', COALESCE(SUM(amount_cycles), 0)) FROM database_cycle_ledger WHERE kind = 'cycles_purchase' LIMIT 1".to_string(),
        10,
    )
    .expect("controller should query index SQL");

    assert_eq!(result.limit, 10);
    assert_eq!(result.row_count, 1);
    assert_eq!(
        result.rows,
        vec![r#"{"cycles_purchase_cycles":2345000000}"#.to_string()]
    );
}

#[test]
fn non_controller_can_query_public_wiki_metrics() {
    install_empty_test_service();
    let non_controller = Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("valid non-controller principal");
    set_test_caller_principal_for_test(non_controller);

    let metrics = wiki_metrics().expect("public metrics should not require controller");

    assert_eq!(metrics.users_total, 0);
    assert_eq!(metrics.databases_total, 0);
}

#[test]
fn non_controller_can_query_public_wiki_metrics_series_clamped_to_seven_days() {
    install_empty_test_service();
    let non_controller = Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("valid non-controller principal");
    set_test_caller_principal_for_test(non_controller);

    let series = wiki_metrics_series(30)
        .expect("public metrics series should not require controller and should clamp to max 7");

    assert_eq!(series.len(), 7);
    assert_eq!(series[0].metrics.users_total, 0);
    assert_eq!(series[0].metrics.databases_total, 0);
}

#[test]
fn reader_can_query_database_sql_json_without_controller_role() {
    install_test_service();
    let reader =
        Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai").expect("valid reader principal");
    SERVICE.with(|slot| {
        let service = slot.borrow();
        let service = service.as_ref().expect("service should be installed");
        service
            .write_node(
                "2vxsx-fae",
                WriteNodeRequest {
                    database_id: "default".to_string(),
                    path: "/Knowledge/sql.md".to_string(),
                    kind: NodeKind::File,
                    content: "database sql".to_string(),
                    metadata_json: "{}".to_string(),
                    expected_etag: None,
                },
                1_700_000_000_002,
            )
            .expect("node should write");
        service
            .grant_database_access(
                "default",
                "2vxsx-fae",
                &reader.to_text(),
                DatabaseRole::Reader,
                1_700_000_000_003,
            )
            .expect("reader grant should succeed");
    });
    set_test_caller_principal_for_test(reader);

    let result = query_database_sql_json(
        "default".to_string(),
        "SELECT json_object('path', path, 'content', content) FROM fs_nodes WHERE path = '/Knowledge/sql.md' LIMIT 1".to_string(),
        10,
    )
    .expect("reader should query database SQL");

    assert_eq!(result.row_count, 1);
    assert_eq!(
        result.rows,
        vec![r#"{"path":"/Knowledge/sql.md","content":"database sql"}"#]
    );
}

#[test]
fn database_sql_json_rejects_non_readers_at_entrypoint() {
    install_test_service();
    let non_reader =
        Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai").expect("valid non-reader principal");
    set_test_caller_principal_for_test(non_reader);

    let error = query_database_sql_json(
        "default".to_string(),
        "SELECT json_object('ok', 1) LIMIT 1".to_string(),
        10,
    )
    .expect_err("non-reader should reject");

    assert!(error.contains("principal has no access"));
}

#[test]
fn database_sql_json_rejects_invalid_json_at_entrypoint() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::anonymous());

    let error = query_database_sql_json(
        "default".to_string(),
        "SELECT 'not-json' FROM fs_nodes LIMIT 1".to_string(),
        10,
    )
    .expect_err("invalid JSON should reject");

    assert!(error.contains("exactly one non-null valid JSON object TEXT column"));
}

#[test]
fn database_sql_json_rejects_extra_result_columns_at_entrypoint() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::anonymous());

    let error = query_database_sql_json(
        "default".to_string(),
        "SELECT json_object('ok', 1), path FROM fs_nodes LIMIT 1".to_string(),
        10,
    )
    .expect_err("extra result columns should reject");

    assert!(error.contains("exactly one non-null valid JSON object TEXT column"));
}

#[test]
fn controller_can_check_cycles_top_up() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD + 1);

    let result = block_on_ready(check_cycles_top_up()).expect("controller should check top-up");

    assert_eq!(result.status, CyclesTopUpCheckStatus::SkippedAboveThreshold);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 0);
}

#[test]
fn cycles_top_up_skips_when_disabled() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(1);
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .update_cycles_billing_config(
                CyclesBillingConfigUpdate {
                    iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
                    cycles_per_kinic: 1_000,
                    min_update_cycles: 1,
                    top_up: test_cycles_top_up_config(false, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
                },
                &test_billing_authority_principal().to_text(),
            )
            .expect("top-up config should update");
    });

    let result = block_on_ready(check_cycles_top_up()).expect("disabled check should succeed");

    assert_eq!(result.status, CyclesTopUpCheckStatus::SkippedDisabled);
    assert!(!result.called_launcher);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 0);
}

#[test]
fn cycles_top_up_skips_above_threshold() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD + 1);

    let result = block_on_ready(check_cycles_top_up()).expect("top-up check should succeed");

    assert_eq!(result.status, CyclesTopUpCheckStatus::SkippedAboveThreshold);
    assert!(!result.called_launcher);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 0);
}

#[test]
fn cycles_top_up_calls_launcher_at_threshold() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD);

    let result = block_on_ready(check_cycles_top_up()).expect("top-up check should succeed");

    assert_eq!(result.status, CyclesTopUpCheckStatus::LauncherOk);
    assert!(result.called_launcher);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 1);
}

#[test]
fn cycles_top_up_calls_launcher_once_below_threshold() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD - 1);

    let result = block_on_ready(check_cycles_top_up()).expect("top-up check should succeed");

    assert_eq!(result.status, CyclesTopUpCheckStatus::LauncherOk);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 1);
}

#[test]
fn cycles_top_up_skips_when_request_in_progress() {
    install_empty_test_service();
    clear_cycles_top_up_state_for_test();
    set_test_caller_principal_for_test(Principal::management_canister());
    set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD - 1);
    set_cycles_top_up_in_progress_for_test();

    let result = block_on_ready(check_cycles_top_up()).expect("top-up check should succeed");

    assert_eq!(result.status, CyclesTopUpCheckStatus::SkippedInProgress);
    assert!(!result.called_launcher);
    assert_eq!(cycles_top_up_launcher_call_count_for_test(), 0);
}

#[test]
fn cycles_top_up_launcher_error_stays_outer_ok() {
    for error in [
        CyclesTopUpLauncherError::TooSoon,
        CyclesTopUpLauncherError::Unauthorized,
        CyclesTopUpLauncherError::LauncherBalanceTooLow,
        CyclesTopUpLauncherError::TopUpFailed("rejected".to_string()),
    ] {
        install_empty_test_service();
        clear_cycles_top_up_state_for_test();
        set_test_caller_principal_for_test(Principal::management_canister());
        set_cycles_balance_for_test(DEFAULT_CYCLES_TOP_UP_THRESHOLD - 1);
        set_next_cycles_top_up_launcher_result_for_test(Ok(CyclesTopUpLauncherResult::Err(
            error.clone(),
        )));

        let result =
            block_on_ready(check_cycles_top_up()).expect("launcher Err should stay outer Ok");

        assert_eq!(result.status, CyclesTopUpCheckStatus::LauncherErr);
        assert_eq!(
            result.launcher_result,
            Some(CyclesTopUpLauncherResult::Err(error))
        );
        assert_eq!(cycles_top_up_launcher_call_count_for_test(), 1);
    }
}

#[test]
fn controller_can_settle_database_storage_charges_batch() {
    install_test_service();
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should install")
            .write_node(
                "2vxsx-fae",
                WriteNodeRequest {
                    database_id: "default".to_string(),
                    path: "/Knowledge/storage.md".to_string(),
                    kind: NodeKind::File,
                    content: "storage billing".to_string(),
                    metadata_json: "{}".to_string(),
                    expected_etag: None,
                },
                1_700_000_000_002,
            )
            .expect("storage node should write");
    });
    set_test_caller_principal_for_test(Principal::management_canister());

    let result = settle_database_storage_charges_batch(StorageBillingBatchRequest {
        cursor_mount_id: None,
        limit: Some(100),
    })
    .expect("controller should settle storage billing batch");

    assert_eq!(result.processed_databases, 1);
}

#[test]
fn index_sql_json_rejects_non_controller_callers() {
    install_test_service();
    let non_controller = Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("valid non-controller principal");
    set_test_caller_principal_for_test(non_controller);

    let error = query_index_sql_json("SELECT json_object('ok', 1) LIMIT 1".to_string(), 10)
        .expect_err("non-controller should reject");

    assert!(error.contains("caller is not a canister controller"));
}

#[test]
fn settle_database_storage_charges_batch_rejects_non_controller_callers() {
    install_test_service();
    let non_controller = Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("valid non-controller principal");
    set_test_caller_principal_for_test(non_controller);

    let error = settle_database_storage_charges_batch(StorageBillingBatchRequest {
        cursor_mount_id: None,
        limit: None,
    })
    .expect_err("non-controller should reject");

    assert!(error.contains("caller is not a canister controller"));
}

#[test]
fn index_sql_json_rejects_anonymous_callers() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::anonymous());

    let error = query_index_sql_json("SELECT json_object('ok', 1) LIMIT 1".to_string(), 10)
        .expect_err("anonymous should reject");

    assert!(error.contains("caller is not a canister controller"));
}

#[test]
fn index_sql_json_rejects_mutating_and_multi_statement_sql() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    for sql in [
        "UPDATE database_cycle_accounts SET balance_cycles = 0",
        "DELETE FROM database_cycle_ledger",
        "INSERT INTO database_cycle_ledger (database_id) VALUES ('x')",
        "CREATE TABLE x (id INTEGER)",
        "DROP TABLE database_cycle_ledger",
        "PRAGMA table_info(database_cycle_ledger)",
        "ATTACH DATABASE 'x' AS x",
        "SELECT json_object('ok', 1); SELECT json_object('ok', 2)",
    ] {
        let error = query_index_sql_json(sql.to_string(), 10).expect_err("SQL should reject");
        assert!(
            error.contains("index SQL must") || error.contains("index SQL token is not allowed"),
            "unexpected error for {sql}: {error}"
        );
    }
}

#[test]
fn index_sql_json_requires_text_json_first_column() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    let error = query_index_sql_json("SELECT 1 LIMIT 1".to_string(), 10)
        .expect_err("non-text first column should reject");

    assert!(error.contains("exactly one non-null valid JSON object TEXT column"));
}

#[test]
fn index_sql_json_requires_json_object_at_entrypoint() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    for sql in [
        "SELECT 'not-json' LIMIT 1",
        "SELECT json_array(1, 2) LIMIT 1",
        "SELECT json('null') LIMIT 1",
    ] {
        let error =
            query_index_sql_json(sql.to_string(), 10).expect_err("non-object JSON should reject");
        assert!(
            error.contains("exactly one non-null valid JSON object TEXT column"),
            "unexpected error for {sql}: {error}"
        );
    }
}

#[test]
fn index_sql_json_rejects_oversized_row_at_entrypoint() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    let error = query_index_sql_json(
        "SELECT json_object('content', printf('%270000s', 'x')) LIMIT 1".to_string(),
        1,
    )
    .expect_err("oversized index SQL row should reject");

    assert!(error.contains("row JSON exceeds"));
}

#[test]
fn index_sql_json_rejects_extra_result_columns() {
    install_test_service();
    set_test_caller_principal_for_test(Principal::management_canister());

    let error = query_index_sql_json("SELECT json_object('ok', 1), 1 LIMIT 1".to_string(), 10)
        .expect_err("extra result columns should reject");

    assert!(error.contains("exactly one non-null valid JSON object TEXT column"));
}

fn fund_database(database_id: &str, payment_amount_e8s: u64, ledger_block_index: u64) {
    let principal = Principal::management_canister().to_text();
    SERVICE.with(|slot| {
        let service = slot.borrow();
        let service = service.as_ref().expect("service should be installed");
        let operation_id = service
            .begin_database_cycles_purchase(
                database_id,
                &principal,
                payment_amount_e8s,
                1_700_000_000_000,
            )
            .expect("database cycle purchase should begin");
        service
            .prepare_pending_database_activation(database_id, 1_700_000_000_000)
            .expect("pending database activation should prepare");
        let cycles = super::cycles_for_payment_amount_e8s(
            payment_amount_e8s,
            &service
                .cycles_billing_config()
                .expect("cycles config should load"),
        )
        .expect("cycles amount should compute");
        service
            .complete_database_cycles_purchase_ledger_transfer(
                operation_id,
                database_id,
                &principal,
                cycles,
                ledger_block_index,
            )
            .expect("ledger transfer should be marked complete");
        service
            .apply_database_cycles_purchase(
                operation_id,
                database_id,
                &principal,
                cycles,
                ledger_block_index,
                1_700_000_000_000,
            )
            .expect("database should be funded");
    });
}

fn test_billing_authority_principal() -> Principal {
    Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("billing authority principal should parse")
}

struct AuthenticatedCallerGuard;

impl AuthenticatedCallerGuard {
    fn install() -> Self {
        set_test_caller_principal_for_test(Principal::management_canister());
        Self
    }

    fn install_principal(principal: Principal) -> Self {
        set_test_caller_principal_for_test(principal);
        Self
    }
}

impl Drop for AuthenticatedCallerGuard {
    fn drop(&mut self) {
        set_test_caller_principal_for_test(Principal::anonymous());
    }
}

#[test]
fn update_cycles_billing_config_accepts_record_argument() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install_principal(test_billing_authority_principal());

    update_cycles_billing_config(CyclesBillingConfigUpdate {
        iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
        cycles_per_kinic: 469_000_000_000,
        min_update_cycles: 2_000_000,
        top_up: test_cycles_top_up_config(true, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
    })
    .expect("cycles config update should accept record argument");

    let config = get_cycles_billing_config().expect("cycles config should load");
    assert_eq!(config.cycles_per_kinic, 469_000_000_000);
    assert_eq!(config.min_update_cycles, 2_000_000);
}

#[test]
fn post_upgrade_cycles_billing_config_arg_accepts_no_arg() {
    let bytes = Encode!().expect("empty candid args should encode");

    let parsed = parse_upgrade_cycles_billing_config_arg(&bytes)
        .expect("empty post-upgrade arg should parse");

    assert_eq!(parsed, None);
}

#[test]
fn post_upgrade_cycles_billing_config_arg_accepts_bare_config() {
    let config = explicit_cycles_billing_config();
    let bytes = Encode!(&config).expect("cycles config should encode");

    let parsed = parse_upgrade_cycles_billing_config_arg(&bytes)
        .expect("bare post-upgrade config should parse");

    assert_eq!(parsed, Some(config));
}

#[test]
fn post_upgrade_cycles_billing_config_arg_accepts_optional_config() {
    let config = explicit_cycles_billing_config();
    let bytes = Encode!(&Some(config.clone())).expect("optional cycles config should encode");

    let parsed = parse_upgrade_cycles_billing_config_arg(&bytes)
        .expect("optional post-upgrade config should parse");

    assert_eq!(parsed, Some(config));
}

#[test]
fn transfer_from_duplicate_outcome_is_completed() {
    let outcome = transfer_from_error_outcome(TransferFromError::Duplicate {
        duplicate_of: Nat::from(77_u64),
    });

    match outcome {
        LedgerTransferFromOutcome::Completed(block_index) => assert_eq!(block_index, 77),
        other => panic!("duplicate should complete, got {other:?}"),
    }
}

#[test]
fn transfer_from_bad_fee_outcome_is_typed() {
    let outcome = transfer_from_error_outcome(TransferFromError::BadFee {
        expected_fee: Nat::from(99_u64),
    });

    match outcome {
        LedgerTransferFromOutcome::BadFee { expected_fee_e8s } => {
            assert_eq!(expected_fee_e8s, 99);
        }
        other => panic!("bad fee should be typed, got {other:?}"),
    }
}

#[test]
fn purchase_database_cycles_cycles_completed_transfer_from() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Funded".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));

    let result = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect("completed transfer-from should cycle database");

    assert_eq!(result.block_index, 42);
    assert_eq!(result.amount_cycles, 1_172_500);
    assert_eq!(result.balance_cycles, 1_172_500);
    assert_eq!(
        last_ledger_to_for_test()
            .expect("ledger recipient should record")
            .owner
            .to_text(),
        "isz6c-6c4pl-oba7w-ikjex-472yu-rf3fe-valdh-lfazm-5f3ep-v474i-qae"
    );
    assert_eq!(
        database_status_and_mount(&database.database_id).0,
        DatabaseStatus::Active
    );
    let entries = list_database_cycle_entries(database.database_id.clone(), None, 10)
        .expect("database ledger should load")
        .entries;
    assert_eq!(entries.len(), 1);
    assert_eq!(entries[0].kind.as_str(), "cycles_purchase");
    assert_eq!(entries[0].ledger_block_index, Some(42));
}

#[test]
fn purchase_database_cycles_rejects_anonymous_before_ledger_call() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Anonymous purchase".to_string(),
    })
    .expect("database should create");
    drop(_caller);
    clear_last_ledger_memo_for_test();
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("anonymous caller should reject before ledger transfer");

    assert!(error.contains("anonymous caller not allowed"));
    assert_eq!(last_ledger_memo_for_test(), None);
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
}

#[test]
fn purchase_database_cycles_treats_duplicate_as_completed_transfer() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Duplicate ledger".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(transfer_from_error_outcome(
        TransferFromError::Duplicate {
            duplicate_of: Nat::from(77_u64),
        },
    ));

    let result = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect("duplicate transfer-from should cycle database");

    assert_eq!(result.block_index, 77);
    assert_eq!(
        database_status_and_mount(&database.database_id).0,
        DatabaseStatus::Active
    );
    let entries = list_database_cycle_entries(database.database_id, None, 10)
        .expect("database ledger should load")
        .entries;
    assert_eq!(entries.len(), 1);
    assert_eq!(entries[0].kind, "cycles_purchase");
    assert_eq!(entries[0].ledger_block_index, Some(77));
}

#[test]
fn list_database_cycle_entries_paginates_with_clamped_limits() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Cycle history pages".to_string(),
    })
    .expect("database should create");
    for index in 0..105 {
        fund_database(&database.database_id, 500, index + 1);
    }

    let minimum_page = list_database_cycle_entries(database.database_id.clone(), None, 0)
        .expect("minimum page should load");
    assert_eq!(minimum_page.entries.len(), 1);
    assert_eq!(minimum_page.entries[0].entry_id, 1);
    assert_eq!(minimum_page.next_cursor, Some(1));

    let first_page = list_database_cycle_entries(database.database_id.clone(), None, 200)
        .expect("first clamped page should load");
    assert_eq!(first_page.entries.len(), 100);
    assert_eq!(first_page.entries[0].entry_id, 1);
    assert_eq!(first_page.entries[99].entry_id, 100);
    assert_eq!(first_page.next_cursor, Some(100));

    let second_page =
        list_database_cycle_entries(database.database_id, first_page.next_cursor, 200)
            .expect("second clamped page should load");
    assert_eq!(second_page.entries.len(), 5);
    assert_eq!(second_page.entries[0].entry_id, 101);
    assert_eq!(second_page.entries[4].entry_id, 105);
    assert_eq!(second_page.next_cursor, None);
}

#[test]
fn purchase_database_cycles_rejects_bad_fee_without_credit() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Bad fee".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::BadFee {
        expected_fee_e8s: KINIC_LEDGER_FEE_E8S + 1,
    });

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("BadFee should reject and leave no credit");

    assert!(error.contains("BadFee expected fee"));
    assert!(error.contains("re-approve with the current ledger fee"));
    assert_eq!(ledger_transfer_fees_for_test(), vec![KINIC_LEDGER_FEE_E8S]);
    assert!(
        list_database_cycle_entries(database.database_id.clone(), None, 10)
            .expect("ledger should load")
            .entries
            .is_empty()
    );
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
}

#[test]
fn purchase_database_cycles_rejects_invalid_target_before_ledger_call() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Purchase validation".to_string(),
    })
    .expect("database should create");

    clear_last_ledger_memo_for_test();
    let zero = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        0,
    )))
    .expect_err("zero amount should reject");
    assert!(zero.contains("cycles purchase payment amount must be positive"));

    let overflow = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        i64::MAX as u64,
    )))
    .expect_err("payment amount overflow should reject before approve");
    assert!(overflow.contains("cycles purchase amount exceeds u64"));

    let missing = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        "missing", 500,
    )))
    .expect_err("missing database should reject");
    assert!(missing.contains("database not found"));
    assert_eq!(last_ledger_memo_for_test(), None);
}

#[test]
fn purchase_database_cycles_rejects_balance_overflow_before_ledger_call() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Overflow".to_string(),
    })
    .expect("database should create");
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .update_cycles_billing_config(
                CyclesBillingConfigUpdate {
                    iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
                    cycles_per_kinic: 100_000_000,
                    min_update_cycles: 1,
                    top_up: test_cycles_top_up_config(true, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
                },
                &test_billing_authority_principal().to_text(),
            )
            .expect("cycles config should update");
    });
    fund_database(&database.database_id, i64::MAX as u64, 41);
    clear_last_ledger_memo_for_test();
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));

    let error = block_on_ready(purchase_database_cycles(DatabaseCyclesPurchaseRequest {
        database_id: database.database_id,
        payment_amount_e8s: 1,
        min_expected_cycles: 1,
    }))
    .expect_err("overflow should reject before ledger");

    assert!(error.contains("balance overflow"));
    assert_eq!(last_ledger_memo_for_test(), None);
}

#[test]
fn purchase_database_cycles_uses_current_config_amount() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Current config".to_string(),
    })
    .expect("database should create");
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .update_cycles_billing_config(
                CyclesBillingConfigUpdate {
                    iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
                    cycles_per_kinic: 234_500_000_000,
                    min_update_cycles: 2,
                    top_up: test_cycles_top_up_config(true, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
                },
                &test_billing_authority_principal().to_text(),
            )
            .expect("cycles config should update");
    });
    clear_last_ledger_memo_for_test();
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));

    let result = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect("purchase should use current config");

    assert_eq!(result.amount_cycles, 1_172_500);
    assert_eq!(result.balance_cycles, 1_172_500);
    let entries = list_database_cycle_entries(database.database_id, None, 10)
        .expect("cycles history should load")
        .entries;
    assert_eq!(entries[0].amount_cycles, 1_172_500);
}

#[test]
fn purchase_database_cycles_leaves_balance_on_ledger_reject() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Rejected".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::LedgerErr(
        "icrc2_transfer_from failed: InsufficientAllowance".to_string(),
    ));

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("ledger reject should not cycle database");

    assert!(error.contains("InsufficientAllowance"));
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
    let entries = list_database_cycle_entries(database.database_id.clone(), None, 10)
        .expect("database ledger should load")
        .entries;
    assert!(entries.is_empty());
}

#[test]
fn purchase_database_cycles_keeps_ambiguous_transfer_from_for_review() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Ambiguous".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Ambiguous(
        "icrc2_transfer_from decode failed".to_string(),
    ));

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("ambiguous transfer-from should require review");

    assert!(error.contains("result ambiguous"));
    assert!(error.contains("operation_id 1"));
    assert!(error.contains("billing authority review required"));
    assert_eq!(
        pending_cycle_purchase_state(&database.database_id),
        r#"{"status":"ambiguous","block":null}"#
    );
    assert!(database_exists(&database.database_id));
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
    let duplicate = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("ambiguous pending operation should block duplicate purchase");
    assert!(
        duplicate.contains("database activation is pending")
            || duplicate.contains("cycles purchase already pending")
    );
}

#[test]
fn list_database_cycles_pending_purchases_allows_owner_authority_and_payer() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let payer = Principal::from_text(DEFAULT_LLM_WRITER_PRINCIPAL).expect("payer should parse");
    let stranger =
        Principal::from_text("bkyz2-fmaaa-aaaaa-qaaaq-cai").expect("stranger should parse");
    let database = {
        let _owner = AuthenticatedCallerGuard::install_principal(owner);
        mark_initial_free_database_grant_used_for_test();
        create_database(CreateDatabaseRequest {
            name: "Pending".to_string(),
        })
        .expect("database should create")
    };

    let payer_guard = AuthenticatedCallerGuard::install_principal(payer);
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Ambiguous(
        "timeout".to_string(),
    ));
    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        50_000_000,
    )))
    .expect_err("ambiguous transfer should keep pending operation");
    assert!(error.contains("billing authority review required"));

    let payer_view = list_database_cycles_pending_purchases(database.database_id.clone())
        .expect("payer should view own pending purchase");
    assert_eq!(payer_view.len(), 1);
    assert_eq!(payer_view[0].status, "ambiguous");
    assert_eq!(payer_view[0].required_action, "billing_authority_review");

    drop(payer_guard);
    let owner_guard = AuthenticatedCallerGuard::install_principal(owner);
    let owner_view = list_database_cycles_pending_purchases(database.database_id.clone())
        .expect("owner should view pending purchase");
    assert_eq!(owner_view, payer_view);

    drop(owner_guard);
    let authority_guard =
        AuthenticatedCallerGuard::install_principal(test_billing_authority_principal());
    let authority_view = list_database_cycles_pending_purchases(database.database_id.clone())
        .expect("billing authority should view pending purchase");
    assert_eq!(authority_view, payer_view);

    drop(authority_guard);
    let _stranger = AuthenticatedCallerGuard::install_principal(stranger);
    let error = list_database_cycles_pending_purchases(database.database_id)
        .expect_err("unrelated caller should reject");
    assert!(error.contains("cannot view pending cycle purchases"));
}

#[test]
fn purchase_database_cycles_mount_failure_keeps_completed_pending_operation() {
    install_empty_test_service();
    let _owner = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Mount review".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));
    fail_next_mount_database_file_for_test();

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        500,
    )))
    .expect_err("mount failure after ledger success should not credit");

    assert!(error.contains("test mount failure"));
    assert!(error.contains("remains completed for billing authority review"));
    assert_eq!(
        pending_cycle_purchase_state(&database.database_id),
        r#"{"status":"completed","block":42}"#
    );
    assert!(database_exists(&database.database_id));
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
    assert_eq!(
        pending_database_activation_state(&database.database_id),
        r#"{"status":"pending","mount_id":11,"active_mount_id":null,"has_db_file_name":1}"#
    );
    assert!(
        list_database_cycle_entries(database.database_id.clone(), None, 10)
            .expect("database ledger should load")
            .entries
            .is_empty()
    );
    assert_eq!(
        list_database_cycles_pending_purchases(database.database_id)
            .expect("owner should view completed pending purchase")[0]
            .required_action,
        "billing_authority_review"
    );
}

#[test]
fn purchase_database_cycles_apply_failure_keeps_completed_pending_for_review() {
    install_empty_test_service();
    let _owner = AuthenticatedCallerGuard::install();
    mark_initial_free_database_grant_used_for_test();
    let database = create_database(CreateDatabaseRequest {
        name: "Apply review".to_string(),
    })
    .expect("database should create");
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(44));
    fail_next_apply_database_cycles_purchase_apply_for_test();

    let error = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        600,
    )))
    .expect_err("cycle apply failure after activation should not credit");

    assert!(error.contains("test cycle purchase apply failure"));
    assert!(error.contains("remains completed for billing authority review"));
    assert_eq!(
        pending_cycle_purchase_state(&database.database_id),
        r#"{"status":"completed","block":44}"#
    );
    assert!(database_exists(&database.database_id));
    assert_eq!(
        database_status_and_mount(&database.database_id),
        (DatabaseStatus::Pending, None)
    );
    assert_eq!(
        pending_database_activation_state(&database.database_id),
        r#"{"status":"pending","mount_id":11,"active_mount_id":null,"has_db_file_name":1}"#
    );
    assert!(
        list_database_cycle_entries(database.database_id.clone(), None, 10)
            .expect("database ledger should load")
            .entries
            .is_empty()
    );
    let duplicate = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        600,
    )))
    .expect_err("completed pending operation should block duplicate purchase");
    assert!(duplicate.contains("database activation is pending"));

    assert_eq!(
        list_database_cycles_pending_purchases(database.database_id)
            .expect("owner should view completed pending purchase")[0]
            .required_action,
        "billing_authority_review"
    );
}

#[test]
fn purchase_database_cycles_allows_non_owner_payer() {
    install_empty_test_service();
    let database_id = {
        let _owner = AuthenticatedCallerGuard::install();
        mark_initial_free_database_grant_used_for_test();
        create_database(CreateDatabaseRequest {
            name: "Public funding".to_string(),
        })
        .expect("database should create")
        .database_id
    };
    let payer = Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai")
        .expect("test payer principal should parse");
    let _payer = AuthenticatedCallerGuard::install_principal(payer);
    clear_last_ledger_memo_for_test();
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(43));

    let result = block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database_id,
        700,
    )))
    .expect("non-owner payer should fund DB");

    assert_eq!(result.block_index, 43);
    assert_eq!(result.amount_cycles, 1_641_500);
    assert_eq!(result.balance_cycles, 1_641_500);
    assert_eq!(
        last_ledger_from_for_test().expect("ledger from should be recorded"),
        IcrcAccount {
            owner: payer,
            subaccount: None,
        }
    );
}

#[test]
fn icrc21_purchase_database_cycles_returns_consent_message() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    let database = create_database(CreateDatabaseRequest {
        name: "Consent".to_string(),
    })
    .expect("database should create");
    let request = cycles_purchase_request(&database.database_id, 50_000);
    let arg = Encode!(&request).expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("purchase_database_cycles", arg));

    let message = match response {
        Icrc21ConsentMessageResponse::Ok(info) => match info.consent_message {
            Icrc21ConsentMessage::GenericDisplayMessage(message) => message,
        },
        Icrc21ConsentMessageResponse::Err(error) => {
            panic!("consent message should succeed: {error:?}");
        }
    };
    assert!(message.contains(&database.database_id));
    assert!(message.contains("Cycles: `117250000`"));
    assert!(message.contains("Payment: `0.0005` KINIC"));
    assert!(message.contains("Ledger transfer fee in allowance: `0.001` KINIC"));
    assert!(message.contains("Spender canister:"));
}

#[test]
fn icrc21_purchase_database_cycles_rejects_missing_database() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    let request = cycles_purchase_request("missing", 500);
    let arg = Encode!(&request).expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("purchase_database_cycles", arg));

    match response {
        Icrc21ConsentMessageResponse::Err(super::Icrc21Error::UnsupportedCanisterCall(info)) => {
            assert!(info.description.contains("database not found"));
        }
        other => panic!("missing database consent should reject: {other:?}"),
    }
}

#[test]
fn icrc21_rejects_unsupported_cycle_consent_method() {
    install_empty_test_service();
    let response = icrc21_canister_call_consent_message(consent_request("write_node", Vec::new()));

    assert!(matches!(
        response,
        Icrc21ConsentMessageResponse::Err(super::Icrc21Error::UnsupportedCanisterCall(_))
    ));
}

#[test]
fn icrc21_rejects_malformed_cycle_consent_arg() {
    install_empty_test_service();
    let response = icrc21_canister_call_consent_message(consent_request(
        "purchase_database_cycles",
        Vec::new(),
    ));

    assert!(matches!(
        response,
        Icrc21ConsentMessageResponse::Err(super::Icrc21Error::ConsentMessageUnavailable(_))
    ));
}

#[test]
fn icrc21_market_purchase_access_returns_consent_message() {
    install_empty_test_service();
    let seller = test_billing_authority_principal();
    let payer = Principal::management_canister();
    let access =
        Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").expect("access principal should parse");
    let listing = {
        let _seller = AuthenticatedCallerGuard::install_principal(seller);
        let database = create_database(CreateDatabaseRequest {
            name: "Market consent".to_string(),
        })
        .expect("database should create");
        fund_database(&database.database_id, 1_000_000, 301);
        market_create_listing(market_listing_request(&database.database_id, 250_000_000))
            .expect("listing should create")
    };
    let _payer = AuthenticatedCallerGuard::install_principal(payer);
    let arg = Encode!(&market_purchase_request(
        &listing.listing_id,
        listing.price_e8s,
        access,
    ))
    .expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("market_purchase_access", arg));

    let message = match response {
        Icrc21ConsentMessageResponse::Ok(info) => match info.consent_message {
            Icrc21ConsentMessage::GenericDisplayMessage(message) => message,
        },
        Icrc21ConsentMessageResponse::Err(error) => {
            panic!("market purchase consent should succeed: {error:?}");
        }
    };
    assert!(message.contains("Purchase marketplace database access"));
    assert!(message.contains("Listing: `Market consent`"));
    assert!(message.contains("Payment: `2.5` KINIC"));
    assert!(message.contains("Ledger transfer fee in allowance: `0.001` KINIC"));
    assert!(message.contains(&format!("Seller principal: `{}`", seller.to_text())));
    assert!(message.contains(&format!(
        "Seller payout principal: `{}`",
        Principal::management_canister().to_text()
    )));
    assert!(message.contains(&format!("Payer wallet principal: `{}`", payer.to_text())));
    assert!(message.contains(&format!("Access principal: `{}`", access.to_text())));
    assert!(message.contains("read-only marketplace entitlement"));
}

#[test]
fn icrc21_market_purchase_access_canonicalizes_access_principal() {
    install_empty_test_service();
    let seller = test_billing_authority_principal();
    let payer = Principal::management_canister();
    let access =
        Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").expect("access principal should parse");
    let listing = {
        let _seller = AuthenticatedCallerGuard::install_principal(seller);
        let database = create_database(CreateDatabaseRequest {
            name: "Market canonical consent".to_string(),
        })
        .expect("database should create");
        fund_database(&database.database_id, 1_000_000, 301);
        market_create_listing(market_listing_request(&database.database_id, 250_000_000))
            .expect("listing should create")
    };
    let _payer = AuthenticatedCallerGuard::install_principal(payer);
    let arg = Encode!(&MarketPurchaseRequest {
        listing_id: listing.listing_id.clone(),
        price_e8s: listing.price_e8s,
        access_principal: access.to_text().to_ascii_uppercase(),
    })
    .expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("market_purchase_access", arg));

    let message = match response {
        Icrc21ConsentMessageResponse::Ok(info) => match info.consent_message {
            Icrc21ConsentMessage::GenericDisplayMessage(message) => message,
        },
        Icrc21ConsentMessageResponse::Err(error) => {
            panic!("market purchase consent should succeed: {error:?}");
        }
    };
    assert!(message.contains(&format!("Access principal: `{}`", access.to_text())));
    assert!(!message.contains(&format!(
        "Access principal: `{}`",
        access.to_text().to_ascii_uppercase()
    )));
}

#[test]
fn icrc21_market_purchase_access_rejects_price_mismatch() {
    install_empty_test_service();
    let seller = test_billing_authority_principal();
    let payer = Principal::management_canister();
    let access =
        Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").expect("access principal should parse");
    let listing = {
        let _seller = AuthenticatedCallerGuard::install_principal(seller);
        let database = create_database(CreateDatabaseRequest {
            name: "Price mismatch".to_string(),
        })
        .expect("database should create");
        fund_database(&database.database_id, 1_000_000, 302);
        market_create_listing(market_listing_request(&database.database_id, 250_000_000))
            .expect("listing should create")
    };
    let _payer = AuthenticatedCallerGuard::install_principal(payer);
    let arg = Encode!(&market_purchase_request(
        &listing.listing_id,
        listing.price_e8s + 1,
        access,
    ))
    .expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("market_purchase_access", arg));

    match response {
        Icrc21ConsentMessageResponse::Err(super::Icrc21Error::UnsupportedCanisterCall(info)) => {
            assert!(info.description.contains("market listing price mismatch"));
        }
        other => panic!("price mismatch consent should reject: {other:?}"),
    }
}

#[test]
fn icrc21_market_purchase_access_rejects_inactive_listing() {
    install_empty_test_service();
    let seller = test_billing_authority_principal();
    let payer = Principal::management_canister();
    let access =
        Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").expect("access principal should parse");
    let listing = {
        let _seller = AuthenticatedCallerGuard::install_principal(seller);
        let database = create_database(CreateDatabaseRequest {
            name: "Inactive listing".to_string(),
        })
        .expect("database should create");
        fund_database(&database.database_id, 1_000_000, 303);
        let listing = market_create_listing(market_listing_request(&database.database_id, 250))
            .expect("listing should create");
        market_pause_listing(listing.listing_id.clone()).expect("listing should pause");
        listing
    };
    let _payer = AuthenticatedCallerGuard::install_principal(payer);
    let arg = Encode!(&market_purchase_request(
        &listing.listing_id,
        listing.price_e8s,
        access,
    ))
    .expect("arg should encode");

    let response =
        icrc21_canister_call_consent_message(consent_request("market_purchase_access", arg));

    match response {
        Icrc21ConsentMessageResponse::Err(super::Icrc21Error::UnsupportedCanisterCall(info)) => {
            assert!(info.description.contains("market listing is not active"));
        }
        other => panic!("inactive listing consent should reject: {other:?}"),
    }
}

#[test]
fn market_list_seller_listings_filters_by_seller_and_pages() {
    install_empty_test_service();
    let seller_a = test_billing_authority_principal();
    let seller_b = Principal::management_canister();
    {
        let _seller = AuthenticatedCallerGuard::install_principal(seller_a);
        let first = create_database(CreateDatabaseRequest {
            name: "Seller A first".to_string(),
        })
        .expect("first database should create");
        fund_database(&first.database_id, 1_000_000, 304);
        market_create_listing(market_listing_request(&first.database_id, 100))
            .expect("first listing should create");
        let second = create_database(CreateDatabaseRequest {
            name: "Seller A second".to_string(),
        })
        .expect("second database should create");
        fund_database(&second.database_id, 1_000_000, 305);
        market_create_listing(market_listing_request(&second.database_id, 200))
            .expect("second listing should create");
    }
    {
        let _seller = AuthenticatedCallerGuard::install_principal(seller_b);
        let other = create_database(CreateDatabaseRequest {
            name: "Seller B listing".to_string(),
        })
        .expect("other database should create");
        fund_database(&other.database_id, 1_000_000, 306);
        market_create_listing(market_listing_request(&other.database_id, 300))
            .expect("other listing should create");
    }

    let first_page = market_list_seller_listings(seller_a.to_text(), None, 1)
        .expect("first seller page should load");
    assert_eq!(first_page.listings.len(), 1);
    assert_eq!(
        first_page.listings[0].listing.seller_principal,
        seller_a.to_text()
    );
    assert!(first_page.next_cursor.is_some());

    let second_page = market_list_seller_listings(seller_a.to_text(), first_page.next_cursor, 10)
        .expect("second seller page should load");
    assert_eq!(second_page.listings.len(), 1);
    assert_eq!(
        second_page.listings[0].listing.seller_principal,
        seller_a.to_text()
    );
    assert!(second_page.next_cursor.is_none());
}

#[test]
fn purchase_database_cycles_sends_operation_memo_to_ledger() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    let database = create_database(CreateDatabaseRequest {
        name: "Memo".to_string(),
    })
    .expect("database should create");
    clear_last_ledger_memo_for_test();
    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(43));

    block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &database.database_id,
        700,
    )))
    .expect("cycle purchase should succeed");

    let memo = String::from_utf8(last_ledger_memo_for_test().expect("memo should be recorded"))
        .expect("memo should be utf8");
    let operation_id = memo
        .strip_prefix("kvfs:cp:")
        .expect("memo should use compact cycles purchase prefix")
        .parse::<u64>()
        .expect("memo should end with decimal operation id");
    assert!(operation_id > 0);
}

#[test]
fn purchase_database_cycles_rejects_unknown_and_deleted_database() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();

    let missing = block_on_ready(purchase_database_cycles(DatabaseCyclesPurchaseRequest {
        database_id: "missing".to_string(),
        payment_amount_e8s: 50_000_000,
        min_expected_cycles: 1,
    }))
    .expect_err("unknown database should reject");
    assert!(missing.contains("database not found"));

    let database = create_database(CreateDatabaseRequest {
        name: "Deleted".to_string(),
    })
    .expect("database should create");
    fund_database(&database.database_id, 1_000_000, 44);
    super::delete_database(delete_database_request(&database.database_id))
        .expect("owner should delete");

    let deleted = block_on_ready(purchase_database_cycles(DatabaseCyclesPurchaseRequest {
        database_id: database.database_id,
        payment_amount_e8s: 50_000_000,
        min_expected_cycles: 1,
    }))
    .expect_err("deleted database should reject");
    assert!(deleted.contains("database not found"));
}

fn database_charge_methods(database_id: &str) -> Vec<String> {
    list_database_cycle_entries(database_id.to_string(), None, 100)
        .expect("database cycles ledger should load")
        .entries
        .into_iter()
        .filter(|entry| entry.kind == "charge")
        .map(|entry| entry.method.expect("charge should record method"))
        .collect()
}

fn install_unfunded_default_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("default", "2vxsx-fae", 1_700_000_000_000)
        .expect("default database should create");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn install_suspended_default_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("default", "2vxsx-fae", 1_700_000_000_000)
        .expect("default database should create");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn install_low_balance_default_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("default", "2vxsx-fae", 1_700_000_000_000)
        .expect("default database should create");
    service
        .begin_database_cycles_purchase("default", "2vxsx-fae", 1_000_000, 1_700_000_000_001)
        .and_then(|operation_id| {
            let cycles = cycles_for_test_payment(&service, 1_000_000);
            service.complete_database_cycles_purchase_ledger_transfer(
                operation_id,
                "default",
                "2vxsx-fae",
                cycles,
                1,
            )?;
            service.apply_database_cycles_purchase(
                operation_id,
                "default",
                "2vxsx-fae",
                cycles,
                1,
                1_700_000_000_001,
            )
        })
        .expect("default database should start funded");
    service
        .grant_database_access(
            "default",
            "2vxsx-fae",
            &test_billing_authority_principal().to_text(),
            DatabaseRole::Writer,
            1_700_000_000_002,
        )
        .expect("writer should be granted before low-balance config");
    service
        .update_cycles_billing_config(
            CyclesBillingConfigUpdate {
                iap_authority_id: Some("ryjl3-tyaaa-aaaaa-aaaba-cai".to_string()),
                cycles_per_kinic: 1_000,
                min_update_cycles: 3_000_000_000,
                top_up: test_cycles_top_up_config(true, DEFAULT_CYCLES_TOP_UP_THRESHOLD),
            },
            &test_billing_authority_principal().to_text(),
        )
        .expect("minimum balance should update");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn ensure_parent_folders(path: &str) {
    let segments = path
        .split('/')
        .filter(|segment| !segment.is_empty())
        .collect::<Vec<_>>();
    let mut current = String::new();
    for segment in segments.iter().take(segments.len().saturating_sub(1)) {
        current.push('/');
        current.push_str(segment);
        mkdir_node(MkdirNodeRequest {
            database_id: "default".to_string(),
            path: current.clone(),
        })
        .expect("parent folder should exist or be created");
    }
}

#[test]
fn empty_index_does_not_create_default_database() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");

    let databases = service
        .list_databases()
        .expect("empty index should be readable");
    assert!(databases.is_empty());
}

#[test]
fn existing_database_index_is_loaded_without_implicit_default() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("alpha", "owner", 1)
        .expect("existing database should create");

    let databases = service
        .list_databases()
        .expect("existing index should load");

    assert_eq!(databases.len(), 1);
    assert_eq!(databases[0].database_id, "alpha");
}

#[test]
fn canister_list_databases_returns_caller_membership_summaries() {
    install_test_service();

    let summaries = list_databases().expect("database summaries should load");

    assert_eq!(summaries.len(), 1);
    assert_eq!(summaries[0].database_id, "default");
    assert_eq!(summaries[0].role, DatabaseRole::Owner);
    assert_eq!(summaries[0].status, DatabaseStatus::Active);
}

#[test]
fn canister_list_databases_hides_deleted_databases() {
    install_test_service();

    super::delete_database(delete_database_request("default")).expect("owner should delete");
    let summaries = list_databases().expect("database summaries should load");

    assert!(summaries.is_empty());
}

#[test]
fn database_metadata_description_allows_newlines() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let database_id;

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        let database = create_database(CreateDatabaseRequest {
            name: "Multiline metadata".to_string(),
        })
        .expect("database should create");
        database_id = database.database_id;
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(220));
        block_on_ready(purchase_database_cycles(cycles_purchase_request(
            &database_id,
            1_000_000,
        )))
        .expect("market database should activate");

        let metadata = update_database_metadata(UpdateDatabaseMetadataRequest {
            database_id,
            name: "Multiline metadata".to_string(),
            description: "Line one\nLine two\r\n\tIndented".to_string(),
            llm_summary: Some("Summary one\nSummary two".to_string()),
            tags_json: "[]".to_string(),
        })
        .expect("multiline metadata should update");
        assert_eq!(metadata.description, "Line one\nLine two\r\n\tIndented");
        assert_eq!(
            metadata.llm_summary,
            Some("Summary one\nSummary two".to_string())
        );
    }
}

#[test]
fn database_metadata_rejects_non_whitespace_control_characters() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let database_id;

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        let database = create_database(CreateDatabaseRequest {
            name: "Control metadata".to_string(),
        })
        .expect("database should create");
        database_id = database.database_id;
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(221));
        block_on_ready(purchase_database_cycles(cycles_purchase_request(
            &database_id,
            1_000_000,
        )))
        .expect("market database should activate");

        let description_error = update_database_metadata(UpdateDatabaseMetadataRequest {
            database_id: database_id.clone(),
            name: "Control metadata".to_string(),
            description: "bad\0description".to_string(),
            llm_summary: None,
            tags_json: "[]".to_string(),
        })
        .expect_err("NUL in description should be rejected");
        assert!(description_error.contains("database description may only contain newline"));

        let name_error = update_database_metadata(UpdateDatabaseMetadataRequest {
            database_id: database_id.clone(),
            name: "bad\nname".to_string(),
            description: String::new(),
            llm_summary: None,
            tags_json: "[]".to_string(),
        })
        .expect_err("name newline should be rejected");
        assert!(name_error.contains("database name may not contain control characters"));

        let tags_error = update_database_metadata(UpdateDatabaseMetadataRequest {
            database_id,
            name: "Control metadata".to_string(),
            description: String::new(),
            llm_summary: None,
            tags_json: "[\"bad\ntag\"]".to_string(),
        })
        .expect_err("tags newline should be rejected");
        assert!(tags_error.contains("database tags may not contain control characters"));
    }
}

#[test]
fn database_metadata_rejects_invalid_tags_json() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let database_id;

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        let database = create_database(CreateDatabaseRequest {
            name: "Tags metadata".to_string(),
        })
        .expect("database should create");
        database_id = database.database_id;
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(222));
        block_on_ready(purchase_database_cycles(cycles_purchase_request(
            &database_id,
            1_000_000,
        )))
        .expect("market database should activate");

        for (tags_json, expected) in [
            (
                "{\"tag\":\"not-array\"}",
                "database tags_json must be a JSON string array",
            ),
            (
                "[\"valid\", 1]",
                "database tags_json must be a JSON string array",
            ),
            (
                "[\"valid\", \" \"]",
                "database tags_json must not contain empty tags",
            ),
            (
                "[\"bad\\ntag\"]",
                "database tags_json must not contain control characters",
            ),
        ] {
            let error = update_database_metadata(UpdateDatabaseMetadataRequest {
                database_id: database_id.clone(),
                name: "Tags metadata".to_string(),
                description: String::new(),
                llm_summary: None,
                tags_json: tags_json.to_string(),
            })
            .expect_err("invalid tags_json should be rejected");
            assert!(
                error.contains(expected),
                "expected {expected:?} in {error:?}"
            );
        }
    }
}

#[test]
fn canister_list_databases_includes_market_entitlements_as_reader_access() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let buyer = Principal::self_authenticating(b"market buyer");
    let wallet = Principal::self_authenticating(b"market wallet payer");
    let payout = Principal::self_authenticating(b"market seller payout");
    let database_id;
    let listing_id;

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        let database = create_database(CreateDatabaseRequest {
            name: "Private market".to_string(),
        })
        .expect("market database should create");
        database_id = database.database_id;
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(201));
        block_on_ready(purchase_database_cycles(cycles_purchase_request(
            &database_id,
            1_000_000,
        )))
        .expect("market database should activate");
        write_node(WriteNodeRequest {
            database_id: database_id.clone(),
            path: "/Knowledge/paid.md".to_string(),
            kind: NodeKind::File,
            content: "# Paid\n\nPrivate body".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        })
        .expect("market database content should write");
        let mut request = market_listing_request(&database_id, 500);
        request.payout_principal = payout.to_text();
        let listing = market_create_listing(request).expect("listing should create");
        assert!(!listing.listing_id.starts_with("listing_"));
        assert_eq!(listing.status, MarketListingStatus::Active);
        listing_id = listing.listing_id;
    }

    {
        let _caller = AuthenticatedCallerGuard::install_principal(wallet);
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(202));
        let order = block_on_ready(market_purchase_access(market_purchase_request(
            &listing_id,
            500,
            buyer,
        )))
        .expect("wallet should pay for buyer access");
        assert_eq!(order.buyer_principal, buyer.to_text());
        assert_eq!(order.payout_principal, payout.to_text());
        assert_eq!(order.ledger_block_index, 202);
        assert_eq!(
            last_ledger_from_for_test()
                .expect("market payer should record")
                .owner,
            wallet
        );
        assert_eq!(
            last_ledger_to_for_test()
                .expect("market recipient should record")
                .owner,
            payout
        );
    }

    {
        let _caller = AuthenticatedCallerGuard::install_principal(buyer);
        let summaries = list_databases().expect("buyer database summaries should load");
        let summary = summaries
            .iter()
            .find(|summary| summary.database_id == database_id)
            .expect("entitled database should appear in authenticated list");
        assert_eq!(summary.role, DatabaseRole::Reader);

        let node = read_node(database_id.clone(), "/Knowledge/paid.md".to_string())
            .expect("entitled buyer read should succeed")
            .expect("paid node should exist");
        assert_eq!(node.content, "# Paid\n\nPrivate body");
        let children = list_children(ListChildrenRequest {
            database_id: database_id.clone(),
            path: "/Knowledge".to_string(),
        })
        .expect("entitled buyer should list children");
        assert!(
            children
                .iter()
                .any(|child| child.path == "/Knowledge/paid.md")
        );
    }

    let anonymous_summaries = list_databases().expect("anonymous summaries should load");
    assert!(
        anonymous_summaries
            .iter()
            .all(|summary| summary.database_id != database_id)
    );

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        grant_database_access(database_id.clone(), buyer.to_text(), DatabaseRole::Writer)
            .expect("owner should grant writer access");
    }
    {
        let _caller = AuthenticatedCallerGuard::install_principal(buyer);
        let summaries = list_databases().expect("buyer database summaries should load");
        let matching = summaries
            .iter()
            .filter(|summary| summary.database_id == database_id)
            .collect::<Vec<_>>();
        assert_eq!(matching.len(), 1);
        assert_eq!(matching[0].role, DatabaseRole::Writer);
    }
}

#[test]
fn marketplace_listing_detail_includes_wiki_node_character_counts() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let database_id;
    let listing_id;
    let japanese_content = "# 日本語\n\nabc";

    {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        let database = create_database(CreateDatabaseRequest {
            name: "Market character counts".to_string(),
        })
        .expect("market database should create");
        database_id = database.database_id;
        set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(211));
        block_on_ready(purchase_database_cycles(cycles_purchase_request(
            &database_id,
            1_000_000,
        )))
        .expect("market database should activate");
        write_node(WriteNodeRequest {
            database_id: database_id.clone(),
            path: "/Knowledge/japanese.md".to_string(),
            kind: NodeKind::File,
            content: japanese_content.to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        })
        .expect("wiki node should write");
        mkdir_node(MkdirNodeRequest {
            database_id: database_id.clone(),
            path: "/Sources/test".to_string(),
        })
        .expect("source parent folder should create");
        write_node(WriteNodeRequest {
            database_id: database_id.clone(),
            path: "/Sources/test/source.md".to_string(),
            kind: NodeKind::Source,
            content: "source text should not appear in marketplace node sizes".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        })
        .expect("source node should write");
        let listing = market_create_listing(market_listing_request(&database_id, 500))
            .expect("listing should create");
        assert_eq!(listing.status, MarketListingStatus::Active);
        listing_id = listing.listing_id;
    }

    let detail = market_get_listing(listing_id).expect("listing detail should load");
    let excerpt = detail
        .preview
        .excerpts
        .iter()
        .find(|excerpt| excerpt.path == "/Knowledge/japanese.md")
        .expect("wiki file should appear in marketplace node size details");
    assert_eq!(
        excerpt.content_chars,
        japanese_content.chars().count() as u64
    );
    assert_eq!(excerpt.excerpt, japanese_content);
    assert!(
        detail
            .preview
            .excerpts
            .iter()
            .all(|excerpt| !excerpt.path.starts_with("/Sources/"))
    );
}

#[test]
fn update_charge_cycles_checks_counter_order_and_overflow() {
    assert_eq!(
        update_charge_cycles(10, 11).expect("charge should compute"),
        20_000_001
    );
    assert_eq!(
        update_charge_cycles(11, 10).expect_err("decreased counter should fail"),
        "instruction counter decreased during update"
    );
    assert_eq!(
        update_charge_cycles(0, u128::MAX).expect_err("overflow should fail"),
        "cycle charge overflow"
    );
}

#[test]
fn write_nodes_records_instruction_charge_and_writes_nodes() {
    install_test_service();
    set_update_charge_units_for_test(vec![10_000, 10_321]);

    let results = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![
            WriteNodeItem {
                path: "/Knowledge/batch-a.md".to_string(),
                kind: NodeKind::File,
                content: "alpha".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
            WriteNodeItem {
                path: "/Knowledge/batch-b.md".to_string(),
                kind: NodeKind::File,
                content: "beta".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            },
        ],
    })
    .expect("batch write should succeed");

    assert_eq!(results.len(), 2);
    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    let charge = entries
        .iter()
        .find(|entry| entry.kind == "charge")
        .expect("charge entry should exist");
    assert_eq!(charge.amount_cycles, -20_000_321);
    assert_eq!(charge.cycles_delta, Some(20_000_321));
    assert_eq!(charge.method.as_deref(), Some("write_nodes"));
    assert!(
        read_node("default".to_string(), "/Knowledge/batch-a.md".to_string())
            .expect("read should succeed")
            .is_some()
    );
}

#[test]
fn mutate_nodes_batch_records_one_charge_and_returns_ordered_results() {
    install_test_service();
    set_update_charge_units_for_test(vec![20_000, 20_456]);

    let results = mutate_nodes_batch(MutateNodesBatchRequest {
        database_id: "default".to_string(),
        operations: vec![
            NodeMutation::Mkdir("/Memory".to_string()),
            NodeMutation::Write(WriteNodeItem {
                path: "/Memory/context.md".to_string(),
                kind: NodeKind::File,
                content: "remember this".to_string(),
                metadata_json: "{}".to_string(),
                expected_etag: None,
            }),
        ],
    })
    .expect("heterogeneous batch should succeed");

    assert!(matches!(results[0], NodeMutationResult::Mkdir(_)));
    assert!(matches!(results[1], NodeMutationResult::Write(_)));
    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    let charge = entries
        .iter()
        .find(|entry| entry.kind == "charge")
        .expect("charge entry should exist");
    assert_eq!(charge.amount_cycles, -20_000_456);
    assert_eq!(charge.method.as_deref(), Some("mutate_nodes_batch"));
}

#[test]
fn write_nodes_creates_folder_items() {
    install_test_service();

    let results = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/batch-folder".to_string(),
            kind: NodeKind::Folder,
            content: String::new(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect("batch folder write should succeed");

    assert_eq!(results.len(), 1);
    assert!(results[0].created);
    assert_eq!(results[0].node.path, "/Knowledge/batch-folder");
    assert_eq!(results[0].node.kind, NodeKind::Folder);
    let children = list_children(ListChildrenRequest {
        database_id: "default".to_string(),
        path: "/Knowledge".to_string(),
    })
    .expect("children should load");
    assert!(children.iter().any(
        |child| child.path == "/Knowledge/batch-folder" && child.kind == NodeEntryKind::Folder
    ));
}

#[test]
fn write_node_creates_folder_items() {
    install_test_service();

    let result = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/single-folder".to_string(),
        kind: NodeKind::Folder,
        content: String::new(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("folder write should succeed");

    assert!(result.created);
    assert_eq!(result.node.path, "/Knowledge/single-folder");
    assert_eq!(result.node.kind, NodeKind::Folder);
    let children = list_children(ListChildrenRequest {
        database_id: "default".to_string(),
        path: "/Knowledge".to_string(),
    })
    .expect("children should load");
    assert!(children.iter().any(
        |child| child.path == "/Knowledge/single-folder" && child.kind == NodeEntryKind::Folder
    ));
}

#[test]
fn write_node_and_write_nodes_record_instruction_charges() {
    install_test_service();
    set_update_charge_units_for_test(vec![7, 11, 13, 19]);

    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/single.md".to_string(),
        kind: NodeKind::File,
        content: "single".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("single write should succeed");
    write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/batch.md".to_string(),
            kind: NodeKind::File,
            content: "batch".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect("batch write should succeed");

    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    let charges = entries
        .iter()
        .filter(|entry| entry.kind == "charge")
        .collect::<Vec<_>>();
    assert_eq!(charges.len(), 2);
    assert_eq!(charges[0].method.as_deref(), Some("write_node"));
    assert_eq!(charges[0].cycles_delta, Some(20_000_004));
    assert_eq!(charges[1].method.as_deref(), Some("write_nodes"));
    assert_eq!(charges[1].cycles_delta, Some(20_000_006));
}

#[test]
fn write_node_overdrawn_charge_consumes_balance_and_suspends_database() {
    install_test_service();
    let before_balance = list_databases()
        .expect("database summaries should load")
        .into_iter()
        .find(|database| database.database_id == "default")
        .and_then(|database| database.cycles_balance)
        .expect("default database should have cycles balance");

    set_update_charge_units_for_test(vec![0, 1_000_000_000_000]);
    let written = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/overdrawn.md".to_string(),
        kind: NodeKind::File,
        content: "overdrawn charge still writes".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("overdrawn post-charge should not trap");

    assert_eq!(written.node.path, "/Knowledge/overdrawn.md");
    assert!(
        read_node("default".to_string(), "/Knowledge/overdrawn.md".to_string())
            .expect("written node should read")
            .is_some()
    );
    let summary = list_databases()
        .expect("database summaries should load")
        .into_iter()
        .find(|database| database.database_id == "default")
        .expect("default database summary should exist");
    assert_eq!(summary.cycles_balance, Some(0));
    assert_eq!(summary.cycles_suspended_at_ms, Some(1_700_000_000_000));

    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    let charge = entries
        .iter()
        .find(|entry| entry.kind == "charge")
        .expect("charge entry should exist");
    assert_eq!(charge.amount_cycles, -(before_balance as i64));
    assert_eq!(charge.balance_after_cycles, 0);
    assert_eq!(charge.cycles_delta, Some(1_000_020_000_000));
    assert_eq!(charge.method.as_deref(), Some("write_node"));
}

#[test]
fn failed_update_keeps_original_error_when_instruction_counter_decreases() {
    install_test_service();
    set_update_charge_units_for_test(vec![20, 10]);

    let error = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/stale.md".to_string(),
        kind: NodeKind::File,
        content: "stale write".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: Some("stale".to_string()),
    })
    .expect_err("stale etag write should fail");

    assert_eq!(error.code, NodeMutationErrorCode::NotFound);
    assert!(error.message.contains("/Knowledge/stale.md"));
    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    assert!(entries.iter().all(|entry| entry.kind != "charge"));
}

#[test]
fn write_nodes_rejects_low_database_cycles_balance() {
    install_unfunded_default_service();

    let single = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/no-balance-single.md".to_string(),
        kind: NodeKind::File,
        content: "no balance single".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect_err("low balance database should reject single write");
    let error = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/no-balance.md".to_string(),
            kind: NodeKind::File,
            content: "no balance".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect_err("low balance database should reject batch write");

    assert!(single.message.contains("database cycles are suspended"));
    assert!(error.message.contains("database cycles are suspended"));
    assert_eq!(single.code, NodeMutationErrorCode::WriteUnavailable);
    assert_eq!(error.code, NodeMutationErrorCode::WriteUnavailable);
    assert!(
        read_node(
            "default".to_string(),
            "/Knowledge/no-balance-single.md".to_string()
        )
        .expect("single path read should succeed")
        .is_none()
    );
    assert!(
        read_node(
            "default".to_string(),
            "/Knowledge/no-balance.md".to_string()
        )
        .expect("batch path read should succeed")
        .is_none()
    );
}

#[test]
fn suspended_database_rejects_metered_mutations() {
    install_suspended_default_service();

    let batch = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/suspended.md".to_string(),
            kind: NodeKind::File,
            content: "suspended".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect_err("suspended database should reject batch write");
    let mkdir = mkdir_node(MkdirNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/suspended-folder".to_string(),
    })
    .expect_err("suspended database should reject mkdir");

    assert!(batch.message.contains("database cycles are suspended"));
    assert!(mkdir.message.contains("database cycles are suspended"));
}

#[test]
fn suspended_database_rejects_grant_but_allows_unmetered_owner_management_operations() {
    install_suspended_default_service();

    let grant = grant_database_access(
        "default".to_string(),
        "aaaaa-aa".to_string(),
        DatabaseRole::Reader,
    )
    .expect_err("suspended database should reject metered grant");
    assert!(grant.contains("database cycles are suspended"));

    update_database_metadata(UpdateDatabaseMetadataRequest {
        database_id: "default".to_string(),
        name: "Suspended rename".to_string(),
        description: String::new(),
        llm_summary: None,
        tags_json: "[]".to_string(),
    })
    .expect("suspended database owner should update metadata");
    super::delete_database(delete_database_request("default"))
        .expect("suspended database owner should delete");
}

#[test]
fn low_balance_database_rejects_grant_but_allows_revoke_and_delete() {
    install_low_balance_default_service();

    let grant = grant_database_access(
        "default".to_string(),
        "aaaaa-aa".to_string(),
        DatabaseRole::Reader,
    )
    .expect_err("low-balance database should reject metered grant");
    assert!(grant.contains("database cycles balance is too low"));

    revoke_database_access(
        "default".to_string(),
        test_billing_authority_principal().to_text(),
    )
    .expect("low-balance database owner should revoke");
    super::delete_database(delete_database_request("default"))
        .expect("low-balance database owner should delete");
}

#[test]
fn metered_update_checks_access_before_cycles_state() {
    install_suspended_default_service();
    let _caller = AuthenticatedCallerGuard::install();

    let error = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/no-access.md".to_string(),
            kind: NodeKind::File,
            content: "no access".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect_err("non-member should fail before cycles state");

    assert!(error.message.contains("principal has no access"));
    assert!(!error.message.contains("database cycles are suspended"));
}

#[test]
fn check_database_write_cycles_requires_authenticated_writer() {
    install_empty_test_service();
    let owner = Principal::management_canister();
    let reader =
        Principal::from_text("rrkah-fqaaa-aaaaa-aaaaq-cai").expect("reader principal should parse");
    let database_id = {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        mark_initial_free_database_grant_used_for_test();
        create_database(CreateDatabaseRequest {
            name: "Write cycles check".to_string(),
        })
        .expect("database should create")
        .database_id
    };

    let anonymous =
        check_database_write_cycles(database_id.clone()).expect_err("anonymous caller should fail");
    assert!(anonymous.contains("anonymous caller not allowed"));

    let suspended = {
        let _caller = AuthenticatedCallerGuard::install_principal(owner);
        check_database_write_cycles(database_id.clone())
            .expect_err("suspended database should fail")
    };
    assert!(suspended.contains("database cycles are suspended"));

    fund_database(&database_id, 1_000_000, 91);
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .expect("service should be installed")
            .grant_database_access(
                &database_id,
                &owner.to_text(),
                &reader.to_text(),
                DatabaseRole::Reader,
                2,
            )
            .expect("reader should grant");
    });

    let reader_error = {
        let _caller = AuthenticatedCallerGuard::install_principal(reader);
        check_database_write_cycles(database_id.clone()).expect_err("reader should fail")
    };
    assert!(reader_error.contains("principal lacks required database role"));

    let _caller = AuthenticatedCallerGuard::install_principal(owner);
    check_database_write_cycles(database_id).expect("owner should pass write cycles check");
}

#[test]
fn get_node_publication_rejects_anonymous_at_entrypoint() {
    install_test_service();

    let error = get_node_publication(PublishNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/public.md".to_string(),
    })
    .expect_err("anonymous caller should fail before publication lookup");

    assert!(error.contains("anonymous caller not allowed"));
}

#[test]
fn write_nodes_rejects_reader_role() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("public", "owner", 1)
        .expect("database should create");
    service
        .begin_database_cycles_purchase("public", "owner", 1_000_000, 2)
        .and_then(|operation_id| {
            let cycles = cycles_for_test_payment(&service, 1_000_000);
            service.complete_database_cycles_purchase_ledger_transfer(
                operation_id,
                "public",
                "owner",
                cycles,
                1,
            )?;
            service.apply_database_cycles_purchase(operation_id, "public", "owner", cycles, 1, 2)
        })
        .expect("database should have write cycles available");
    service
        .grant_database_access("public", "owner", "2vxsx-fae", DatabaseRole::Reader, 3)
        .expect("anonymous reader should grant");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));

    let error = write_nodes(WriteNodesRequest {
        database_id: "public".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Knowledge/nope.md".to_string(),
            kind: NodeKind::File,
            content: "nope".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect_err("reader should not write");

    assert!(
        error
            .message
            .contains("principal lacks required database role")
    );
    assert_eq!(error.code, NodeMutationErrorCode::Forbidden);
}

#[test]
fn write_nodes_allows_source_paths_without_schema_validation() {
    install_test_service();

    let results = write_nodes(WriteNodesRequest {
        database_id: "default".to_string(),
        nodes: vec![WriteNodeItem {
            path: "/Sources/not-raw.md".to_string(),
            kind: NodeKind::Source,
            content: "invalid source path".to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        }],
    })
    .expect("source path schema should not be checked at entrypoint");

    assert_eq!(results.len(), 1);
    assert_eq!(results[0].node.path, "/Sources/not-raw.md");
    assert_eq!(results[0].node.kind, NodeKind::Source);
}

#[test]
fn create_database_returns_result() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();
    let initial_grant =
        get_initial_free_database_grant_status().expect("initial grant status should load");
    assert!(initial_grant.available);

    let result = create_database(CreateDatabaseRequest {
        name: " Team skills ".to_string(),
    })
    .expect("database should create");
    assert!(result.database_id.starts_with("db_"));
    assert_eq!(result.database_id.len(), 15);
    assert_eq!(result.name, "Team skills");
    assert_eq!(result.status, DatabaseStatus::Active);
    assert!(result.initial_free_grant_applied);

    let summaries = list_databases().expect("database summaries should load");
    let summary = summaries
        .iter()
        .find(|summary| summary.database_id == result.database_id)
        .expect("created database summary should exist");
    assert_eq!(summary.status, DatabaseStatus::Active);
    let used_grant =
        get_initial_free_database_grant_status().expect("used grant status should load");
    assert!(!used_grant.available);
    assert_eq!(
        used_grant.database_id.as_deref(),
        Some(result.database_id.as_str())
    );

    let children = list_children(ListChildrenRequest {
        database_id: result.database_id.clone(),
        path: "/".to_string(),
    })
    .expect("free grant database should list");
    assert!(children.iter().any(|child| {
        child.path == "/Skills" && child.kind == NodeEntryKind::Folder && !child.is_virtual
    }));

    let pending = create_database(CreateDatabaseRequest {
        name: " Paid skills ".to_string(),
    })
    .expect("second database should create pending");
    assert_eq!(pending.status, DatabaseStatus::Pending);
    assert!(!pending.initial_free_grant_applied);
    let pending_summary = list_databases()
        .expect("database summaries should load")
        .into_iter()
        .find(|summary| summary.database_id == pending.database_id)
        .expect("pending database summary should exist");
    assert_eq!(pending_summary.status, DatabaseStatus::Pending);
    let pending_read = list_children(ListChildrenRequest {
        database_id: pending.database_id.clone(),
        path: "/Knowledge".to_string(),
    })
    .expect_err("second DB should reject reads until funded");
    assert!(pending_read.contains("database is pending"));

    set_next_ledger_transfer_from_outcome_for_test(LedgerTransferFromOutcome::Completed(42));
    block_on_ready(purchase_database_cycles(cycles_purchase_request(
        &pending.database_id,
        1_000_000,
    )))
    .expect("cycle purchase should activate database");
    let status = status(pending.database_id.clone());
    assert_eq!(status.file_count, 0);
    assert_eq!(status.source_count, 0);
    let children = list_children(ListChildrenRequest {
        database_id: pending.database_id,
        path: "/".to_string(),
    })
    .expect("activated database should list");
    assert!(children.iter().any(|child| {
        child.path == "/Skills" && child.kind == NodeEntryKind::Folder && !child.is_virtual
    }));
}

#[test]
fn create_database_rejects_pending_database_limit() {
    install_empty_test_service();
    let _caller = AuthenticatedCallerGuard::install();

    let free = create_database(CreateDatabaseRequest {
        name: "Free".to_string(),
    })
    .expect("initial free database should create active");

    for offset in 0..3 {
        create_database(CreateDatabaseRequest {
            name: format!("Pending {offset}"),
        })
        .expect("pending database should create within limit");
    }

    let error = create_database(CreateDatabaseRequest {
        name: "Pending 3".to_string(),
    })
    .expect_err("fourth pending database should reject");
    assert!(error.contains("too many pending databases for caller"));

    let summaries = list_databases().expect("database summaries should load");
    assert_eq!(summaries.len(), 4);
    assert!(summaries.iter().any(|summary| {
        summary.database_id == free.database_id && summary.status == DatabaseStatus::Active
    }));
    assert_eq!(
        summaries
            .iter()
            .filter(|summary| summary.status == DatabaseStatus::Pending)
            .count(),
        3
    );
}

#[test]
fn canister_update_database_metadata_requires_owner() {
    install_test_service();

    update_database_metadata(UpdateDatabaseMetadataRequest {
        database_id: "default".to_string(),
        name: "Renamed default".to_string(),
        description: "Updated description".to_string(),
        llm_summary: Some("Updated summary".to_string()),
        tags_json: "[\"updated\"]".to_string(),
    })
    .expect("owner should update database metadata");

    let summaries = list_databases().expect("database summaries should load");
    let metadata = summaries[0]
        .metadata
        .as_ref()
        .expect("database summary should include metadata");
    assert_eq!(metadata.name, "Renamed default");
    assert_eq!(metadata.description, "Updated description");
    assert_eq!(metadata.llm_summary.as_deref(), Some("Updated summary"));
    assert_eq!(metadata.tags_json, "[\"updated\"]");
}

#[test]
fn canister_rename_database_updates_name_only() {
    install_test_service();

    update_database_metadata(UpdateDatabaseMetadataRequest {
        database_id: "default".to_string(),
        name: "Before rename".to_string(),
        description: "Keep description".to_string(),
        llm_summary: Some("Keep summary".to_string()),
        tags_json: "[\"keep\"]".to_string(),
    })
    .expect("owner should seed database metadata");

    rename_database(RenameDatabaseRequest {
        database_id: "default".to_string(),
        name: "Renamed through old API".to_string(),
    })
    .expect("owner should rename database");

    let summaries = list_databases().expect("database summaries should load");
    let metadata = summaries[0]
        .metadata
        .as_ref()
        .expect("database summary should include metadata");
    assert_eq!(summaries[0].name, "Renamed through old API");
    assert_eq!(metadata.name, "Renamed through old API");
    assert_eq!(metadata.description, "Keep description");
    assert_eq!(metadata.llm_summary.as_deref(), Some("Keep summary"));
    assert_eq!(metadata.tags_json, "[\"keep\"]");
}

#[test]
fn grant_database_access_records_instruction_charge_and_grants_role() {
    install_test_service();
    set_update_charge_units_for_test(vec![100, 125]);
    let principal = Principal::self_authenticating([42]).to_text();

    grant_database_access(
        "default".to_string(),
        principal.clone(),
        DatabaseRole::Reader,
    )
    .expect("reader should grant");

    let entries = list_database_cycle_entries("default".to_string(), None, 20)
        .expect("database cycles ledger should load")
        .entries;
    let charge = entries
        .iter()
        .find(|entry| entry.kind == "charge")
        .expect("grant charge should record");
    assert_eq!(charge.method.as_deref(), Some("grant_database_access"));
    assert_eq!(charge.cycles_delta, Some(20_000_025));
    let members =
        list_database_members("default".to_string()).expect("database members should load");
    assert!(
        members
            .iter()
            .any(|member| member.principal == principal && member.role == DatabaseRole::Reader)
    );
}

#[test]
fn grant_database_access_rejects_invalid_principal() {
    install_test_service();

    let error = grant_database_access(
        "default".to_string(),
        "not a principal".to_string(),
        DatabaseRole::Reader,
    )
    .expect_err("invalid principal should fail");

    assert!(error.contains("invalid principal"));
    assert!(database_charge_methods("default").is_empty());
}

#[test]
fn grant_database_access_rejects_non_owner_without_charge() {
    install_test_service();

    {
        let _caller = AuthenticatedCallerGuard::install();
        let error = grant_database_access(
            "default".to_string(),
            "aaaaa-aa".to_string(),
            DatabaseRole::Reader,
        )
        .expect_err("non-owner grant should fail");
        assert!(error.contains("principal has no access"));
    }

    assert!(database_charge_methods("default").is_empty());
}

#[test]
fn grant_database_access_rejects_member_limit() {
    install_test_service();

    for index in 0..30 {
        grant_database_access(
            "default".to_string(),
            Principal::self_authenticating([index as u8]).to_text(),
            DatabaseRole::Reader,
        )
        .expect("member grant should fit limit");
    }

    let error = grant_database_access(
        "default".to_string(),
        Principal::self_authenticating([30]).to_text(),
        DatabaseRole::Reader,
    )
    .expect_err("member cap should reject new member");
    assert!(error.contains("too many database members"));
    assert_eq!(database_charge_methods("default").len(), 30);

    grant_database_access(
        "default".to_string(),
        Principal::self_authenticating([0]).to_text(),
        DatabaseRole::Writer,
    )
    .expect("existing member role update should remain allowed");
}

#[test]
fn revoke_database_access_validates_and_canonicalizes_principal() {
    install_test_service();

    let invalid = revoke_database_access("default".to_string(), "not a principal".to_string())
        .expect_err("invalid principal should fail");
    assert!(invalid.contains("invalid principal"));

    grant_database_access(
        "default".to_string(),
        "aaaaa-aa".to_string(),
        DatabaseRole::Reader,
    )
    .expect("valid principal should grant");
    revoke_database_access("default".to_string(), "aaaaa-aa".to_string())
        .expect("valid principal should revoke");
}

#[test]
fn delete_account_requires_authentication_and_is_retryable() {
    install_test_service();

    let error = delete_account().expect_err("anonymous caller should be rejected");
    assert!(error.contains("anonymous caller"));

    let _caller = AuthenticatedCallerGuard::install();
    delete_account().expect("authenticated empty account should delete");
    delete_account().expect("repeated account deletion should succeed");
}

#[test]
fn anonymous_reader_grant_allows_public_read() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("public", "owner", 1)
        .expect("database should create");
    service
        .grant_database_access("public", "owner", "2vxsx-fae", DatabaseRole::Reader, 2)
        .expect("anonymous reader should grant");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));

    let node = read_node("public".to_string(), "/Knowledge/missing.md".to_string())
        .expect("anonymous reader query should pass role check");

    assert_eq!(node, None);
    let members = list_database_members("public".to_string())
        .expect("anonymous reader should list public database members");
    assert!(
        members
            .iter()
            .any(|member| member.principal == "owner" && member.role == DatabaseRole::Owner)
    );
}

#[test]
fn status_stays_available_after_fs_migrations() {
    install_test_service();

    let current = status("default".to_string());

    assert_eq!(current.file_count, 0);
    assert_eq!(current.source_count, 0);
}

#[test]
fn store_entrypoints_return_four_store_contract() {
    install_test_service();

    let manifest = memory_manifest(MemoryManifestRequest {
        database_id: "default".to_string(),
    })
    .expect("store manifest should load default database");
    assert_eq!(manifest.api_version, "kinic-stores-v1");
    assert_eq!(manifest.write_policy, "stores_read_only");
    assert_eq!(manifest.recommended_entrypoint, "query_context");
    assert!(is_canister_method_entrypoint(
        &manifest.recommended_entrypoint
    ));
    assert!(!is_canister_method_entrypoint("skill inspect"));
    assert_eq!(manifest.max_depth, 2);
    assert_eq!(
        manifest.enabled_stores,
        vec!["memory", "knowledge", "skill", "session"]
    );
    assert_eq!(
        manifest
            .entry_roots
            .iter()
            .map(|root| (root.path.as_str(), root.kind.as_str()))
            .collect::<Vec<_>>(),
        vec![
            ("/Memory", "memory"),
            ("/Knowledge", "knowledge"),
            ("/Skills", "skill"),
            ("/Sessions", "session"),
        ]
    );
    assert!(manifest.purpose.contains("knowledge"));
    assert!(manifest.roots.iter().any(|root| root.path == "/Knowledge"));
    assert!(
        manifest
            .roots
            .iter()
            .any(|root| root.path == "/Sessions" && root.kind == "session")
    );
    assert!(
        manifest
            .roots
            .iter()
            .any(|root| root.path == "/Skills" && root.kind == "skill")
    );
    assert!(
        manifest
            .roots
            .iter()
            .any(|root| root.path == "/Sources" && root.kind == "source_evidence")
    );
    assert!(
        manifest
            .roots
            .iter()
            .any(|root| root.path == "/Sources/sessions" && root.kind == "session_evidence")
    );
    assert!(
        manifest
            .roots
            .iter()
            .any(|root| root.path == "/Sources/skill-runs" && root.kind == "skill_run_evidence")
    );
    assert!(
        manifest
            .canonical_roles
            .iter()
            .any(|role| role.name == "facts")
    );
    assert!(
        manifest
            .canonical_roles
            .iter()
            .any(|role| role.name == "open_questions")
    );

    for (path, content) in [
        (
            "/Knowledge/scope/index.md",
            "# Index\n\n[Overview](overview.md)",
        ),
        (
            "/Knowledge/scope/overview.md",
            "# Overview\n\nbeam memory [Raw](/Sources/a/a.md)",
        ),
        ("/Knowledge/scope/schema.md", "# Schema\n\nread-only"),
        (
            "/Knowledge/scope/provenance.md",
            "# Provenance\n\n[Raw](/Sources/a/a.md)",
        ),
        ("/Sources/a/a.md", "raw source"),
    ] {
        ensure_parent_folders(path);
        write_node(WriteNodeRequest {
            database_id: "default".to_string(),
            path: path.to_string(),
            kind: if path.starts_with("/Sources/") {
                NodeKind::Source
            } else {
                NodeKind::File
            },
            content: content.to_string(),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        })
        .expect("write should succeed");
    }

    let context = query_context(QueryContextRequest {
        database_id: "default".to_string(),
        task: "beam memory".to_string(),
        entities: Vec::new(),
        namespace: Some("/Knowledge/scope".to_string()),
        budget_tokens: 1_000,
        include_evidence: true,
        depth: 1,
    })
    .expect("memory recall should load");
    assert!(
        context
            .nodes
            .iter()
            .any(|node| node.node.path == "/Knowledge/scope/overview.md")
    );
    assert!(!context.evidence.is_empty());

    let evidence = source_evidence(SourceEvidenceRequest {
        database_id: "default".to_string(),
        node_path: "/Knowledge/scope/overview.md".to_string(),
    })
    .expect("evidence should load");
    assert!(
        evidence
            .refs
            .iter()
            .any(|item| item.source_path == "/Sources/a/a.md")
    );
    let source_ref = evidence
        .refs
        .iter()
        .find(|item| item.source_path == "/Sources/a/a.md")
        .expect("source evidence ref should exist");
    assert!(source_ref.source_etag.is_some());
    assert!(source_ref.source_updated_at.is_some());
}

fn is_canister_method_entrypoint(value: &str) -> bool {
    fn method_chars(value: &str) -> bool {
        !value.is_empty()
            && value
                .chars()
                .all(|c| c.is_ascii_lowercase() || c.is_ascii_digit() || c == '_')
    }

    let mut parts = value.splitn(2, ':');
    let method = parts.next().unwrap_or_default();
    if !method_chars(method) {
        return false;
    }
    parts.next().is_none_or(|path| path.starts_with('/'))
}

#[test]
fn retired_voice_methods_cannot_modify_or_reconcile_credits() {
    let retired = Err("voice retired".to_string());
    assert_eq!(
        super::configure_voice_rate(vfs_types::VoiceRate {
            version: 1,
            cycles_per_minute: 60,
            authority: "authority".into(),
        }),
        retired
    );
    assert_eq!(super::get_voice_rate().unwrap_err(), "voice retired");
    assert_eq!(
        super::initialize_voice_policy("db".into()).unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::get_voice_access("db".into(), "owner".into()).unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::set_voice_policy(vfs_types::VoicePolicy {
            database_id: "db".into(),
            principal: "owner".into(),
            enabled: true,
            daily_budget_cycles: 600,
        }),
        retired
    );
    assert_eq!(
        super::get_voice_policy("db".into(), "owner".into()).unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::reserve_voice(vfs_types::VoiceReserveRequest {
            session_id: "session".into(),
            database_id: "db".into(),
            principal: "owner".into(),
            rate_version: 1,
            reserved_seconds: 60,
        })
        .unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::settle_voice(vfs_types::VoiceSettleRequest {
            session_id: "session".into(),
            confirmed_seconds: 7,
            close: true
        })
        .unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::stop_voice(vfs_types::VoiceStopRequest {
            session_id: "session".into(),
            final_seconds: 7
        })
        .unwrap_err(),
        "voice retired"
    );
    assert_eq!(
        super::get_voice_reservation("session".into()).unwrap_err(),
        "voice retired"
    );
}

#[test]
fn writer_cannot_begin_step_activate_or_read_private_rebuild_status() {
    install_test_service();
    let writer = Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").unwrap();
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .unwrap()
            .grant_database_access(
                "default",
                "2vxsx-fae",
                &writer.to_text(),
                DatabaseRole::Writer,
                1,
            )
            .unwrap()
    });
    set_test_caller_principal_for_test(writer);
    let r = vfs_types::EvidenceRebuildRequest {
        database_id: "default".into(),
        expected_source_mount: 11,
        expected_schema: "vfs_store:005_evidence_storage".into(),
    };
    assert!(
        super::evidence_rebuild_begin(r)
            .unwrap_err()
            .contains("controller")
    );
    assert!(
        super::evidence_rebuild_status(vfs_types::DatabaseIdRequest {
            database_id: "default".into()
        })
        .unwrap_err()
        .contains("controller")
    );
    let step = vfs_types::EvidenceRebuildStepRequest {
        database_id: "default".into(),
        migration_id: "not-authorized".into(),
        expected_step: 0,
        max_rows: 3,
        max_bytes: 65536,
    };
    assert!(
        super::evidence_rebuild_step(step.clone())
            .unwrap_err()
            .contains("controller")
    );
    assert!(
        super::evidence_rebuild_verify(step)
            .unwrap_err()
            .contains("controller")
    );
    let control = vfs_types::EvidenceRebuildControlRequest {
        database_id: "default".into(),
        migration_id: "not-authorized".into(),
        expected_state_hash: "not-authorized".into(),
    };
    assert!(
        super::evidence_rebuild_activate(control.clone())
            .unwrap_err()
            .contains("controller")
    );
    assert!(
        super::evidence_rebuild_rollback(control.clone())
            .unwrap_err()
            .contains("controller")
    );
    assert!(
        super::evidence_rebuild_resume_writes(control)
            .unwrap_err()
            .contains("controller")
    );
}

#[test]
fn controller_gate_does_not_charge_rejected_writer_update() {
    install_test_service();
    let writer = Principal::from_text("r7inp-6aaaa-aaaaa-aaabq-cai").unwrap();
    SERVICE.with(|slot| {
        slot.borrow()
            .as_ref()
            .unwrap()
            .grant_database_access(
                "default",
                "2vxsx-fae",
                &writer.to_text(),
                DatabaseRole::Writer,
                1,
            )
            .unwrap()
    });
    let balance = || {
        SERVICE.with(|slot| {
            slot.borrow()
                .as_ref()
                .unwrap()
                .list_database_summaries_for_caller("2vxsx-fae")
                .unwrap()
                .into_iter()
                .find(|d| d.database_id == "default")
                .unwrap()
                .cycles_balance
        })
    };
    let before = balance();
    set_test_caller_principal_for_test(Principal::management_canister());
    let idle = super::evidence_rebuild_status(vfs_types::DatabaseIdRequest {
        database_id: "default".into(),
    })
    .unwrap();
    super::evidence_rebuild_begin(vfs_types::EvidenceRebuildRequest {
        database_id: "default".into(),
        expected_source_mount: idle.source_mount,
        expected_schema: idle.source_schema,
    })
    .unwrap();
    set_test_caller_principal_for_test(writer);
    assert!(
        write_node(WriteNodeRequest {
            database_id: "default".into(),
            path: "/Knowledge/rejected.md".into(),
            kind: NodeKind::File,
            content: "must not commit".into(),
            metadata_json: "{}".into(),
            expected_etag: None
        })
        .is_err()
    );
    assert_eq!(balance(), before);
}

#[test]
fn bekko_refill_endpoints_require_controller_and_start_disabled() {
    use super::bekko_refill::{check_bekko_refill, configure_bekko_refill, get_bekko_refill_state};
    use vfs_types::BekkoRefillConfig;
    install_test_service();
    super::with_service(|svc| svc.initialize_bekko_refill(0)).unwrap();
    set_test_caller_principal_for_test(Principal::anonymous());
    assert!(get_bekko_refill_state().is_err());
    assert!(configure_bekko_refill(BekkoRefillConfig::default()).is_err());
    assert!(block_on_ready(check_bekko_refill()).is_err());
    set_test_caller_principal_for_test(Principal::management_canister());
    assert!(!get_bekko_refill_state().unwrap().config.enabled);
    assert!(
        block_on_ready(check_bekko_refill())
            .unwrap()
            .active
            .is_none()
    );
}

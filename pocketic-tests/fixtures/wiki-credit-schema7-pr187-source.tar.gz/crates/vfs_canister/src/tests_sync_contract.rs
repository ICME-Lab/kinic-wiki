// Where: crates/vfs_canister/src/tests_sync_contract.rs
// What: Additional entry-point tests for search/sync behavior and Candid contract integrity.
// Why: The VFS validation phase needs API-boundary coverage for behavior and interface drift.
use tempfile::tempdir;
use vfs_runtime::VfsService;
use vfs_types::{
    DeleteNodeRequest, ExportSnapshotRequest, FetchUpdatesRequest, MkdirNodeRequest, NodeKind,
    SearchNodePathsRequest, SearchNodesRequest, SearchPreviewMode, WriteNodeRequest,
};

use super::{
    HttpRequest, ICP_CLI_LOGIN_DISCOVERY_PATH, ICP_CLI_LOGIN_PATH, II_ALTERNATIVE_ORIGINS_PATH,
    II_APP_LOGO, II_APP_LOGO_PATH, II_APP_METADATA_BODY, II_APP_METADATA_PATH,
    II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY, II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY,
    II_STAGING_EXTENSION_ORIGIN, SERVICE, delete_node, export_snapshot, fetch_updates,
    http_request, mkdir_node, search_node_paths, search_nodes, staging_ii_alternative_origins_body,
    write_node,
};
use ic_http_certification::CERTIFICATE_EXPRESSION_HEADER_NAME;

const TEST_CYCLE_PURCHASE_E8S: u64 = 10_000_000;
const TEST_CYCLE_PURCHASE_CYCLES: u64 = 23_450_000_000;

fn install_test_service() {
    let dir = tempdir().expect("tempdir should create");
    let root = dir.keep();
    let service = VfsService::new(root.join("index.sqlite3"), root.join("databases"));
    service
        .run_index_migrations()
        .expect("index migrations should run");
    service
        .create_database("default", "2vxsx-fae", 1_700_000_000_000)
        .expect("default database should create");
    service
        .begin_database_cycles_purchase(
            "default",
            "2vxsx-fae",
            TEST_CYCLE_PURCHASE_E8S,
            1_700_000_000_001,
        )
        .and_then(|operation_id| {
            service.complete_database_cycles_purchase_ledger_transfer(
                operation_id,
                "default",
                "2vxsx-fae",
                TEST_CYCLE_PURCHASE_CYCLES,
                1,
            )?;
            service.apply_database_cycles_purchase(
                operation_id,
                "default",
                "2vxsx-fae",
                TEST_CYCLE_PURCHASE_CYCLES,
                1,
                1_700_000_000_001,
            )
        })
        .expect("default database should have write cycles available");
    SERVICE.with(|slot| *slot.borrow_mut() = Some(service));
}

fn ensure_parent_folders(path: &str) {
    let segments = path
        .split('/')
        .filter(|segment| !segment.is_empty())
        .collect::<Vec<_>>();
    let mut current = String::new();
    for segment in segments.iter().take(segments.len().saturating_sub(1)) {
        current.push('/');
        current.push_str(segment);
        mkdir_node(MkdirNodeRequest {
            database_id: "default".to_string(),
            path: current.clone(),
        })
        .expect("parent folder should exist or be created");
    }
}

#[test]
fn http_request_serves_certified_ii_alternative_origins() {
    let response = http_request(test_http_get(II_ALTERNATIVE_ORIGINS_PATH));

    assert_eq!(response.status_code, 200);
    let body = String::from_utf8(response.body).expect("body should be utf8");
    assert!(body.contains(r#""alternativeOrigins""#));
    assert!(body.contains("https://wiki.kinic.xyz"));
    assert!(body.contains("https://kinic.xyz"));
    assert!(body.contains("chrome-extension://jcfniiflikojmbfnaoamlbbddlikchaj"));
    assert!(body.contains("chrome-extension://hbnicbmdodpmihmcnfgejcdgbfmemoci"));
    assert!(body.contains("chrome-extension://moebdnadaffhlddnhifmmdoecifhcbdi"));

    let headers = response.headers;
    assert!(headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Content-Type") && value == "application/json; charset=utf-8"
    }));
    assert!(
        headers
            .iter()
            .any(|(name, _)| { name.eq_ignore_ascii_case(CERTIFICATE_EXPRESSION_HEADER_NAME) })
    );
}

#[test]
fn production_ii_alternative_origins_do_not_include_localhost() {
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3000"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3000"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3010"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3010"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3100"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3100"));
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains(&removed_ios_local_origin()));
}

#[test]
fn http_request_serves_certified_ii_app_metadata() {
    let response = http_request(test_http_get(II_APP_METADATA_PATH));

    assert_eq!(response.status_code, 200);
    assert_eq!(
        String::from_utf8(response.body).expect("body should be utf8"),
        II_APP_METADATA_BODY
    );
    assert!(II_APP_METADATA_BODY.contains(r#""name":"Kinic Wiki""#));
    assert!(II_APP_METADATA_BODY.contains(II_APP_LOGO_PATH));
    assert!(response.headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Content-Type") && value == "application/json; charset=utf-8"
    }));
    assert!(response.headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Access-Control-Allow-Origin") && value == "*"
    }));
    assert!(
        response
            .headers
            .iter()
            .any(|(name, _)| { name.eq_ignore_ascii_case(CERTIFICATE_EXPRESSION_HEADER_NAME) })
    );
}

#[test]
fn http_request_serves_certified_ii_app_logo() {
    let response = http_request(test_http_get(II_APP_LOGO_PATH));

    assert_eq!(response.status_code, 200);
    assert_eq!(response.body, II_APP_LOGO);
    assert!(response.headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Content-Type") && value == "image/png"
    }));
    assert!(response.headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Access-Control-Allow-Origin") && value == "*"
    }));
    assert!(
        response
            .headers
            .iter()
            .any(|(name, _)| { name.eq_ignore_ascii_case(CERTIFICATE_EXPRESSION_HEADER_NAME) })
    );
}

#[test]
fn staging_ii_alternative_origins_adds_only_the_staging_frontends() {
    let body = staging_ii_alternative_origins_body(
        "https://kinic-wiki-browser-staging.example.workers.dev",
    );
    assert!(body.contains("https://wiki.kinic.xyz"));
    assert!(body.contains("https://kinic-wiki-browser-staging.example.workers.dev"));
    assert!(body.contains(II_STAGING_EXTENSION_ORIGIN));
    assert_eq!(body.matches(II_STAGING_EXTENSION_ORIGIN).count(), 1);
    assert!(!II_PRODUCTION_ALTERNATIVE_ORIGINS_BODY.contains(II_STAGING_EXTENSION_ORIGIN));
    assert_eq!(
        body.matches("://").count(),
        7,
        "Internet Identity rejects ii-alternative-origins with more than 10 entries"
    );
}

#[test]
fn local_dev_ii_alternative_origins_include_fixed_dev_server_origins() {
    assert!(!II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3000"));
    assert!(II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3000"));
    assert!(II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3010"));
    assert!(II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3010"));
    assert!(II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://127.0.0.1:3100"));
    assert!(!II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains("http://localhost:3100"));
    assert!(!II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.contains(&removed_ios_local_origin()));
    assert_eq!(
        II_LOCAL_DEV_ALTERNATIVE_ORIGINS_BODY.matches("://").count(),
        9,
        "Internet Identity rejects ii-alternative-origins with more than 10 entries"
    );
}

fn removed_ios_local_origin() -> String {
    ["https://ios", "-local.kinic.xyz"].concat()
}

#[test]
fn http_request_serves_icp_cli_login_discovery() {
    let response = http_request(test_http_get(ICP_CLI_LOGIN_DISCOVERY_PATH));

    assert_eq!(response.status_code, 200);
    assert_eq!(
        String::from_utf8(response.body).expect("body should be utf8"),
        ICP_CLI_LOGIN_PATH
    );
    let headers = response.headers;
    assert!(headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Content-Type") && value == "text/plain; charset=utf-8"
    }));
    assert!(
        headers
            .iter()
            .any(|(name, _)| { name.eq_ignore_ascii_case(CERTIFICATE_EXPRESSION_HEADER_NAME) })
    );
}

#[test]
fn http_request_serves_icp_cli_login_page() {
    let response = http_request(test_http_get(ICP_CLI_LOGIN_PATH));

    assert_eq!(response.status_code, 200);
    let body = String::from_utf8(response.body).expect("body should be utf8");
    let compact_body = body
        .chars()
        .filter(|character| !character.is_whitespace())
        .collect::<String>();
    assert!(body.contains("<h1>CLI login</h1>"));
    assert!(body.contains("Delegation recipient"));
    assert!(body.contains("Local CLI callback"));
    assert!(body.contains("Callback host/port"));
    assert!(body.contains("Derivation origin"));
    assert!(body.contains("Delegation TTL"));
    assert!(body.contains("https://id.ai"));
    assert!(!body.contains("http://id.ai.localhost:"));
    assert!(body.contains("https://6emaw-iyaaa-aaaay-aacka-cai.icp0.io"));
    assert!(compact_body.contains("endsWith(\".localhost\")"));
    assert!(compact_body.contains("derivationOrigin:"));
    assert!(compact_body.contains(r#"method:"POST""#));
    assert!(compact_body.contains(r#""content-type":"application/json""#));
    assert!(compact_body.contains("redirect:\"error\""));
    assert!(body.contains("CLI login complete."));
    assert!(!body.contains("https://esm.sh/"));
    assert!(!body.contains(r#"<script type="module">"#));
    let headers = response.headers;
    assert!(headers.iter().any(|(name, value)| {
        name.eq_ignore_ascii_case("Content-Type") && value == "text/html; charset=utf-8"
    }));
    assert!(
        headers
            .iter()
            .any(|(name, _)| { name.eq_ignore_ascii_case(CERTIFICATE_EXPRESSION_HEADER_NAME) })
    );
}

#[test]
fn http_request_rejects_unknown_paths() {
    let response = http_request(test_http_get("/not-found"));

    assert_eq!(response.status_code, 404);
}

fn test_http_get(url: &str) -> HttpRequest {
    HttpRequest {
        method: "GET".to_string(),
        url: url.to_string(),
        headers: Vec::new(),
        body: Vec::new(),
        certificate_version: Some(2),
    }
}

#[test]
fn public_http_certifies_fresh_bounded_payload_and_invalidates_after_write() {
    install_test_service();
    super::public_http::reset();
    ensure_parent_folders("/Knowledge/public.md");
    let write = |content: String| {
        write_node(WriteNodeRequest {
            database_id: "default".into(),
            path: "/Knowledge/public.md".into(),
            kind: NodeKind::File,
            content,
            metadata_json: "{}".into(),
            expected_etag: super::read_node("default".into(), "/Knowledge/public.md".into())
                .unwrap()
                .map(|node| node.etag),
        })
        .expect("write succeeds")
    };
    write(format!("# Original\n{}TAILSENTINEL", "あ".repeat(20_000)));
    let url = "/api/wiki-seo/default/Knowledge/public.md";
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(true));
    let registered = super::http_request_update(test_http_get(url));
    assert_eq!(registered.status_code, 200);
    assert_eq!(registered.upgrade, Some(false));
    assert!(
        registered
            .headers
            .iter()
            .any(|(key, value)| key == "Cache-Control" && value == "no-store")
    );
    let json: serde_json::Value = serde_json::from_slice(&registered.body).unwrap();
    assert_eq!(
        json["node"]["content"].as_str().unwrap().chars().count(),
        16_000
    );
    assert!(
        !String::from_utf8(registered.body.clone())
            .unwrap()
            .contains("TAILSENTINEL")
    );
    assert_eq!(http_request(test_http_get(url)).body, registered.body);
    let old_root = super::certified_http_tree().root_hash();
    // A second URL must coexist with the first proof.
    super::http_request_update(test_http_get("/api/wiki-seo/default/Knowledge"));
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(false));
    write("# Changed\nNew body".into());
    assert_ne!(old_root, super::certified_http_tree().root_hash());
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(true));
    let new = super::http_request_update(test_http_get(url));
    assert!(String::from_utf8(new.body).unwrap().contains("New body"));
    // Upgrade starts with no derived proofs; canonical content remains readable.
    super::public_http::reset();
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(true));
    assert!(
        String::from_utf8(super::http_request_update(test_http_get(url)).body)
            .unwrap()
            .contains("New body")
    );
}

#[test]
fn public_http_preserves_proofs_for_failed_auth_unrelated_updates_and_other_databases() {
    install_test_service();
    super::public_http::reset();
    let url = "/api/wiki-seo/default/Knowledge";
    super::http_request_update(test_http_get(url));
    let root = super::certified_http_tree().root_hash();
    assert_eq!(
        super::get_voice_reservation("retired".into()).unwrap_err(),
        "voice retired"
    );
    assert_eq!(root, super::certified_http_tree().root_hash());
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(false));

    // A rejected authorization must not change the certified root.
    super::set_test_caller_principal_for_test(candid::Principal::management_canister());
    assert!(super::revoke_database_access("default".into(), "2vxsx-fae".into()).is_err());
    assert!(
        write_node(WriteNodeRequest {
            database_id: "default".into(),
            path: "/Knowledge/denied.md".into(),
            kind: NodeKind::File,
            content: "Denied".into(),
            metadata_json: "{}".into(),
            expected_etag: None,
        })
        .is_err()
    );
    super::set_test_caller_principal_for_test(candid::Principal::anonymous());
    assert_eq!(root, super::certified_http_tree().root_hash());

    super::with_service(|service| service.create_database("other", "2vxsx-fae", 1)).unwrap();
    let other_url = "/api/wiki-seo/other/Knowledge";
    super::http_request_update(test_http_get(other_url));
    super::rename_database(vfs_types::RenameDatabaseRequest {
        database_id: "other".into(),
        name: "Renamed".into(),
    })
    .unwrap();
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(false));
    assert_eq!(http_request(test_http_get(other_url)).upgrade, Some(true));
}

#[test]
fn public_http_fits_escaped_unicode_and_long_child_links_without_losing_the_article() {
    install_test_service();
    super::public_http::reset();
    ensure_parent_folders("/Knowledge/wide/overview.md");
    let metadata = serde_json::json!({
        "title": "Article title", "metadata": {"description": "Description 😀".repeat(10_000)},
        "unused": "x".repeat(20_000)
    })
    .to_string();
    write_node(WriteNodeRequest {
        database_id: "default".into(),
        path: "/Knowledge/wide/overview.md".into(),
        kind: NodeKind::File,
        content: format!("# Article\n{}", "😀\u{1}\\\"".repeat(10_000)),
        metadata_json: metadata,
        expected_etag: None,
    })
    .unwrap();
    for index in 0..100 {
        write_node(WriteNodeRequest {
            database_id: "default".into(),
            path: format!("/Knowledge/wide/{index:03}-{}.md", "長".repeat(240)),
            kind: NodeKind::File,
            content: "Child".into(),
            metadata_json: "{}".into(),
            expected_etag: None,
        })
        .unwrap();
    }
    let response =
        super::http_request_update(test_http_get("/api/wiki-seo/default/Knowledge/wide"));
    assert_eq!(response.status_code, 200);
    assert!(response.body.len() <= 128_000);
    let payload: serde_json::Value = serde_json::from_slice(&response.body).unwrap();
    assert!(
        payload["node"]["content"]
            .as_str()
            .unwrap()
            .starts_with("# Article")
    );
    let metadata: serde_json::Value =
        serde_json::from_str(payload["node"]["metadataJson"].as_str().unwrap()).unwrap();
    assert_eq!(metadata["title"], "Article title");
    assert!(metadata.get("unused").is_none());
    assert_eq!(payload["childrenTruncated"], true);
    let links = payload["children"].as_array().unwrap();
    assert!(!links.is_empty() && links.len() < 100);
    for link in links {
        assert!(
            super::read_node("default".into(), link["path"].as_str().unwrap().into())
                .unwrap()
                .is_some()
        );
        assert!(link["name"].as_str().unwrap().ends_with(".md"));
    }
}

#[test]
fn public_http_never_uses_gateway_caller_authority_and_revocation_removes_proof() {
    install_test_service();
    super::public_http::reset();
    let owner = "owner-principal";
    super::with_service(|service| {
        service.create_database("private_http", owner, 1)?;
        Ok(())
    })
    .unwrap();
    let url = "/api/wiki-seo/private_http/Knowledge";
    assert_eq!(
        super::http_request_update(test_http_get(url)).status_code,
        404
    );
    super::with_unmetered_update("test_grant", None, |service, _, _| {
        service.grant_database_access(
            "private_http",
            owner,
            "2vxsx-fae",
            vfs_types::DatabaseRole::Reader,
            2,
        )
    })
    .unwrap();
    assert_eq!(http_request(test_http_get(url)).upgrade, Some(true));
    assert_eq!(
        super::http_request_update(test_http_get(url)).status_code,
        200
    );
    super::with_unmetered_update("test_revoke", None, |service, _, _| {
        service.revoke_database_access("private_http", owner, "2vxsx-fae")
    })
    .unwrap();
    assert_eq!(
        super::http_request_update(test_http_get(url)).status_code,
        404
    );
    assert_eq!(http_request(test_http_get(url)).status_code, 404);
}

#[test]
fn public_http_rejects_malformed_paths_and_preserves_static_certificates() {
    install_test_service();
    super::public_http::reset();
    for path in [
        "/api/wiki-seo/default/%GG",
        "/api/wiki-seo/default/%FF",
        "/api/wiki-seo/default/Knowledge/%2e%2e/private",
        "/api/wiki-seo/default/Knowledge/%00",
    ] {
        assert_eq!(http_request(test_http_get(path)).status_code, 400);
    }
    super::http_request_update(test_http_get("/api/wiki-seo/default/Knowledge"));
    let static_response = http_request(test_http_get(II_APP_METADATA_PATH));
    assert_eq!(static_response.status_code, 200);
    assert!(
        static_response
            .headers
            .iter()
            .any(|(name, _)| name == CERTIFICATE_EXPRESSION_HEADER_NAME)
    );
}

#[test]
fn canister_search_respects_prefix_and_hides_deleted_nodes() {
    install_test_service();

    ensure_parent_folders("/Knowledge/project-alpha/one.md");
    ensure_parent_folders("/Knowledge/project-beta/two.md");
    let alpha = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/project-alpha/one.md".to_string(),
        kind: NodeKind::File,
        content: "alpha shared term".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("alpha write should succeed");
    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/project-beta/two.md".to_string(),
        kind: NodeKind::File,
        content: "beta shared term".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("beta write should succeed");

    delete_node(DeleteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/project-alpha/one.md".to_string(),
        expected_etag: Some(alpha.node.etag),
        expected_folder_index_etag: None,
    })
    .expect("delete should succeed");

    let hits = search_nodes(SearchNodesRequest {
        database_id: "default".to_string(),
        query_text: "shared".to_string(),
        prefix: Some("/Knowledge/project-alpha".to_string()),
        top_k: 10,
        preview_mode: Some(SearchPreviewMode::None),
    })
    .expect("search should succeed");
    assert!(hits.is_empty());

    let beta_hits = search_nodes(SearchNodesRequest {
        database_id: "default".to_string(),
        query_text: "shared".to_string(),
        prefix: Some("/Knowledge/project-beta".to_string()),
        top_k: 10,
        preview_mode: Some(SearchPreviewMode::None),
    })
    .expect("search should succeed");
    assert_eq!(beta_hits.len(), 1);
    assert_eq!(beta_hits[0].path, "/Knowledge/project-beta/two.md");

    let path_hits = search_node_paths(SearchNodePathsRequest {
        database_id: "default".to_string(),
        query_text: "PROJECT-beta".to_string(),
        prefix: Some("/Knowledge".to_string()),
        top_k: 10,
        preview_mode: None,
    })
    .expect("path search should succeed");
    assert!(
        path_hits
            .iter()
            .any(|hit| hit.path == "/Knowledge/project-beta/two.md")
    );
}

#[test]
fn canister_fetch_updates_reports_removed_paths_after_delete() {
    install_test_service();

    ensure_parent_folders("/Knowledge/scope/item.md");
    let created = write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/scope/item.md".to_string(),
        kind: NodeKind::File,
        content: "scope body".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("write should succeed");

    let snapshot = export_snapshot(ExportSnapshotRequest {
        database_id: "default".to_string(),
        prefix: Some("/Knowledge/scope".to_string()),
        limit: 100,
        cursor: None,
        snapshot_revision: None,
        snapshot_session_id: None,
    })
    .expect("snapshot should succeed");

    delete_node(DeleteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/scope/item.md".to_string(),
        expected_etag: Some(created.node.etag),
        expected_folder_index_etag: None,
    })
    .expect("delete should succeed");

    let updates = fetch_updates(FetchUpdatesRequest {
        database_id: "default".to_string(),
        known_snapshot_revision: snapshot.snapshot_revision,
        prefix: Some("/Knowledge/scope".to_string()),
        limit: 100,
        cursor: None,
        target_snapshot_revision: None,
    })
    .expect("updates should succeed");
    assert!(updates.changed_nodes.is_empty());
    assert_eq!(
        updates.removed_paths,
        vec!["/Knowledge/scope/item.md".to_string()]
    );
}

#[test]
fn canister_fetch_updates_rejects_prefix_scope_changes() {
    install_test_service();

    ensure_parent_folders("/Knowledge/a/one.md");
    ensure_parent_folders("/Knowledge/b/two.md");
    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/a/one.md".to_string(),
        kind: NodeKind::File,
        content: "alpha".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("write should succeed");
    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/b/two.md".to_string(),
        kind: NodeKind::File,
        content: "beta".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("write should succeed");

    let narrow = export_snapshot(ExportSnapshotRequest {
        database_id: "default".to_string(),
        prefix: Some("/Knowledge/a".to_string()),
        limit: 100,
        cursor: None,
        snapshot_revision: None,
        snapshot_session_id: None,
    })
    .expect("snapshot should succeed");
    let widened = fetch_updates(FetchUpdatesRequest {
        database_id: "default".to_string(),
        known_snapshot_revision: narrow.snapshot_revision,
        prefix: Some("/Knowledge".to_string()),
        limit: 100,
        cursor: None,
        target_snapshot_revision: None,
    });
    assert_eq!(
        widened.expect_err("prefix scope change should fail"),
        "known_snapshot_revision prefix does not match request prefix"
    );
}

#[test]
fn canister_fetch_updates_returns_delta_from_old_retained_revision() {
    install_test_service();

    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/base.md".to_string(),
        kind: NodeKind::File,
        content: "base".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("base write should succeed");
    write_node(WriteNodeRequest {
        database_id: "default".to_string(),
        path: "/Knowledge/unchanged.md".to_string(),
        kind: NodeKind::File,
        content: "unchanged".to_string(),
        metadata_json: "{}".to_string(),
        expected_etag: None,
    })
    .expect("unchanged write should succeed");

    let base = export_snapshot(ExportSnapshotRequest {
        database_id: "default".to_string(),
        prefix: Some("/Knowledge".to_string()),
        limit: 100,
        cursor: None,
        snapshot_revision: None,
        snapshot_session_id: None,
    })
    .expect("snapshot should succeed");

    for index in 0..300 {
        write_node(WriteNodeRequest {
            database_id: "default".to_string(),
            path: format!("/Knowledge/history-{index}.md"),
            kind: NodeKind::File,
            content: format!("revision {index}"),
            metadata_json: "{}".to_string(),
            expected_etag: None,
        })
        .expect("history write should succeed");
    }

    let first = fetch_updates(FetchUpdatesRequest {
        database_id: "default".to_string(),
        known_snapshot_revision: base.snapshot_revision.clone(),
        prefix: Some("/Knowledge".to_string()),
        limit: 100,
        cursor: None,
        target_snapshot_revision: None,
    })
    .expect("first old snapshot delta page should succeed");
    let second = fetch_updates(FetchUpdatesRequest {
        database_id: "default".to_string(),
        known_snapshot_revision: base.snapshot_revision.clone(),
        prefix: Some("/Knowledge".to_string()),
        limit: 100,
        cursor: first.next_cursor.clone(),
        target_snapshot_revision: Some(first.snapshot_revision.clone()),
    })
    .expect("second old snapshot delta page should succeed");
    let third = fetch_updates(FetchUpdatesRequest {
        database_id: "default".to_string(),
        known_snapshot_revision: base.snapshot_revision,
        prefix: Some("/Knowledge".to_string()),
        limit: 100,
        cursor: second.next_cursor.clone(),
        target_snapshot_revision: Some(first.snapshot_revision.clone()),
    })
    .expect("third old snapshot delta page should succeed");
    let updates = [first, second, third]
        .into_iter()
        .flat_map(|page| page.changed_nodes)
        .collect::<Vec<_>>();

    assert_eq!(updates.len(), 300);
    assert!(
        !updates
            .iter()
            .any(|node| node.path == "/Knowledge/unchanged.md")
    );
    assert!(
        updates
            .iter()
            .all(|node| node.path.starts_with("/Knowledge/history-"))
    );
}

#[test]
fn exported_candid_matches_checked_in_vfs_did() {
    assert_eq!(
        super::candid_interface().trim_end(),
        include_str!("../vfs.did").trim_end()
    );
}

#[test]
fn api_doc_is_discoverable_as_an_anonymous_query() {
    // No service initialization or caller identity: the guide is static and public.
    let doc = super::get_api_doc();
    assert!(doc.starts_with("# Kinic Wiki API"));
    for method in [
        "list_databases",
        "search_nodes",
        "list_nodes",
        "read_nodes",
        "query_context",
        "memory_manifest",
        "write_nodes",
        "mutate_nodes_batch",
    ] {
        assert!(doc.contains(method), "missing usage guidance for {method}");
    }
    assert!(doc.contains("expected_etag"));
    assert!(doc.contains("milliseconds"));
    assert!(doc.contains("10^8"));
    assert!(doc.contains("Questions only"));
    assert!(super::candid_interface().contains("get_api_doc : () -> (text) query;"));
}

#[test]
fn abandoned_source_capture_queries_are_not_public() {
    let generated = super::candid_interface();
    let checked_in = include_str!("../vfs.did");

    for method in [
        "list_my_source_capture_requests",
        "get_my_source_capture_url_state",
        "list_recoverable_source_capture_requests",
    ] {
        assert!(
            !generated.contains(method),
            "generated Candid exposes {method}"
        );
        assert!(
            !checked_in.contains(method),
            "checked-in Candid exposes {method}"
        );
    }
}

#[test]
fn mkdir_node_request_type_is_fixed_at_interface_boundary() {
    let generated = super::candid_interface();
    let checked_in = include_str!("../vfs.did");

    for did in [generated.as_str(), checked_in] {
        assert!(
            did.contains("type MkdirNodeRequest = record { path : text; database_id : text };"),
            "mkdir_node request type must stay nominal in the public interface",
        );
        assert!(
            did.contains("type ListChildrenRequest = record { path : text; database_id : text };"),
            "list_children request type must stay nominal in the public interface",
        );
        assert!(
            did.contains("has_children : bool;"),
            "ChildNode must expose descendant state",
        );
        assert!(
            has_query_method_input(did, "list_children", "ListChildrenRequest"),
            "list_children must consume ListChildrenRequest at the interface boundary",
        );
        assert!(
            has_method_input(did, "mkdir_node", "MkdirNodeRequest"),
            "mkdir_node must consume MkdirNodeRequest at the interface boundary",
        );
        assert!(
            has_method_input(
                did,
                "authorize_source_capture_trigger_session",
                "SourceCaptureTriggerSessionRequest"
            ),
            "authorize_source_capture_trigger_session must consume SourceCaptureTriggerSessionRequest",
        );
        assert!(
            has_query_method_input(did, "outgoing_links", "OutgoingLinksRequest"),
            "outgoing_links must consume OutgoingLinksRequest at the interface boundary",
        );
        assert!(
            !has_query_method_input(did, "list_children", "DeleteNodeResult"),
            "list_children must not collapse to DeleteNodeResult",
        );
        assert!(
            !has_query_method_input(did, "mkdir_node", "DeleteNodeResult"),
            "mkdir_node must not collapse to DeleteNodeResult",
        );
        assert!(
            !has_query_method_input(did, "outgoing_links", "IncomingLinksRequest"),
            "outgoing_links must not collapse to IncomingLinksRequest",
        );
        assert!(
            !did.contains("recent_changes :"),
            "recent_changes should not be part of agent memory v1",
        );
        assert!(
            !did.contains("memory_summary :"),
            "memory_summary should not be part of agent memory v1",
        );
    }
}

fn has_query_method_input(did: &str, method: &str, input: &str) -> bool {
    let prefix = format!("  {method} : ({input}) -> (");
    did.lines()
        .any(|line| line.starts_with(&prefix) && line.ends_with(" query;"))
}

fn has_method_input(did: &str, method: &str, input: &str) -> bool {
    let prefix = format!("  {method} : ({input}) -> (");
    did.lines().any(|line| line.starts_with(&prefix))
}

#[test]
fn public_folder_seo_uses_overview_and_keeps_catalogs_explicitly_readable() {
    install_test_service();
    super::public_http::reset();
    ensure_parent_folders("/Knowledge/catalog-check/index.md");
    for (name, content) in [
        ("index.md", "# Agent catalog\nCATALOG_SENTINEL"),
        ("article.md", "# Article\nReader content"),
    ] {
        write_node(WriteNodeRequest {
            database_id: "default".into(),
            path: format!("/Knowledge/catalog-check/{name}"),
            kind: NodeKind::File,
            content: content.into(),
            metadata_json: "{}".into(),
            expected_etag: None,
        })
        .unwrap();
    }
    let url = "/api/wiki-seo/default/Knowledge/catalog-check";
    let response = super::http_request_update(test_http_get(url));
    let payload: serde_json::Value = serde_json::from_slice(&response.body).unwrap();
    assert!(payload["node"].is_null());
    assert!(
        payload["children"]
            .as_array()
            .unwrap()
            .iter()
            .any(|child| child["name"] == "article.md")
    );
    assert!(!String::from_utf8_lossy(&response.body).contains("CATALOG_SENTINEL"));
    write_node(WriteNodeRequest {
        database_id: "default".into(),
        path: "/Knowledge/catalog-check/overview.md".into(),
        kind: NodeKind::File,
        content: "# Reader description".into(),
        metadata_json: "{}".into(),
        expected_etag: None,
    })
    .unwrap();
    let response = super::http_request_update(test_http_get(url));
    let payload: serde_json::Value = serde_json::from_slice(&response.body).unwrap();
    assert_eq!(payload["node"]["content"], "# Reader description");
    let response = super::http_request_update(test_http_get(
        "/api/wiki-seo/default/Knowledge/catalog-check/index.md",
    ));
    let payload: serde_json::Value = serde_json::from_slice(&response.body).unwrap();
    assert!(
        payload["node"]["content"]
            .as_str()
            .unwrap()
            .contains("CATALOG_SENTINEL")
    );
}

var e = Object.defineProperty, t = (t, n) => {
	let r = {};
	for (var i in t) e(r, i, {
		get: t[i],
		enumerable: !0
	});
	return n || e(r, Symbol.toStringTag, { value: "Module" }), r;
}, n = typeof globalThis == "object" && "crypto" in globalThis ? globalThis.crypto : void 0;
function r(e) {
	return e instanceof Uint8Array || ArrayBuffer.isView(e) && e.constructor.name === "Uint8Array";
}
function i(e) {
	if (!Number.isSafeInteger(e) || e < 0) throw Error("positive integer expected, got " + e);
}
function a(e, ...t) {
	if (!r(e)) throw Error("Uint8Array expected");
	if (t.length > 0 && !t.includes(e.length)) throw Error("Uint8Array expected of length " + t + ", got length=" + e.length);
}
function o(e) {
	if (typeof e != "function" || typeof e.create != "function") throw Error("Hash should be wrapped by utils.createHasher");
	i(e.outputLen), i(e.blockLen);
}
function s(e, t = !0) {
	if (e.destroyed) throw Error("Hash instance has been destroyed");
	if (t && e.finished) throw Error("Hash#digest() has already been called");
}
function c(e, t) {
	a(e);
	let n = t.outputLen;
	if (e.length < n) throw Error("digestInto() expects output buffer of length at least " + n);
}
function l(...e) {
	for (let t = 0; t < e.length; t++) e[t].fill(0);
}
function u(e) {
	return new DataView(e.buffer, e.byteOffset, e.byteLength);
}
function d(e, t) {
	return e << 32 - t | e >>> t;
}
var f = typeof Uint8Array.from([]).toHex == "function" && typeof Uint8Array.fromHex == "function", p = /* @__PURE__ */ Array.from({ length: 256 }, (e, t) => t.toString(16).padStart(2, "0"));
function m(e) {
	if (a(e), f) return e.toHex();
	let t = "";
	for (let n = 0; n < e.length; n++) t += p[e[n]];
	return t;
}
var h = {
	_0: 48,
	_9: 57,
	A: 65,
	F: 70,
	a: 97,
	f: 102
};
function g(e) {
	if (e >= h._0 && e <= h._9) return e - h._0;
	if (e >= h.A && e <= h.F) return e - (h.A - 10);
	if (e >= h.a && e <= h.f) return e - (h.a - 10);
}
function _(e) {
	if (typeof e != "string") throw Error("hex string expected, got " + typeof e);
	if (f) return Uint8Array.fromHex(e);
	let t = e.length, n = t / 2;
	if (t % 2) throw Error("hex string expected, got unpadded hex of length " + t);
	let r = new Uint8Array(n);
	for (let t = 0, i = 0; t < n; t++, i += 2) {
		let n = g(e.charCodeAt(i)), a = g(e.charCodeAt(i + 1));
		if (n === void 0 || a === void 0) {
			let t = e[i] + e[i + 1];
			throw Error("hex string expected, got non-hex character \"" + t + "\" at index " + i);
		}
		r[t] = n * 16 + a;
	}
	return r;
}
function v(e) {
	if (typeof e != "string") throw Error("string expected");
	return new Uint8Array(new TextEncoder().encode(e));
}
function y(e) {
	return typeof e == "string" && (e = v(e)), a(e), e;
}
function b(...e) {
	let t = 0;
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		a(r), t += r.length;
	}
	let n = new Uint8Array(t);
	for (let t = 0, r = 0; t < e.length; t++) {
		let i = e[t];
		n.set(i, r), r += i.length;
	}
	return n;
}
var x = class {};
function ee(e) {
	let t = (t) => e().update(y(t)).digest(), n = e();
	return t.outputLen = n.outputLen, t.blockLen = n.blockLen, t.create = () => e(), t;
}
function te(e = 32) {
	if (n && typeof n.getRandomValues == "function") return n.getRandomValues(new Uint8Array(e));
	if (n && typeof n.randomBytes == "function") return Uint8Array.from(n.randomBytes(e));
	throw Error("crypto.getRandomValues must be defined");
}
function ne(e, t, n, r) {
	if (typeof e.setBigUint64 == "function") return e.setBigUint64(t, n, r);
	let i = BigInt(32), a = BigInt(4294967295), o = Number(n >> i & a), s = Number(n & a), c = r ? 4 : 0, l = r ? 0 : 4;
	e.setUint32(t + c, o, r), e.setUint32(t + l, s, r);
}
function re(e, t, n) {
	return e & t ^ ~e & n;
}
function ie(e, t, n) {
	return e & t ^ e & n ^ t & n;
}
var S = class extends x {
	constructor(e, t, n, r) {
		super(), this.finished = !1, this.length = 0, this.pos = 0, this.destroyed = !1, this.blockLen = e, this.outputLen = t, this.padOffset = n, this.isLE = r, this.buffer = new Uint8Array(e), this.view = u(this.buffer);
	}
	update(e) {
		s(this), e = y(e), a(e);
		let { view: t, buffer: n, blockLen: r } = this, i = e.length;
		for (let a = 0; a < i;) {
			let o = Math.min(r - this.pos, i - a);
			if (o === r) {
				let t = u(e);
				for (; r <= i - a; a += r) this.process(t, a);
				continue;
			}
			n.set(e.subarray(a, a + o), this.pos), this.pos += o, a += o, this.pos === r && (this.process(t, 0), this.pos = 0);
		}
		return this.length += e.length, this.roundClean(), this;
	}
	digestInto(e) {
		s(this), c(e, this), this.finished = !0;
		let { buffer: t, view: n, blockLen: r, isLE: i } = this, { pos: a } = this;
		t[a++] = 128, l(this.buffer.subarray(a)), this.padOffset > r - a && (this.process(n, 0), a = 0);
		for (let e = a; e < r; e++) t[e] = 0;
		ne(n, r - 8, BigInt(this.length * 8), i), this.process(n, 0);
		let o = u(e), d = this.outputLen;
		if (d % 4) throw Error("_sha2: outputLen should be aligned to 32bit");
		let f = d / 4, p = this.get();
		if (f > p.length) throw Error("_sha2: outputLen bigger than state");
		for (let e = 0; e < f; e++) o.setUint32(4 * e, p[e], i);
	}
	digest() {
		let { buffer: e, outputLen: t } = this;
		this.digestInto(e);
		let n = e.slice(0, t);
		return this.destroy(), n;
	}
	_cloneInto(e) {
		e ||= new this.constructor(), e.set(...this.get());
		let { blockLen: t, buffer: n, length: r, finished: i, destroyed: a, pos: o } = this;
		return e.destroyed = a, e.finished = i, e.length = r, e.pos = o, r % t && e.buffer.set(n), e;
	}
	clone() {
		return this._cloneInto();
	}
}, C = /* @__PURE__ */ Uint32Array.from([
	1779033703,
	3144134277,
	1013904242,
	2773480762,
	1359893119,
	2600822924,
	528734635,
	1541459225
]), w = /* @__PURE__ */ Uint32Array.from([
	3238371032,
	914150663,
	812702999,
	4144912697,
	4290775857,
	1750603025,
	1694076839,
	3204075428
]), ae = /* @__PURE__ */ Uint32Array.from([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]), T = /* @__PURE__ */ new Uint32Array(64), oe = class extends S {
	constructor(e = 32) {
		super(64, e, 8, !1), this.A = C[0] | 0, this.B = C[1] | 0, this.C = C[2] | 0, this.D = C[3] | 0, this.E = C[4] | 0, this.F = C[5] | 0, this.G = C[6] | 0, this.H = C[7] | 0;
	}
	get() {
		let { A: e, B: t, C: n, D: r, E: i, F: a, G: o, H: s } = this;
		return [
			e,
			t,
			n,
			r,
			i,
			a,
			o,
			s
		];
	}
	set(e, t, n, r, i, a, o, s) {
		this.A = e | 0, this.B = t | 0, this.C = n | 0, this.D = r | 0, this.E = i | 0, this.F = a | 0, this.G = o | 0, this.H = s | 0;
	}
	process(e, t) {
		for (let n = 0; n < 16; n++, t += 4) T[n] = e.getUint32(t, !1);
		for (let e = 16; e < 64; e++) {
			let t = T[e - 15], n = T[e - 2], r = d(t, 7) ^ d(t, 18) ^ t >>> 3;
			T[e] = (d(n, 17) ^ d(n, 19) ^ n >>> 10) + T[e - 7] + r + T[e - 16] | 0;
		}
		let { A: n, B: r, C: i, D: a, E: o, F: s, G: c, H: l } = this;
		for (let e = 0; e < 64; e++) {
			let t = d(o, 6) ^ d(o, 11) ^ d(o, 25), u = l + t + re(o, s, c) + ae[e] + T[e] | 0, f = (d(n, 2) ^ d(n, 13) ^ d(n, 22)) + ie(n, r, i) | 0;
			l = c, c = s, s = o, o = a + u | 0, a = i, i = r, r = n, n = u + f | 0;
		}
		n = n + this.A | 0, r = r + this.B | 0, i = i + this.C | 0, a = a + this.D | 0, o = o + this.E | 0, s = s + this.F | 0, c = c + this.G | 0, l = l + this.H | 0, this.set(n, r, i, a, o, s, c, l);
	}
	roundClean() {
		l(T);
	}
	destroy() {
		this.set(0, 0, 0, 0, 0, 0, 0, 0), l(this.buffer);
	}
}, se = class extends oe {
	constructor() {
		super(28), this.A = w[0] | 0, this.B = w[1] | 0, this.C = w[2] | 0, this.D = w[3] | 0, this.E = w[4] | 0, this.F = w[5] | 0, this.G = w[6] | 0, this.H = w[7] | 0;
	}
}, ce = /* @__PURE__ */ ee(() => new oe()), le = /* @__PURE__ */ ee(() => new se()), ue = /* @__PURE__ */ BigInt(0), de = /* @__PURE__ */ BigInt(1);
function fe(e, t = "") {
	if (typeof e != "boolean") {
		let n = t && `"${t}"`;
		throw Error(n + "expected boolean, got type=" + typeof e);
	}
	return e;
}
function pe(e, t, n = "") {
	let i = r(e), a = e?.length, o = t !== void 0;
	if (!i || o && a !== t) {
		let r = n && `"${n}" `, s = o ? ` of length ${t}` : "", c = i ? `length=${a}` : `type=${typeof e}`;
		throw Error(r + "expected Uint8Array" + s + ", got " + c);
	}
	return e;
}
function me(e) {
	if (typeof e != "string") throw Error("hex string expected, got " + typeof e);
	return e === "" ? ue : BigInt("0x" + e);
}
function E(e) {
	return me(m(e));
}
function he(e) {
	return a(e), me(m(Uint8Array.from(e).reverse()));
}
function D(e, t) {
	return _(e.toString(16).padStart(t * 2, "0"));
}
function ge(e, t) {
	return D(e, t).reverse();
}
function _e(e, t, n) {
	let i;
	if (typeof t == "string") try {
		i = _(t);
	} catch (t) {
		throw Error(e + " must be hex string or Uint8Array, cause: " + t);
	}
	else if (r(t)) i = Uint8Array.from(t);
	else throw Error(e + " must be hex string or Uint8Array");
	let a = i.length;
	if (typeof n == "number" && a !== n) throw Error(e + " of length " + n + " expected, got " + a);
	return i;
}
var ve = (e) => typeof e == "bigint" && ue <= e;
function ye(e, t, n) {
	return ve(e) && ve(t) && ve(n) && t <= e && e < n;
}
function be(e) {
	let t;
	for (t = 0; e > ue; e >>= de, t += 1);
	return t;
}
function xe(e, t) {
	return e >> BigInt(t) & de;
}
var O = (e) => (de << BigInt(e)) - de;
function Se(e) {
	return typeof e == "function" && Number.isSafeInteger(e.outputLen);
}
function Ce(e, t, n = {}) {
	if (!e || typeof e != "object") throw Error("expected valid options object");
	function r(t, n, r) {
		let i = e[t];
		if (r && i === void 0) return;
		let a = typeof i;
		if (a !== n || i === null) throw Error(`param "${t}" is invalid: expected ${n}, got ${a}`);
	}
	Object.entries(t).forEach(([e, t]) => r(e, t, !1)), Object.entries(n).forEach(([e, t]) => r(e, t, !0));
}
var we = () => {
	throw Error("not implemented");
};
function Te(e) {
	let t = /* @__PURE__ */ new WeakMap();
	return (n, ...r) => {
		let i = t.get(n);
		if (i !== void 0) return i;
		let a = e(n, ...r);
		return t.set(n, a), a;
	};
}
var k = BigInt(0), A = BigInt(1), j = /* @__PURE__ */ BigInt(2), Ee = /* @__PURE__ */ BigInt(3), De = /* @__PURE__ */ BigInt(4), Oe = /* @__PURE__ */ BigInt(5), ke = /* @__PURE__ */ BigInt(7), Ae = /* @__PURE__ */ BigInt(8), je = /* @__PURE__ */ BigInt(9), Me = /* @__PURE__ */ BigInt(16);
function M(e, t) {
	let n = e % t;
	return n >= k ? n : t + n;
}
function Ne(e, t) {
	if (e === k) throw Error("invert: expected non-zero number");
	if (t <= k) throw Error("invert: expected positive modulus, got " + t);
	let n = M(e, t), r = t, i = k, a = A, o = A, s = k;
	for (; n !== k;) {
		let e = r / n, t = r % n, c = i - o * e, l = a - s * e;
		r = n, n = t, i = o, a = s, o = c, s = l;
	}
	if (r !== A) throw Error("invert: does not exist");
	return M(i, t);
}
function Pe(e, t, n) {
	if (!e.eql(e.sqr(t), n)) throw Error("Cannot find square root");
}
function Fe(e, t) {
	let n = (e.ORDER + A) / De, r = e.pow(t, n);
	return Pe(e, r, t), r;
}
function Ie(e, t) {
	let n = (e.ORDER - Oe) / Ae, r = e.mul(t, j), i = e.pow(r, n), a = e.mul(t, i), o = e.mul(e.mul(a, j), i), s = e.mul(a, e.sub(o, e.ONE));
	return Pe(e, s, t), s;
}
function Le(e) {
	let t = Ge(e), n = Re(e), r = n(t, t.neg(t.ONE)), i = n(t, r), a = n(t, t.neg(r)), o = (e + ke) / Me;
	return (e, t) => {
		let n = e.pow(t, o), s = e.mul(n, r), c = e.mul(n, i), l = e.mul(n, a), u = e.eql(e.sqr(s), t), d = e.eql(e.sqr(c), t);
		n = e.cmov(n, s, u), s = e.cmov(l, c, d);
		let f = e.eql(e.sqr(s), t), p = e.cmov(n, s, f);
		return Pe(e, p, t), p;
	};
}
function Re(e) {
	if (e < Ee) throw Error("sqrt is not defined for small field");
	let t = e - A, n = 0;
	for (; t % j === k;) t /= j, n++;
	let r = j, i = Ge(e);
	for (; Ue(i, r) === 1;) if (r++ > 1e3) throw Error("Cannot find square root: probably non-prime P");
	if (n === 1) return Fe;
	let a = i.pow(r, t), o = (t + A) / j;
	return function(e, r) {
		if (e.is0(r)) return r;
		if (Ue(e, r) !== 1) throw Error("Cannot find square root");
		let i = n, s = e.mul(e.ONE, a), c = e.pow(r, t), l = e.pow(r, o);
		for (; !e.eql(c, e.ONE);) {
			if (e.is0(c)) return e.ZERO;
			let t = 1, n = e.sqr(c);
			for (; !e.eql(n, e.ONE);) if (t++, n = e.sqr(n), t === i) throw Error("Cannot find square root");
			let r = A << BigInt(i - t - 1), a = e.pow(s, r);
			i = t, s = e.sqr(a), c = e.mul(c, s), l = e.mul(l, a);
		}
		return l;
	};
}
function ze(e) {
	return e % De === Ee ? Fe : e % Ae === Oe ? Ie : e % Me === je ? Le(e) : Re(e);
}
var Be = [
	"create",
	"isValid",
	"is0",
	"neg",
	"inv",
	"sqrt",
	"sqr",
	"eql",
	"add",
	"sub",
	"mul",
	"pow",
	"div",
	"addN",
	"subN",
	"mulN",
	"sqrN"
];
function Ve(e) {
	return Ce(e, Be.reduce((e, t) => (e[t] = "function", e), {
		ORDER: "bigint",
		MASK: "bigint",
		BYTES: "number",
		BITS: "number"
	})), e;
}
function He(e, t, n) {
	if (n < k) throw Error("invalid exponent, negatives unsupported");
	if (n === k) return e.ONE;
	if (n === A) return t;
	let r = e.ONE, i = t;
	for (; n > k;) n & A && (r = e.mul(r, i)), i = e.sqr(i), n >>= A;
	return r;
}
function N(e, t, n = !1) {
	let r = Array(t.length).fill(n ? e.ZERO : void 0), i = t.reduce((t, n, i) => e.is0(n) ? t : (r[i] = t, e.mul(t, n)), e.ONE), a = e.inv(i);
	return t.reduceRight((t, n, i) => e.is0(n) ? t : (r[i] = e.mul(t, r[i]), e.mul(t, n)), a), r;
}
function Ue(e, t) {
	let n = (e.ORDER - A) / j, r = e.pow(t, n), i = e.eql(r, e.ONE), a = e.eql(r, e.ZERO), o = e.eql(r, e.neg(e.ONE));
	if (!i && !a && !o) throw Error("invalid Legendre symbol result");
	return i ? 1 : a ? 0 : -1;
}
function We(e, t) {
	t !== void 0 && i(t);
	let n = t === void 0 ? e.toString(2).length : t;
	return {
		nBitLength: n,
		nByteLength: Math.ceil(n / 8)
	};
}
function Ge(e, t, n = !1, r = {}) {
	if (e <= k) throw Error("invalid field: expected ORDER > 0, got " + e);
	let i, a, o = !1, s;
	if (typeof t == "object" && t) {
		if (r.sqrt || n) throw Error("cannot specify opts in two arguments");
		let e = t;
		e.BITS && (i = e.BITS), e.sqrt && (a = e.sqrt), typeof e.isLE == "boolean" && (n = e.isLE), typeof e.modFromBytes == "boolean" && (o = e.modFromBytes), s = e.allowedLengths;
	} else typeof t == "number" && (i = t), r.sqrt && (a = r.sqrt);
	let { nBitLength: c, nByteLength: l } = We(e, i);
	if (l > 2048) throw Error("invalid field: expected ORDER of <= 2048 bytes");
	let u, d = Object.freeze({
		ORDER: e,
		isLE: n,
		BITS: c,
		BYTES: l,
		MASK: O(c),
		ZERO: k,
		ONE: A,
		allowedLengths: s,
		create: (t) => M(t, e),
		isValid: (t) => {
			if (typeof t != "bigint") throw Error("invalid field element: expected bigint, got " + typeof t);
			return k <= t && t < e;
		},
		is0: (e) => e === k,
		isValidNot0: (e) => !d.is0(e) && d.isValid(e),
		isOdd: (e) => (e & A) === A,
		neg: (t) => M(-t, e),
		eql: (e, t) => e === t,
		sqr: (t) => M(t * t, e),
		add: (t, n) => M(t + n, e),
		sub: (t, n) => M(t - n, e),
		mul: (t, n) => M(t * n, e),
		pow: (e, t) => He(d, e, t),
		div: (t, n) => M(t * Ne(n, e), e),
		sqrN: (e) => e * e,
		addN: (e, t) => e + t,
		subN: (e, t) => e - t,
		mulN: (e, t) => e * t,
		inv: (t) => Ne(t, e),
		sqrt: a || ((t) => (u ||= ze(e), u(d, t))),
		toBytes: (e) => n ? ge(e, l) : D(e, l),
		fromBytes: (t, r = !0) => {
			if (s) {
				if (!s.includes(t.length) || t.length > l) throw Error("Field.fromBytes: expected " + s + " bytes, got " + t.length);
				let e = new Uint8Array(l);
				e.set(t, n ? 0 : e.length - t.length), t = e;
			}
			if (t.length !== l) throw Error("Field.fromBytes: expected " + l + " bytes, got " + t.length);
			let i = n ? he(t) : E(t);
			if (o && (i = M(i, e)), !r && !d.isValid(i)) throw Error("invalid field element: outside of range 0..ORDER");
			return i;
		},
		invertBatch: (e) => N(d, e),
		cmov: (e, t, n) => n ? t : e
	});
	return Object.freeze(d);
}
function Ke(e) {
	if (typeof e != "bigint") throw Error("field order must be bigint");
	let t = e.toString(2).length;
	return Math.ceil(t / 8);
}
function qe(e) {
	let t = Ke(e);
	return t + Math.ceil(t / 2);
}
function Je(e, t, n = !1) {
	let r = e.length, i = Ke(t), a = qe(t);
	if (r < 16 || r < a || r > 1024) throw Error("expected " + a + "-1024 bytes of input, got " + r);
	let o = M(n ? he(e) : E(e), t - A) + A;
	return n ? ge(o, i) : D(o, i);
}
var Ye = BigInt(0), P = BigInt(1);
function Xe(e, t) {
	let n = t.negate();
	return e ? n : t;
}
function Ze(e, t) {
	let n = N(e.Fp, t.map((e) => e.Z));
	return t.map((t, r) => e.fromAffine(t.toAffine(n[r])));
}
function Qe(e, t) {
	if (!Number.isSafeInteger(e) || e <= 0 || e > t) throw Error("invalid window size, expected [1.." + t + "], got W=" + e);
}
function $e(e, t) {
	Qe(e, t);
	let n = Math.ceil(t / e) + 1, r = 2 ** (e - 1), i = 2 ** e;
	return {
		windows: n,
		windowSize: r,
		mask: O(e),
		maxNumber: i,
		shiftBy: BigInt(e)
	};
}
function et(e, t, n) {
	let { windowSize: r, mask: i, maxNumber: a, shiftBy: o } = n, s = Number(e & i), c = e >> o;
	s > r && (s -= a, c += P);
	let l = t * r, u = l + Math.abs(s) - 1, d = s === 0, f = s < 0, p = t % 2 != 0;
	return {
		nextN: c,
		offset: u,
		isZero: d,
		isNeg: f,
		isNegF: p,
		offsetF: l
	};
}
function tt(e, t) {
	if (!Array.isArray(e)) throw Error("array expected");
	e.forEach((e, n) => {
		if (!(e instanceof t)) throw Error("invalid point at index " + n);
	});
}
function nt(e, t) {
	if (!Array.isArray(e)) throw Error("array of scalars expected");
	e.forEach((e, n) => {
		if (!t.isValid(e)) throw Error("invalid scalar at index " + n);
	});
}
var rt = /* @__PURE__ */ new WeakMap(), it = /* @__PURE__ */ new WeakMap();
function at(e) {
	return it.get(e) || 1;
}
function ot(e) {
	if (e !== Ye) throw Error("invalid wNAF");
}
var st = class {
	constructor(e, t) {
		this.BASE = e.BASE, this.ZERO = e.ZERO, this.Fn = e.Fn, this.bits = t;
	}
	_unsafeLadder(e, t, n = this.ZERO) {
		let r = e;
		for (; t > Ye;) t & P && (n = n.add(r)), r = r.double(), t >>= P;
		return n;
	}
	precomputeWindow(e, t) {
		let { windows: n, windowSize: r } = $e(t, this.bits), i = [], a = e, o = a;
		for (let e = 0; e < n; e++) {
			o = a, i.push(o);
			for (let e = 1; e < r; e++) o = o.add(a), i.push(o);
			a = o.double();
		}
		return i;
	}
	wNAF(e, t, n) {
		if (!this.Fn.isValid(n)) throw Error("invalid scalar");
		let r = this.ZERO, i = this.BASE, a = $e(e, this.bits);
		for (let e = 0; e < a.windows; e++) {
			let { nextN: o, offset: s, isZero: c, isNeg: l, isNegF: u, offsetF: d } = et(n, e, a);
			n = o, c ? i = i.add(Xe(u, t[d])) : r = r.add(Xe(l, t[s]));
		}
		return ot(n), {
			p: r,
			f: i
		};
	}
	wNAFUnsafe(e, t, n, r = this.ZERO) {
		let i = $e(e, this.bits);
		for (let e = 0; e < i.windows && n !== Ye; e++) {
			let { nextN: a, offset: o, isZero: s, isNeg: c } = et(n, e, i);
			if (n = a, !s) {
				let e = t[o];
				r = r.add(c ? e.negate() : e);
			}
		}
		return ot(n), r;
	}
	getPrecomputes(e, t, n) {
		let r = rt.get(t);
		return r || (r = this.precomputeWindow(t, e), e !== 1 && (typeof n == "function" && (r = n(r)), rt.set(t, r))), r;
	}
	cached(e, t, n) {
		let r = at(e);
		return this.wNAF(r, this.getPrecomputes(r, e, n), t);
	}
	unsafe(e, t, n, r) {
		let i = at(e);
		return i === 1 ? this._unsafeLadder(e, t, r) : this.wNAFUnsafe(i, this.getPrecomputes(i, e, n), t, r);
	}
	createCache(e, t) {
		Qe(t, this.bits), it.set(e, t), rt.delete(e);
	}
	hasCache(e) {
		return at(e) !== 1;
	}
};
function ct(e, t, n, r) {
	let i = t, a = e.ZERO, o = e.ZERO;
	for (; n > Ye || r > Ye;) n & P && (a = a.add(i)), r & P && (o = o.add(i)), i = i.double(), n >>= P, r >>= P;
	return {
		p1: a,
		p2: o
	};
}
function lt(e, t, n, r) {
	tt(n, e), nt(r, t);
	let i = n.length, a = r.length;
	if (i !== a) throw Error("arrays of points and scalars must have equal length");
	let o = e.ZERO, s = be(BigInt(i)), c = 1;
	s > 12 ? c = s - 3 : s > 4 ? c = s - 2 : s > 0 && (c = 2);
	let l = O(c), u = Array(Number(l) + 1).fill(o), d = Math.floor((t.BITS - 1) / c) * c, f = o;
	for (let e = d; e >= 0; e -= c) {
		u.fill(o);
		for (let t = 0; t < a; t++) {
			let i = r[t], a = Number(i >> BigInt(e) & l);
			u[a] = u[a].add(n[t]);
		}
		let t = o;
		for (let e = u.length - 1, n = o; e > 0; e--) n = n.add(u[e]), t = t.add(n);
		if (f = f.add(t), e !== 0) for (let e = 0; e < c; e++) f = f.double();
	}
	return f;
}
function ut(e, t, n) {
	if (t) {
		if (t.ORDER !== e) throw Error("Field.ORDER must match order: Fp == p, Fn == n");
		return Ve(t), t;
	} else return Ge(e, { isLE: n });
}
function dt(e, t, n = {}, r) {
	if (r === void 0 && (r = e === "edwards"), !t || typeof t != "object") throw Error(`expected valid ${e} CURVE object`);
	for (let e of [
		"p",
		"n",
		"h"
	]) {
		let n = t[e];
		if (!(typeof n == "bigint" && n > Ye)) throw Error(`CURVE.${e} must be positive bigint`);
	}
	let i = ut(t.p, n.Fp, r), a = ut(t.n, n.Fn, r), o = [
		"Gx",
		"Gy",
		"a",
		e === "weierstrass" ? "b" : "d"
	];
	for (let e of o) if (!i.isValid(t[e])) throw Error(`CURVE.${e} must be valid field element of CURVE.Fp`);
	return t = Object.freeze(Object.assign({}, t)), {
		CURVE: t,
		Fp: i,
		Fn: a
	};
}
var ft = E;
function F(e, t) {
	if (mt(e), mt(t), e < 0 || e >= 1 << 8 * t) throw Error("invalid I2OSP input: " + e);
	let n = Array.from({ length: t }).fill(0);
	for (let r = t - 1; r >= 0; r--) n[r] = e & 255, e >>>= 8;
	return new Uint8Array(n);
}
function pt(e, t) {
	let n = new Uint8Array(e.length);
	for (let r = 0; r < e.length; r++) n[r] = e[r] ^ t[r];
	return n;
}
function mt(e) {
	if (!Number.isSafeInteger(e)) throw Error("number expected");
}
function ht(e) {
	if (!r(e) && typeof e != "string") throw Error("DST must be Uint8Array or string");
	return typeof e == "string" ? v(e) : e;
}
function gt(e, t, n, r) {
	a(e), mt(n), t = ht(t), t.length > 255 && (t = r(b(v("H2C-OVERSIZE-DST-"), t)));
	let { outputLen: i, blockLen: o } = r, s = Math.ceil(n / i);
	if (n > 65535 || s > 255) throw Error("expand_message_xmd: invalid lenInBytes");
	let c = b(t, F(t.length, 1)), l = F(0, o), u = F(n, 2), d = Array(s), f = r(b(l, e, u, F(0, 1), c));
	d[0] = r(b(f, F(1, 1), c));
	for (let e = 1; e <= s; e++) d[e] = r(b(pt(f, d[e - 1]), F(e + 1, 1), c));
	return b(...d).slice(0, n);
}
function _t(e, t, n, r, i) {
	if (a(e), mt(n), t = ht(t), t.length > 255) {
		let e = Math.ceil(2 * r / 8);
		t = i.create({ dkLen: e }).update(v("H2C-OVERSIZE-DST-")).update(t).digest();
	}
	if (n > 65535 || t.length > 255) throw Error("expand_message_xof: invalid lenInBytes");
	return i.create({ dkLen: n }).update(e).update(F(n, 2)).update(t).update(F(t.length, 1)).digest();
}
function vt(e, t, n) {
	Ce(n, {
		p: "bigint",
		m: "number",
		k: "number",
		hash: "function"
	});
	let { p: r, k: i, m: o, hash: s, expand: c, DST: l } = n;
	if (!Se(n.hash)) throw Error("expected valid hash");
	a(e), mt(t);
	let u = r.toString(2).length, d = Math.ceil((u + i) / 8), f = t * o * d, p;
	if (c === "xmd") p = gt(e, l, f, s);
	else if (c === "xof") p = _t(e, l, f, i, s);
	else if (c === "_internal_pass") p = e;
	else throw Error("expand must be \"xmd\" or \"xof\"");
	let m = Array(t);
	for (let e = 0; e < t; e++) {
		let t = Array(o);
		for (let n = 0; n < o; n++) {
			let i = d * (n + e * o);
			t[n] = M(ft(p.subarray(i, i + d)), r);
		}
		m[e] = t;
	}
	return m;
}
function yt(e, t) {
	let n = t.map((e) => Array.from(e).reverse());
	return (t, r) => {
		let [i, a, o, s] = n.map((n) => n.reduce((n, r) => e.add(e.mul(n, t), r))), [c, l] = N(e, [a, s], !0);
		return t = e.mul(i, c), r = e.mul(r, e.mul(o, l)), {
			x: t,
			y: r
		};
	};
}
var bt = v("HashToScalar-");
function xt(e, t, n) {
	if (typeof t != "function") throw Error("mapToCurve() must be defined");
	function r(n) {
		return e.fromAffine(t(n));
	}
	function i(t) {
		let n = t.clearCofactor();
		return n.equals(e.ZERO) ? e.ZERO : (n.assertValidity(), n);
	}
	return {
		defaults: n,
		hashToCurve(e, t) {
			let a = vt(e, 2, Object.assign({}, n, t)), o = r(a[0]), s = r(a[1]);
			return i(o.add(s));
		},
		encodeToCurve(e, t) {
			let a = n.encodeDST ? { DST: n.encodeDST } : {};
			return i(r(vt(e, 1, Object.assign({}, n, a, t))[0]));
		},
		mapToCurve(e) {
			if (!Array.isArray(e)) throw Error("expected array of bigints");
			for (let t of e) if (typeof t != "bigint") throw Error("expected array of bigints");
			return i(r(e));
		},
		hashToScalar(t, r) {
			let i = e.Fn.ORDER;
			return vt(t, 1, Object.assign({}, n, {
				p: i,
				m: 1,
				DST: bt
			}, r))[0][0];
		}
	};
}
var St = class extends x {
	constructor(e, t) {
		super(), this.finished = !1, this.destroyed = !1, o(e);
		let n = y(t);
		if (this.iHash = e.create(), typeof this.iHash.update != "function") throw Error("Expected instance of class which extends utils.Hash");
		this.blockLen = this.iHash.blockLen, this.outputLen = this.iHash.outputLen;
		let r = this.blockLen, i = new Uint8Array(r);
		i.set(n.length > r ? e.create().update(n).digest() : n);
		for (let e = 0; e < i.length; e++) i[e] ^= 54;
		this.iHash.update(i), this.oHash = e.create();
		for (let e = 0; e < i.length; e++) i[e] ^= 106;
		this.oHash.update(i), l(i);
	}
	update(e) {
		return s(this), this.iHash.update(e), this;
	}
	digestInto(e) {
		s(this), a(e, this.outputLen), this.finished = !0, this.iHash.digestInto(e), this.oHash.update(e), this.oHash.digestInto(e), this.destroy();
	}
	digest() {
		let e = new Uint8Array(this.oHash.outputLen);
		return this.digestInto(e), e;
	}
	_cloneInto(e) {
		e ||= Object.create(Object.getPrototypeOf(this), {});
		let { oHash: t, iHash: n, finished: r, destroyed: i, blockLen: a, outputLen: o } = this;
		return e = e, e.finished = r, e.destroyed = i, e.blockLen = a, e.outputLen = o, e.oHash = t._cloneInto(e.oHash), e.iHash = n._cloneInto(e.iHash), e;
	}
	clone() {
		return this._cloneInto();
	}
	destroy() {
		this.destroyed = !0, this.oHash.destroy(), this.iHash.destroy();
	}
}, Ct = (e, t, n) => new St(e, t).update(n).digest();
Ct.create = (e, t) => new St(e, t);
var wt = (e, t) => (e + (e >= 0 ? t : -t) / L) / t;
function Tt(e, t, n) {
	let [[r, i], [a, o]] = t, s = wt(o * e, n), c = wt(-i * e, n), l = e - s * r - c * a, u = -s * i - c * o, d = l < Et, f = u < Et;
	d && (l = -l), f && (u = -u);
	let p = O(Math.ceil(be(n) / 2)) + I;
	if (l < Et || l >= p || u < Et || u >= p) throw Error("splitScalar (endomorphism): failed, k=" + e);
	return {
		k1neg: d,
		k1: l,
		k2neg: f,
		k2: u
	};
}
var Et = BigInt(0), I = BigInt(1), L = BigInt(2), Dt = BigInt(3), Ot = BigInt(4);
function kt(e, t) {
	let { BYTES: n } = e, r;
	if (typeof t == "bigint") r = t;
	else {
		let i = _e("private key", t);
		try {
			r = e.fromBytes(i);
		} catch {
			throw Error(`invalid private key: expected ui8a of size ${n}, got ${typeof t}`);
		}
	}
	if (!e.isValidNot0(r)) throw Error("invalid private key: out of range [1..N-1]");
	return r;
}
function At(e, t = {}) {
	let n = dt("weierstrass", e, t), { Fp: r, Fn: i } = n, a = n.CURVE, { h: o, n: s } = a;
	Ce(t, {}, {
		allowInfinityPoint: "boolean",
		clearCofactor: "function",
		isTorsionFree: "function",
		fromBytes: "function",
		toBytes: "function",
		endo: "object",
		wrapPrivateKey: "boolean"
	});
	let { endo: c } = t;
	if (c && (!r.is0(a.a) || typeof c.beta != "bigint" || !Array.isArray(c.basises))) throw Error("invalid endo: expected \"beta\": bigint and \"basises\": array");
	let l = Pt(r, i);
	function u() {
		if (!r.isOdd) throw Error("compression is not supported: Field does not have .isOdd()");
	}
	function d(e, t, n) {
		let { x: i, y: a } = t.toAffine(), o = r.toBytes(i);
		return fe(n, "isCompressed"), n ? (u(), b(jt(!r.isOdd(a)), o)) : b(Uint8Array.of(4), o, r.toBytes(a));
	}
	function f(e) {
		pe(e, void 0, "Point");
		let { publicKey: t, publicKeyUncompressed: n } = l, i = e.length, a = e[0], o = e.subarray(1);
		if (i === t && (a === 2 || a === 3)) {
			let e = r.fromBytes(o);
			if (!r.isValid(e)) throw Error("bad point: is not on curve, wrong x");
			let t = g(e), n;
			try {
				n = r.sqrt(t);
			} catch (e) {
				let t = e instanceof Error ? ": " + e.message : "";
				throw Error("bad point: is not on curve, sqrt error" + t);
			}
			u();
			let i = r.isOdd(n);
			return (a & 1) == 1 !== i && (n = r.neg(n)), {
				x: e,
				y: n
			};
		} else if (i === n && a === 4) {
			let e = r.BYTES, t = r.fromBytes(o.subarray(0, e)), n = r.fromBytes(o.subarray(e, e * 2));
			if (!_(t, n)) throw Error("bad point: is not on curve");
			return {
				x: t,
				y: n
			};
		} else throw Error(`bad point: got length ${i}, expected compressed=${t} or uncompressed=${n}`);
	}
	let p = t.toBytes || d, h = t.fromBytes || f;
	function g(e) {
		let t = r.sqr(e), n = r.mul(t, e);
		return r.add(r.add(n, r.mul(e, a.a)), a.b);
	}
	function _(e, t) {
		let n = r.sqr(t), i = g(e);
		return r.eql(n, i);
	}
	if (!_(a.Gx, a.Gy)) throw Error("bad curve params: generator point");
	let v = r.mul(r.pow(a.a, Dt), Ot), y = r.mul(r.sqr(a.b), BigInt(27));
	if (r.is0(r.add(v, y))) throw Error("bad curve params: a or b");
	function x(e, t, n = !1) {
		if (!r.isValid(t) || n && r.is0(t)) throw Error(`bad point coordinate ${e}`);
		return t;
	}
	function ee(e) {
		if (!(e instanceof S)) throw Error("ProjectivePoint expected");
	}
	function te(e) {
		if (!c || !c.basises) throw Error("no endo");
		return Tt(e, c.basises, i.ORDER);
	}
	let ne = Te((e, t) => {
		let { X: n, Y: i, Z: a } = e;
		if (r.eql(a, r.ONE)) return {
			x: n,
			y: i
		};
		let o = e.is0();
		t ??= o ? r.ONE : r.inv(a);
		let s = r.mul(n, t), c = r.mul(i, t), l = r.mul(a, t);
		if (o) return {
			x: r.ZERO,
			y: r.ZERO
		};
		if (!r.eql(l, r.ONE)) throw Error("invZ was invalid");
		return {
			x: s,
			y: c
		};
	}), re = Te((e) => {
		if (e.is0()) {
			if (t.allowInfinityPoint && !r.is0(e.Y)) return;
			throw Error("bad point: ZERO");
		}
		let { x: n, y: i } = e.toAffine();
		if (!r.isValid(n) || !r.isValid(i)) throw Error("bad point: x or y not field elements");
		if (!_(n, i)) throw Error("bad point: equation left != right");
		if (!e.isTorsionFree()) throw Error("bad point: not in prime-order subgroup");
		return !0;
	});
	function ie(e, t, n, i, a) {
		return n = new S(r.mul(n.X, e), n.Y, n.Z), t = Xe(i, t), n = Xe(a, n), t.add(n);
	}
	class S {
		constructor(e, t, n) {
			this.X = x("x", e), this.Y = x("y", t, !0), this.Z = x("z", n), Object.freeze(this);
		}
		static CURVE() {
			return a;
		}
		static fromAffine(e) {
			let { x: t, y: n } = e || {};
			if (!e || !r.isValid(t) || !r.isValid(n)) throw Error("invalid affine point");
			if (e instanceof S) throw Error("projective point not allowed");
			return r.is0(t) && r.is0(n) ? S.ZERO : new S(t, n, r.ONE);
		}
		static fromBytes(e) {
			let t = S.fromAffine(h(pe(e, void 0, "point")));
			return t.assertValidity(), t;
		}
		static fromHex(e) {
			return S.fromBytes(_e("pointHex", e));
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		precompute(e = 8, t = !0) {
			return w.createCache(this, e), t || this.multiply(Dt), this;
		}
		assertValidity() {
			re(this);
		}
		hasEvenY() {
			let { y: e } = this.toAffine();
			if (!r.isOdd) throw Error("Field doesn't support isOdd");
			return !r.isOdd(e);
		}
		equals(e) {
			ee(e);
			let { X: t, Y: n, Z: i } = this, { X: a, Y: o, Z: s } = e, c = r.eql(r.mul(t, s), r.mul(a, i)), l = r.eql(r.mul(n, s), r.mul(o, i));
			return c && l;
		}
		negate() {
			return new S(this.X, r.neg(this.Y), this.Z);
		}
		double() {
			let { a: e, b: t } = a, n = r.mul(t, Dt), { X: i, Y: o, Z: s } = this, c = r.ZERO, l = r.ZERO, u = r.ZERO, d = r.mul(i, i), f = r.mul(o, o), p = r.mul(s, s), m = r.mul(i, o);
			return m = r.add(m, m), u = r.mul(i, s), u = r.add(u, u), c = r.mul(e, u), l = r.mul(n, p), l = r.add(c, l), c = r.sub(f, l), l = r.add(f, l), l = r.mul(c, l), c = r.mul(m, c), u = r.mul(n, u), p = r.mul(e, p), m = r.sub(d, p), m = r.mul(e, m), m = r.add(m, u), u = r.add(d, d), d = r.add(u, d), d = r.add(d, p), d = r.mul(d, m), l = r.add(l, d), p = r.mul(o, s), p = r.add(p, p), d = r.mul(p, m), c = r.sub(c, d), u = r.mul(p, f), u = r.add(u, u), u = r.add(u, u), new S(c, l, u);
		}
		add(e) {
			ee(e);
			let { X: t, Y: n, Z: i } = this, { X: o, Y: s, Z: c } = e, l = r.ZERO, u = r.ZERO, d = r.ZERO, f = a.a, p = r.mul(a.b, Dt), m = r.mul(t, o), h = r.mul(n, s), g = r.mul(i, c), _ = r.add(t, n), v = r.add(o, s);
			_ = r.mul(_, v), v = r.add(m, h), _ = r.sub(_, v), v = r.add(t, i);
			let y = r.add(o, c);
			return v = r.mul(v, y), y = r.add(m, g), v = r.sub(v, y), y = r.add(n, i), l = r.add(s, c), y = r.mul(y, l), l = r.add(h, g), y = r.sub(y, l), d = r.mul(f, v), l = r.mul(p, g), d = r.add(l, d), l = r.sub(h, d), d = r.add(h, d), u = r.mul(l, d), h = r.add(m, m), h = r.add(h, m), g = r.mul(f, g), v = r.mul(p, v), h = r.add(h, g), g = r.sub(m, g), g = r.mul(f, g), v = r.add(v, g), m = r.mul(h, v), u = r.add(u, m), m = r.mul(y, v), l = r.mul(_, l), l = r.sub(l, m), m = r.mul(_, h), d = r.mul(y, d), d = r.add(d, m), new S(l, u, d);
		}
		subtract(e) {
			return this.add(e.negate());
		}
		is0() {
			return this.equals(S.ZERO);
		}
		multiply(e) {
			let { endo: n } = t;
			if (!i.isValidNot0(e)) throw Error("invalid scalar: out of range");
			let r, a, o = (e) => w.cached(this, e, (e) => Ze(S, e));
			if (n) {
				let { k1neg: t, k1: i, k2neg: s, k2: c } = te(e), { p: l, f: u } = o(i), { p: d, f } = o(c);
				a = u.add(f), r = ie(n.beta, l, d, t, s);
			} else {
				let { p: t, f: n } = o(e);
				r = t, a = n;
			}
			return Ze(S, [r, a])[0];
		}
		multiplyUnsafe(e) {
			let { endo: n } = t, r = this;
			if (!i.isValid(e)) throw Error("invalid scalar: out of range");
			if (e === Et || r.is0()) return S.ZERO;
			if (e === I) return r;
			if (w.hasCache(this)) return this.multiply(e);
			if (n) {
				let { k1neg: t, k1: i, k2neg: a, k2: o } = te(e), { p1: s, p2: c } = ct(S, r, i, o);
				return ie(n.beta, s, c, t, a);
			} else return w.unsafe(r, e);
		}
		multiplyAndAddUnsafe(e, t, n) {
			let r = this.multiplyUnsafe(t).add(e.multiplyUnsafe(n));
			return r.is0() ? void 0 : r;
		}
		toAffine(e) {
			return ne(this, e);
		}
		isTorsionFree() {
			let { isTorsionFree: e } = t;
			return o === I ? !0 : e ? e(S, this) : w.unsafe(this, s).is0();
		}
		clearCofactor() {
			let { clearCofactor: e } = t;
			return o === I ? this : e ? e(S, this) : this.multiplyUnsafe(o);
		}
		isSmallOrder() {
			return this.multiplyUnsafe(o).is0();
		}
		toBytes(e = !0) {
			return fe(e, "isCompressed"), this.assertValidity(), p(S, this, e);
		}
		toHex(e = !0) {
			return m(this.toBytes(e));
		}
		toString() {
			return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
		}
		get px() {
			return this.X;
		}
		get py() {
			return this.X;
		}
		get pz() {
			return this.Z;
		}
		toRawBytes(e = !0) {
			return this.toBytes(e);
		}
		_setWindowSize(e) {
			this.precompute(e);
		}
		static normalizeZ(e) {
			return Ze(S, e);
		}
		static msm(e, t) {
			return lt(S, i, e, t);
		}
		static fromPrivateKey(e) {
			return S.BASE.multiply(kt(i, e));
		}
	}
	S.BASE = new S(a.Gx, a.Gy, r.ONE), S.ZERO = new S(r.ZERO, r.ONE, r.ZERO), S.Fp = r, S.Fn = i;
	let C = i.BITS, w = new st(S, t.endo ? Math.ceil(C / 2) : C);
	return S.BASE.precompute(8), S;
}
function jt(e) {
	return Uint8Array.of(e ? 2 : 3);
}
function Mt(e, t) {
	let n = e.ORDER, r = Et;
	for (let e = n - I; e % L === Et; e /= L) r += I;
	let i = r, a = L << i - I - I, o = a * L, s = (n - I) / o, c = (s - I) / L, l = o - I, u = a, d = e.pow(t, s), f = e.pow(t, (s + I) / L), p = (t, n) => {
		let r = d, a = e.pow(n, l), o = e.sqr(a);
		o = e.mul(o, n);
		let s = e.mul(t, o);
		s = e.pow(s, c), s = e.mul(s, a), a = e.mul(s, n), o = e.mul(s, t);
		let p = e.mul(o, a);
		s = e.pow(p, u);
		let m = e.eql(s, e.ONE);
		a = e.mul(o, f), s = e.mul(p, r), o = e.cmov(a, o, m), p = e.cmov(s, p, m);
		for (let t = i; t > I; t--) {
			let n = t - L;
			n = L << n - I;
			let i = e.pow(p, n), s = e.eql(i, e.ONE);
			a = e.mul(o, r), r = e.mul(r, r), i = e.mul(p, r), o = e.cmov(a, o, s), p = e.cmov(i, p, s);
		}
		return {
			isValid: m,
			value: o
		};
	};
	if (e.ORDER % Ot === Dt) {
		let n = (e.ORDER - Dt) / Ot, r = e.sqrt(e.neg(t));
		p = (t, i) => {
			let a = e.sqr(i), o = e.mul(t, i);
			a = e.mul(a, o);
			let s = e.pow(a, n);
			s = e.mul(s, o);
			let c = e.mul(s, r), l = e.mul(e.sqr(s), i), u = e.eql(l, t);
			return {
				isValid: u,
				value: e.cmov(c, s, u)
			};
		};
	}
	return p;
}
function Nt(e, t) {
	Ve(e);
	let { A: n, B: r, Z: i } = t;
	if (!e.isValid(n) || !e.isValid(r) || !e.isValid(i)) throw Error("mapToCurveSimpleSWU: invalid opts");
	let a = Mt(e, i);
	if (!e.isOdd) throw Error("Field does not have .isOdd()");
	return (t) => {
		let o, s, c, l, u, d, f, p;
		o = e.sqr(t), o = e.mul(o, i), s = e.sqr(o), s = e.add(s, o), c = e.add(s, e.ONE), c = e.mul(c, r), l = e.cmov(i, e.neg(s), !e.eql(s, e.ZERO)), l = e.mul(l, n), s = e.sqr(c), d = e.sqr(l), u = e.mul(d, n), s = e.add(s, u), s = e.mul(s, c), d = e.mul(d, l), u = e.mul(d, r), s = e.add(s, u), f = e.mul(o, c);
		let { isValid: m, value: h } = a(s, d);
		p = e.mul(o, t), p = e.mul(p, h), f = e.cmov(f, c, m), p = e.cmov(p, h, m);
		let g = e.isOdd(t) === e.isOdd(p);
		p = e.cmov(e.neg(p), p, g);
		let _ = N(e, [l], !0)[0];
		return f = e.mul(f, _), {
			x: f,
			y: p
		};
	};
}
function Pt(e, t) {
	return {
		secretKey: t.BYTES,
		publicKey: 1 + e.BYTES,
		publicKeyUncompressed: 1 + 2 * e.BYTES,
		publicKeyHasPrefix: !0,
		signature: 2 * t.BYTES
	};
}
function Ft(e) {
	let { CURVE: t, curveOpts: n } = It(e);
	return Rt(e, At(t, n));
}
function It(e) {
	let t = {
		a: e.a,
		b: e.b,
		p: e.Fp.ORDER,
		n: e.n,
		h: e.h,
		Gx: e.Gx,
		Gy: e.Gy
	}, n = e.Fp, r = e.allowedPrivateKeyLengths ? Array.from(new Set(e.allowedPrivateKeyLengths.map((e) => Math.ceil(e / 2)))) : void 0;
	return {
		CURVE: t,
		curveOpts: {
			Fp: n,
			Fn: Ge(t.n, {
				BITS: e.nBitLength,
				allowedLengths: r,
				modFromBytes: e.wrapPrivateKey
			}),
			allowInfinityPoint: e.allowInfinityPoint,
			endo: e.endo,
			isTorsionFree: e.isTorsionFree,
			clearCofactor: e.clearCofactor,
			fromBytes: e.fromBytes,
			toBytes: e.toBytes
		}
	};
}
function Lt(e, t, n) {
	function r(r) {
		let i = e.sqr(r), a = e.mul(i, r);
		return e.add(e.add(a, e.mul(r, t)), n);
	}
	return r;
}
function Rt(e, t) {
	let { Fp: n, Fn: r } = t;
	function i(e) {
		return ye(e, I, r.ORDER);
	}
	let a = Lt(n, e.a, e.b);
	return Object.assign({}, {
		CURVE: e,
		Point: t,
		ProjectivePoint: t,
		normPrivateKeyToScalar: (e) => kt(r, e),
		weierstrassEquation: a,
		isWithinCurveOrder: i
	});
}
var zt = BigInt(0), Bt = BigInt(1), Vt = BigInt(2), Ht = BigInt(3);
function Ut(e) {
	let t = [];
	for (; e > Bt; e >>= Bt) (e & Bt) === zt ? t.unshift(0) : (e & Ht) === Ht ? (t.unshift(-1), e += Bt) : t.unshift(1);
	return t;
}
function Wt(e) {
	if (!Array.isArray(e) || e.length === 0) throw Error("expected non-empty array");
}
function Gt(e, t, n, r) {
	let { Fp2: i, Fp12: a } = e, { twistType: o, ateLoopSize: s, xNegative: c, postPrecompute: l } = r, u;
	if (o === "multiplicative") u = (e, t, n, r, o, s) => a.mul014(r, e, i.mul(t, o), i.mul(n, s));
	else if (o === "divisive") u = (e, t, n, r, o, s) => a.mul034(r, i.mul(n, s), i.mul(t, o), e);
	else throw Error("bls: unknown twist type");
	let d = i.div(i.ONE, i.mul(i.ONE, Vt));
	function f(e, t, n, r) {
		let a = i.sqr(n), o = i.sqr(r), s = i.mulByB(i.mul(o, Ht)), c = i.mul(s, Ht), l = i.sub(i.sub(i.sqr(i.add(n, r)), o), a), u = i.sub(s, a), f = i.mul(i.sqr(t), Ht), p = i.neg(l);
		return e.push([
			u,
			f,
			p
		]), t = i.mul(i.mul(i.mul(i.sub(a, c), t), n), d), n = i.sub(i.sqr(i.mul(i.add(a, c), d)), i.mul(i.sqr(s), Ht)), r = i.mul(a, l), {
			Rx: t,
			Ry: n,
			Rz: r
		};
	}
	function p(e, t, n, r, a, o) {
		let s = i.sub(n, i.mul(o, r)), c = i.sub(t, i.mul(a, r)), l = i.sub(i.mul(s, a), i.mul(c, o)), u = i.neg(s), d = c;
		e.push([
			l,
			u,
			d
		]);
		let f = i.sqr(c), p = i.mul(f, c), m = i.mul(f, t), h = i.add(i.sub(p, i.mul(m, Vt)), i.mul(i.sqr(s), r));
		return t = i.mul(c, h), n = i.sub(i.mul(i.sub(m, h), s), i.mul(p, n)), r = i.mul(r, p), {
			Rx: t,
			Ry: n,
			Rz: r
		};
	}
	let m = Ut(s), h = Te((e) => {
		let { x: t, y: n } = e.toAffine(), r = t, a = n, o = i.neg(n), s = r, c = a, u = i.ONE, d = [];
		for (let e of m) {
			let t = [];
			({Rx: s, Ry: c, Rz: u} = f(t, s, c, u)), e && ({Rx: s, Ry: c, Rz: u} = p(t, s, c, u, r, e === -1 ? o : a)), d.push(t);
		}
		if (l) {
			let e = d[d.length - 1];
			l(s, c, u, r, a, p.bind(null, e));
		}
		return d;
	});
	function g(e, t = !1) {
		let n = a.ONE;
		if (e.length) {
			let t = e[0][0].length;
			for (let r = 0; r < t; r++) {
				n = a.sqr(n);
				for (let [t, i, a] of e) for (let [e, o, s] of t[r]) n = u(e, o, s, n, i, a);
			}
		}
		return c && (n = a.conjugate(n)), t ? a.finalExponentiate(n) : n;
	}
	function _(e, r = !0) {
		let i = [];
		Ze(t, e.map(({ g1: e }) => e)), Ze(n, e.map(({ g2: e }) => e));
		for (let { g1: t, g2: n } of e) {
			if (t.is0() || n.is0()) throw Error("pairing is not available for ZERO point");
			t.assertValidity(), n.assertValidity();
			let e = t.toAffine();
			i.push([
				h(n),
				e.x,
				e.y
			]);
		}
		return g(i, r);
	}
	function v(e, t, n = !0) {
		return _([{
			g1: e,
			g2: t
		}], n);
	}
	return {
		Fp12: a,
		millerLoopBatch: g,
		pairing: v,
		pairingBatch: _,
		calcPairingPrecomputes: h
	};
}
function Kt(e, t, n, r, i) {
	let { Fp12: o, pairingBatch: s } = e;
	function c(e) {
		return e instanceof t.Point ? e : t.Point.fromHex(e);
	}
	function l(e) {
		return e instanceof n.Point ? e : n.Point.fromHex(e);
	}
	function u(e) {
		if (!(e instanceof n.Point)) throw Error(`expected valid message hashed to ${i ? "G1" : "G2"} curve`);
		return e;
	}
	let d = i ? (e, t) => ({
		g1: t,
		g2: e
	}) : (e, t) => ({
		g1: e,
		g2: t
	});
	return {
		getPublicKey(e) {
			let n = kt(t.Point.Fn, e);
			return t.Point.BASE.multiply(n);
		},
		sign(e, n, r) {
			if (r != null) throw Error("sign() expects 2 arguments");
			let i = kt(t.Point.Fn, n);
			return u(e).assertValidity(), e.multiply(i);
		},
		verify(e, n, r, i) {
			if (i != null) throw Error("verify() expects 3 arguments");
			e = l(e), r = c(r);
			let a = r.negate(), f = t.Point.BASE, p = u(n), m = e, h = s([d(a, p), d(f, m)]);
			return o.eql(h, o.ONE);
		},
		verifyBatch(e, n, r) {
			if (Wt(n), r.length !== n.length) throw Error("amount of public keys and messages should be equal");
			let i = l(e), a = n, u = r.map(c), f = /* @__PURE__ */ new Map();
			for (let e = 0; e < u.length; e++) {
				let t = u[e], n = a[e], r = f.get(n);
				r === void 0 && (r = [], f.set(n, r)), r.push(t);
			}
			let p = [], m = t.Point.BASE;
			try {
				for (let [e, t] of f) {
					let n = t.reduce((e, t) => e.add(t));
					p.push(d(n, e));
				}
				return p.push(d(m.negate(), i)), o.eql(s(p), o.ONE);
			} catch {
				return !1;
			}
		},
		aggregatePublicKeys(e) {
			Wt(e), e = e.map((e) => c(e));
			let n = e.reduce((e, t) => e.add(t), t.Point.ZERO);
			return n.assertValidity(), n;
		},
		aggregateSignatures(e) {
			Wt(e), e = e.map((e) => l(e));
			let t = e.reduce((e, t) => e.add(t), n.Point.ZERO);
			return t.assertValidity(), t;
		},
		hash(e, t) {
			a(e);
			let r = t ? { DST: t } : void 0;
			return n.hashToCurve(e, r);
		},
		Signature: r
	};
}
function qt(e) {
	let { Fp: t, Fr: n, Fp2: r, Fp6: i, Fp12: a } = e.fields, o = Ft(e.G1), s = Object.assign(o, xt(o.Point, e.G1.mapToCurve, {
		...e.htfDefaults,
		...e.G1.htfDefaults
	})), c = Ft(e.G2), l = Object.assign(c, xt(c.Point, e.G2.mapToCurve, {
		...e.htfDefaults,
		...e.G2.htfDefaults
	})), u = Gt(e.fields, s.Point, l.Point, {
		...e.params,
		postPrecompute: e.postPrecompute
	}), { millerLoopBatch: d, pairing: f, pairingBatch: p, calcPairingPrecomputes: m } = u, h = Kt(u, s, l, e.G2.Signature, !1), g = Kt(u, l, s, e.G1.ShortSignature, !0), _ = e.randomBytes || te, v = () => {
		let e = qe(n.ORDER);
		return Je(_(e), n.ORDER);
	}, y = {
		randomSecretKey: v,
		randomPrivateKey: v,
		calcPairingPrecomputes: m
	}, { ShortSignature: b } = e.G1, { Signature: x } = e.G2;
	function ee(e, t) {
		return e instanceof s.Point ? e : g.hash(_e("point", e), t?.DST);
	}
	function ne(e, t) {
		return e instanceof l.Point ? e : h.hash(_e("point", e), t?.DST);
	}
	function re(e) {
		return h.getPublicKey(e).toBytes(!0);
	}
	function ie(e) {
		return g.getPublicKey(e).toBytes(!0);
	}
	function S(e, t, n) {
		let r = ne(e, n), i = h.sign(r, t);
		return e instanceof l.Point ? i : x.toBytes(i);
	}
	function C(e, t, n) {
		let r = ee(e, n), i = g.sign(r, t);
		return e instanceof s.Point ? i : b.toBytes(i);
	}
	function w(e, t, n, r) {
		let i = ne(t, r);
		return h.verify(e, i, n);
	}
	function ae(e, t, n, r) {
		let i = ee(t, r);
		return g.verify(e, i, n);
	}
	function T(e) {
		let t = h.aggregatePublicKeys(e);
		return e[0] instanceof s.Point ? t : t.toBytes(!0);
	}
	function oe(e) {
		let t = h.aggregateSignatures(e);
		return e[0] instanceof l.Point ? t : x.toBytes(t);
	}
	function se(e) {
		let t = g.aggregateSignatures(e);
		return e[0] instanceof s.Point ? t : b.toBytes(t);
	}
	function ce(e, t, n, r) {
		let i = t.map((e) => ne(e, r));
		return h.verifyBatch(e, i, n);
	}
	return s.Point.BASE.precompute(4), {
		longSignatures: h,
		shortSignatures: g,
		millerLoopBatch: d,
		pairing: f,
		pairingBatch: p,
		verifyBatch: ce,
		fields: {
			Fr: n,
			Fp: t,
			Fp2: r,
			Fp6: i,
			Fp12: a
		},
		params: {
			ateLoopSize: e.params.ateLoopSize,
			twistType: e.params.twistType,
			r: e.params.r,
			G1b: e.G1.b,
			G2b: e.G2.b
		},
		utils: y,
		getPublicKey: re,
		getPublicKeyForShortSignatures: ie,
		sign: S,
		signShortSignature: C,
		verify: w,
		verifyShortSignature: ae,
		aggregatePublicKeys: T,
		aggregateSignatures: oe,
		aggregateShortSignatures: se,
		G1: s,
		G2: l,
		Signature: x,
		ShortSignature: b
	};
}
var Jt = BigInt(0), R = BigInt(1), z = BigInt(2), Yt = BigInt(3);
function Xt(e, t, n, r, i = 1, a) {
	let o = BigInt(a === void 0 ? r : a), s = n ** BigInt(r), c = [];
	for (let a = 0; a < i; a++) {
		let i = BigInt(a + 1), l = [];
		for (let a = 0, c = R; a < r; a++) {
			let r = (i * c - i) / o % s;
			l.push(e.pow(t, r)), c *= n;
		}
		c.push(l);
	}
	return c;
}
function Zt(e, t, n) {
	let r = t.pow(n, (e.ORDER - R) / Yt), i = t.pow(n, (e.ORDER - R) / z);
	function a(e, n) {
		return [t.mul(t.frobeniusMap(e, 1), r), t.mul(t.frobeniusMap(n, 1), i)];
	}
	let o = t.pow(n, (e.ORDER ** z - R) / Yt), s = t.pow(n, (e.ORDER ** z - R) / z);
	if (!t.eql(s, t.neg(t.ONE))) throw Error("psiFrobenius: PSI2_Y!==-1");
	function c(e, n) {
		return [t.mul(e, o), t.neg(n)];
	}
	let l = (e) => (t, n) => {
		let r = n.toAffine(), i = e(r.x, r.y);
		return t.fromAffine({
			x: i[0],
			y: i[1]
		});
	};
	return {
		psi: a,
		psi2: c,
		G2psi: l(a),
		G2psi2: l(c),
		PSI_X: r,
		PSI_Y: i,
		PSI2_X: o,
		PSI2_Y: s
	};
}
var Qt = (e, t) => {
	if (t.length !== 2) throw Error("invalid tuple");
	let n = t.map((t) => e.create(t));
	return {
		c0: n[0],
		c1: n[1]
	};
}, $t = class {
	constructor(e, t = {}) {
		this.MASK = R;
		let n = e.ORDER, r = n * n;
		this.Fp = e, this.ORDER = r, this.BITS = be(r), this.BYTES = Math.ceil(be(r) / 8), this.isLE = e.isLE, this.ZERO = {
			c0: e.ZERO,
			c1: e.ZERO
		}, this.ONE = {
			c0: e.ONE,
			c1: e.ZERO
		}, this.Fp_NONRESIDUE = e.create(t.NONRESIDUE || BigInt(-1)), this.Fp_div2 = e.div(e.ONE, z), this.NONRESIDUE = Qt(e, t.FP2_NONRESIDUE), this.FROBENIUS_COEFFICIENTS = Xt(e, this.Fp_NONRESIDUE, e.ORDER, 2)[0], this.mulByB = t.Fp2mulByB, Object.seal(this);
	}
	fromBigTuple(e) {
		return Qt(this.Fp, e);
	}
	create(e) {
		return e;
	}
	isValid({ c0: e, c1: t }) {
		function n(e, t) {
			return typeof e == "bigint" && Jt <= e && e < t;
		}
		return n(e, this.ORDER) && n(t, this.ORDER);
	}
	is0({ c0: e, c1: t }) {
		return this.Fp.is0(e) && this.Fp.is0(t);
	}
	isValidNot0(e) {
		return !this.is0(e) && this.isValid(e);
	}
	eql({ c0: e, c1: t }, { c0: n, c1: r }) {
		return this.Fp.eql(e, n) && this.Fp.eql(t, r);
	}
	neg({ c0: e, c1: t }) {
		return {
			c0: this.Fp.neg(e),
			c1: this.Fp.neg(t)
		};
	}
	pow(e, t) {
		return He(this, e, t);
	}
	invertBatch(e) {
		return N(this, e);
	}
	add(e, t) {
		let { c0: n, c1: r } = e, { c0: i, c1: a } = t;
		return {
			c0: this.Fp.add(n, i),
			c1: this.Fp.add(r, a)
		};
	}
	sub({ c0: e, c1: t }, { c0: n, c1: r }) {
		return {
			c0: this.Fp.sub(e, n),
			c1: this.Fp.sub(t, r)
		};
	}
	mul({ c0: e, c1: t }, n) {
		let { Fp: r } = this;
		if (typeof n == "bigint") return {
			c0: r.mul(e, n),
			c1: r.mul(t, n)
		};
		let { c0: i, c1: a } = n, o = r.mul(e, i), s = r.mul(t, a);
		return {
			c0: r.sub(o, s),
			c1: r.sub(r.mul(r.add(e, t), r.add(i, a)), r.add(o, s))
		};
	}
	sqr({ c0: e, c1: t }) {
		let { Fp: n } = this, r = n.add(e, t), i = n.sub(e, t), a = n.add(e, e);
		return {
			c0: n.mul(r, i),
			c1: n.mul(a, t)
		};
	}
	addN(e, t) {
		return this.add(e, t);
	}
	subN(e, t) {
		return this.sub(e, t);
	}
	mulN(e, t) {
		return this.mul(e, t);
	}
	sqrN(e) {
		return this.sqr(e);
	}
	div(e, t) {
		let { Fp: n } = this;
		return this.mul(e, typeof t == "bigint" ? n.inv(n.create(t)) : this.inv(t));
	}
	inv({ c0: e, c1: t }) {
		let { Fp: n } = this, r = n.inv(n.create(e * e + t * t));
		return {
			c0: n.mul(r, n.create(e)),
			c1: n.mul(r, n.create(-t))
		};
	}
	sqrt(e) {
		let { Fp: t } = this, n = this, { c0: r, c1: i } = e;
		if (t.is0(i)) return Ue(t, r) === 1 ? n.create({
			c0: t.sqrt(r),
			c1: t.ZERO
		}) : n.create({
			c0: t.ZERO,
			c1: t.sqrt(t.div(r, this.Fp_NONRESIDUE))
		});
		let a = t.sqrt(t.sub(t.sqr(r), t.mul(t.sqr(i), this.Fp_NONRESIDUE))), o = t.mul(t.add(a, r), this.Fp_div2);
		Ue(t, o) === -1 && (o = t.sub(o, a));
		let s = t.sqrt(o), c = n.create({
			c0: s,
			c1: t.div(t.mul(i, this.Fp_div2), s)
		});
		if (!n.eql(n.sqr(c), e)) throw Error("Cannot find square root");
		let l = c, u = n.neg(l), { re: d, im: f } = n.reim(l), { re: p, im: m } = n.reim(u);
		return f > m || f === m && d > p ? l : u;
	}
	isOdd(e) {
		let { re: t, im: n } = this.reim(e), r = t % z, i = t === Jt, a = n % z;
		return BigInt(r || i && a) == R;
	}
	fromBytes(e) {
		let { Fp: t } = this;
		if (e.length !== this.BYTES) throw Error("fromBytes invalid length=" + e.length);
		return {
			c0: t.fromBytes(e.subarray(0, t.BYTES)),
			c1: t.fromBytes(e.subarray(t.BYTES))
		};
	}
	toBytes({ c0: e, c1: t }) {
		return b(this.Fp.toBytes(e), this.Fp.toBytes(t));
	}
	cmov({ c0: e, c1: t }, { c0: n, c1: r }, i) {
		return {
			c0: this.Fp.cmov(e, n, i),
			c1: this.Fp.cmov(t, r, i)
		};
	}
	reim({ c0: e, c1: t }) {
		return {
			re: e,
			im: t
		};
	}
	Fp4Square(e, t) {
		let n = this, r = n.sqr(e), i = n.sqr(t);
		return {
			first: n.add(n.mulByNonresidue(i), r),
			second: n.sub(n.sub(n.sqr(n.add(e, t)), r), i)
		};
	}
	mulByNonresidue({ c0: e, c1: t }) {
		return this.mul({
			c0: e,
			c1: t
		}, this.NONRESIDUE);
	}
	frobeniusMap({ c0: e, c1: t }, n) {
		return {
			c0: e,
			c1: this.Fp.mul(t, this.FROBENIUS_COEFFICIENTS[n % 2])
		};
	}
}, en = class {
	constructor(e) {
		this.MASK = R, this.Fp2 = e, this.ORDER = e.ORDER, this.BITS = 3 * e.BITS, this.BYTES = 3 * e.BYTES, this.isLE = e.isLE, this.ZERO = {
			c0: e.ZERO,
			c1: e.ZERO,
			c2: e.ZERO
		}, this.ONE = {
			c0: e.ONE,
			c1: e.ZERO,
			c2: e.ZERO
		};
		let { Fp: t } = e, n = Xt(e, e.NONRESIDUE, t.ORDER, 6, 2, 3);
		this.FROBENIUS_COEFFICIENTS_1 = n[0], this.FROBENIUS_COEFFICIENTS_2 = n[1], Object.seal(this);
	}
	add({ c0: e, c1: t, c2: n }, { c0: r, c1: i, c2: a }) {
		let { Fp2: o } = this;
		return {
			c0: o.add(e, r),
			c1: o.add(t, i),
			c2: o.add(n, a)
		};
	}
	sub({ c0: e, c1: t, c2: n }, { c0: r, c1: i, c2: a }) {
		let { Fp2: o } = this;
		return {
			c0: o.sub(e, r),
			c1: o.sub(t, i),
			c2: o.sub(n, a)
		};
	}
	mul({ c0: e, c1: t, c2: n }, r) {
		let { Fp2: i } = this;
		if (typeof r == "bigint") return {
			c0: i.mul(e, r),
			c1: i.mul(t, r),
			c2: i.mul(n, r)
		};
		let { c0: a, c1: o, c2: s } = r, c = i.mul(e, a), l = i.mul(t, o), u = i.mul(n, s);
		return {
			c0: i.add(c, i.mulByNonresidue(i.sub(i.mul(i.add(t, n), i.add(o, s)), i.add(l, u)))),
			c1: i.add(i.sub(i.mul(i.add(e, t), i.add(a, o)), i.add(c, l)), i.mulByNonresidue(u)),
			c2: i.sub(i.add(l, i.mul(i.add(e, n), i.add(a, s))), i.add(c, u))
		};
	}
	sqr({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this, i = r.sqr(e), a = r.mul(r.mul(e, t), z), o = r.mul(r.mul(t, n), z), s = r.sqr(n);
		return {
			c0: r.add(r.mulByNonresidue(o), i),
			c1: r.add(r.mulByNonresidue(s), a),
			c2: r.sub(r.sub(r.add(r.add(a, r.sqr(r.add(r.sub(e, t), n))), o), i), s)
		};
	}
	addN(e, t) {
		return this.add(e, t);
	}
	subN(e, t) {
		return this.sub(e, t);
	}
	mulN(e, t) {
		return this.mul(e, t);
	}
	sqrN(e) {
		return this.sqr(e);
	}
	create(e) {
		return e;
	}
	isValid({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this;
		return r.isValid(e) && r.isValid(t) && r.isValid(n);
	}
	is0({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this;
		return r.is0(e) && r.is0(t) && r.is0(n);
	}
	isValidNot0(e) {
		return !this.is0(e) && this.isValid(e);
	}
	neg({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this;
		return {
			c0: r.neg(e),
			c1: r.neg(t),
			c2: r.neg(n)
		};
	}
	eql({ c0: e, c1: t, c2: n }, { c0: r, c1: i, c2: a }) {
		let { Fp2: o } = this;
		return o.eql(e, r) && o.eql(t, i) && o.eql(n, a);
	}
	sqrt(e) {
		return we();
	}
	div(e, t) {
		let { Fp2: n } = this, { Fp: r } = n;
		return this.mul(e, typeof t == "bigint" ? r.inv(r.create(t)) : this.inv(t));
	}
	pow(e, t) {
		return He(this, e, t);
	}
	invertBatch(e) {
		return N(this, e);
	}
	inv({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this, i = r.sub(r.sqr(e), r.mulByNonresidue(r.mul(n, t))), a = r.sub(r.mulByNonresidue(r.sqr(n)), r.mul(e, t)), o = r.sub(r.sqr(t), r.mul(e, n)), s = r.inv(r.add(r.mulByNonresidue(r.add(r.mul(n, a), r.mul(t, o))), r.mul(e, i)));
		return {
			c0: r.mul(s, i),
			c1: r.mul(s, a),
			c2: r.mul(s, o)
		};
	}
	fromBytes(e) {
		let { Fp2: t } = this;
		if (e.length !== this.BYTES) throw Error("fromBytes invalid length=" + e.length);
		let n = t.BYTES;
		return {
			c0: t.fromBytes(e.subarray(0, n)),
			c1: t.fromBytes(e.subarray(n, n * 2)),
			c2: t.fromBytes(e.subarray(2 * n))
		};
	}
	toBytes({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this;
		return b(r.toBytes(e), r.toBytes(t), r.toBytes(n));
	}
	cmov({ c0: e, c1: t, c2: n }, { c0: r, c1: i, c2: a }, o) {
		let { Fp2: s } = this;
		return {
			c0: s.cmov(e, r, o),
			c1: s.cmov(t, i, o),
			c2: s.cmov(n, a, o)
		};
	}
	fromBigSix(e) {
		let { Fp2: t } = this;
		if (!Array.isArray(e) || e.length !== 6) throw Error("invalid Fp6 usage");
		return {
			c0: t.fromBigTuple(e.slice(0, 2)),
			c1: t.fromBigTuple(e.slice(2, 4)),
			c2: t.fromBigTuple(e.slice(4, 6))
		};
	}
	frobeniusMap({ c0: e, c1: t, c2: n }, r) {
		let { Fp2: i } = this;
		return {
			c0: i.frobeniusMap(e, r),
			c1: i.mul(i.frobeniusMap(t, r), this.FROBENIUS_COEFFICIENTS_1[r % 6]),
			c2: i.mul(i.frobeniusMap(n, r), this.FROBENIUS_COEFFICIENTS_2[r % 6])
		};
	}
	mulByFp2({ c0: e, c1: t, c2: n }, r) {
		let { Fp2: i } = this;
		return {
			c0: i.mul(e, r),
			c1: i.mul(t, r),
			c2: i.mul(n, r)
		};
	}
	mulByNonresidue({ c0: e, c1: t, c2: n }) {
		let { Fp2: r } = this;
		return {
			c0: r.mulByNonresidue(n),
			c1: e,
			c2: t
		};
	}
	mul1({ c0: e, c1: t, c2: n }, r) {
		let { Fp2: i } = this;
		return {
			c0: i.mulByNonresidue(i.mul(n, r)),
			c1: i.mul(e, r),
			c2: i.mul(t, r)
		};
	}
	mul01({ c0: e, c1: t, c2: n }, r, i) {
		let { Fp2: a } = this, o = a.mul(e, r), s = a.mul(t, i);
		return {
			c0: a.add(a.mulByNonresidue(a.sub(a.mul(a.add(t, n), i), s)), o),
			c1: a.sub(a.sub(a.mul(a.add(r, i), a.add(e, t)), o), s),
			c2: a.add(a.sub(a.mul(a.add(e, n), r), o), s)
		};
	}
}, tn = class {
	constructor(e, t) {
		this.MASK = R;
		let { Fp2: n } = e, { Fp: r } = n;
		this.Fp6 = e, this.ORDER = n.ORDER, this.BITS = 2 * e.BITS, this.BYTES = 2 * e.BYTES, this.isLE = e.isLE, this.ZERO = {
			c0: e.ZERO,
			c1: e.ZERO
		}, this.ONE = {
			c0: e.ONE,
			c1: e.ZERO
		}, this.FROBENIUS_COEFFICIENTS = Xt(n, n.NONRESIDUE, r.ORDER, 12, 1, 6)[0], this.X_LEN = t.X_LEN, this.finalExponentiate = t.Fp12finalExponentiate;
	}
	create(e) {
		return e;
	}
	isValid({ c0: e, c1: t }) {
		let { Fp6: n } = this;
		return n.isValid(e) && n.isValid(t);
	}
	is0({ c0: e, c1: t }) {
		let { Fp6: n } = this;
		return n.is0(e) && n.is0(t);
	}
	isValidNot0(e) {
		return !this.is0(e) && this.isValid(e);
	}
	neg({ c0: e, c1: t }) {
		let { Fp6: n } = this;
		return {
			c0: n.neg(e),
			c1: n.neg(t)
		};
	}
	eql({ c0: e, c1: t }, { c0: n, c1: r }) {
		let { Fp6: i } = this;
		return i.eql(e, n) && i.eql(t, r);
	}
	sqrt(e) {
		we();
	}
	inv({ c0: e, c1: t }) {
		let { Fp6: n } = this, r = n.inv(n.sub(n.sqr(e), n.mulByNonresidue(n.sqr(t))));
		return {
			c0: n.mul(e, r),
			c1: n.neg(n.mul(t, r))
		};
	}
	div(e, t) {
		let { Fp6: n } = this, { Fp2: r } = n, { Fp: i } = r;
		return this.mul(e, typeof t == "bigint" ? i.inv(i.create(t)) : this.inv(t));
	}
	pow(e, t) {
		return He(this, e, t);
	}
	invertBatch(e) {
		return N(this, e);
	}
	add({ c0: e, c1: t }, { c0: n, c1: r }) {
		let { Fp6: i } = this;
		return {
			c0: i.add(e, n),
			c1: i.add(t, r)
		};
	}
	sub({ c0: e, c1: t }, { c0: n, c1: r }) {
		let { Fp6: i } = this;
		return {
			c0: i.sub(e, n),
			c1: i.sub(t, r)
		};
	}
	mul({ c0: e, c1: t }, n) {
		let { Fp6: r } = this;
		if (typeof n == "bigint") return {
			c0: r.mul(e, n),
			c1: r.mul(t, n)
		};
		let { c0: i, c1: a } = n, o = r.mul(e, i), s = r.mul(t, a);
		return {
			c0: r.add(o, r.mulByNonresidue(s)),
			c1: r.sub(r.mul(r.add(e, t), r.add(i, a)), r.add(o, s))
		};
	}
	sqr({ c0: e, c1: t }) {
		let { Fp6: n } = this, r = n.mul(e, t);
		return {
			c0: n.sub(n.sub(n.mul(n.add(n.mulByNonresidue(t), e), n.add(e, t)), r), n.mulByNonresidue(r)),
			c1: n.add(r, r)
		};
	}
	addN(e, t) {
		return this.add(e, t);
	}
	subN(e, t) {
		return this.sub(e, t);
	}
	mulN(e, t) {
		return this.mul(e, t);
	}
	sqrN(e) {
		return this.sqr(e);
	}
	fromBytes(e) {
		let { Fp6: t } = this;
		if (e.length !== this.BYTES) throw Error("fromBytes invalid length=" + e.length);
		return {
			c0: t.fromBytes(e.subarray(0, t.BYTES)),
			c1: t.fromBytes(e.subarray(t.BYTES))
		};
	}
	toBytes({ c0: e, c1: t }) {
		let { Fp6: n } = this;
		return b(n.toBytes(e), n.toBytes(t));
	}
	cmov({ c0: e, c1: t }, { c0: n, c1: r }, i) {
		let { Fp6: a } = this;
		return {
			c0: a.cmov(e, n, i),
			c1: a.cmov(t, r, i)
		};
	}
	fromBigTwelve(e) {
		let { Fp6: t } = this;
		return {
			c0: t.fromBigSix(e.slice(0, 6)),
			c1: t.fromBigSix(e.slice(6, 12))
		};
	}
	frobeniusMap(e, t) {
		let { Fp6: n } = this, { Fp2: r } = n, { c0: i, c1: a, c2: o } = n.frobeniusMap(e.c1, t), s = this.FROBENIUS_COEFFICIENTS[t % 12];
		return {
			c0: n.frobeniusMap(e.c0, t),
			c1: n.create({
				c0: r.mul(i, s),
				c1: r.mul(a, s),
				c2: r.mul(o, s)
			})
		};
	}
	mulByFp2({ c0: e, c1: t }, n) {
		let { Fp6: r } = this;
		return {
			c0: r.mulByFp2(e, n),
			c1: r.mulByFp2(t, n)
		};
	}
	conjugate({ c0: e, c1: t }) {
		return {
			c0: e,
			c1: this.Fp6.neg(t)
		};
	}
	mul014({ c0: e, c1: t }, n, r, i) {
		let { Fp6: a } = this, { Fp2: o } = a, s = a.mul01(e, n, r), c = a.mul1(t, i);
		return {
			c0: a.add(a.mulByNonresidue(c), s),
			c1: a.sub(a.sub(a.mul01(a.add(t, e), n, o.add(r, i)), s), c)
		};
	}
	mul034({ c0: e, c1: t }, n, r, i) {
		let { Fp6: a } = this, { Fp2: o } = a, s = a.create({
			c0: o.mul(e.c0, n),
			c1: o.mul(e.c1, n),
			c2: o.mul(e.c2, n)
		}), c = a.mul01(t, r, i), l = a.mul01(a.add(e, t), o.add(n, r), i);
		return {
			c0: a.add(a.mulByNonresidue(c), s),
			c1: a.sub(l, a.add(s, c))
		};
	}
	_cyclotomicSquare({ c0: e, c1: t }) {
		let { Fp6: n } = this, { Fp2: r } = n, { c0: i, c1: a, c2: o } = e, { c0: s, c1: c, c2: l } = t, { first: u, second: d } = r.Fp4Square(i, c), { first: f, second: p } = r.Fp4Square(s, o), { first: m, second: h } = r.Fp4Square(a, l), g = r.mulByNonresidue(h);
		return {
			c0: n.create({
				c0: r.add(r.mul(r.sub(u, i), z), u),
				c1: r.add(r.mul(r.sub(f, a), z), f),
				c2: r.add(r.mul(r.sub(m, o), z), m)
			}),
			c1: n.create({
				c0: r.add(r.mul(r.add(g, s), z), g),
				c1: r.add(r.mul(r.add(d, c), z), d),
				c2: r.add(r.mul(r.add(p, l), z), p)
			})
		};
	}
	_cyclotomicExp(e, t) {
		let n = this.ONE;
		for (let r = this.X_LEN - 1; r >= 0; r--) n = this._cyclotomicSquare(n), xe(t, r) && (n = this.mul(n, e));
		return n;
	}
};
function nn(e) {
	let t = Ge(e.ORDER), n = new $t(t, e), r = new en(n);
	return {
		Fp: t,
		Fp2: n,
		Fp6: r,
		Fp12: new tn(r, e)
	};
}
var B = BigInt(0), rn = BigInt(1), V = BigInt(2), an = BigInt(3), on = BigInt(4), H = BigInt("0xd201000000010000"), sn = be(H), U = {
	p: BigInt("0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaaab"),
	n: BigInt("0x73eda753299d7d483339d80809a1d80553bda402fffe5bfeffffffff00000001"),
	h: BigInt("0x396c8c005555e1568c00aaab0000aaab"),
	a: B,
	b: on,
	Gx: BigInt("0x17f1d3a73197d7942695638c4fa9ac0fc3688c4f9774b905a14e3a3f171bac586c55e83ff97a1aeffb3af00adb22c6bb"),
	Gy: BigInt("0x08b3f481e3aaa0f1a09e30ed741d8ae4fcf5e095d5d00af600db18cb2c04b3edd03cc744a2888ae40caa232946c5e7e1")
}, cn = Ge(U.n, {
	modFromBytes: !0,
	isLE: !0
}), { Fp: W, Fp2: G, Fp6: ln, Fp12: K } = nn({
	ORDER: U.p,
	X_LEN: sn,
	FP2_NONRESIDUE: [rn, rn],
	Fp2mulByB: ({ c0: e, c1: t }) => {
		let n = W.mul(e, on), r = W.mul(t, on);
		return {
			c0: W.sub(n, r),
			c1: W.add(n, r)
		};
	},
	Fp12finalExponentiate: (e) => {
		let t = H, n = K.div(K.frobeniusMap(e, 6), e), r = K.mul(K.frobeniusMap(n, 2), n), i = K.conjugate(K._cyclotomicExp(r, t)), a = K.mul(K.conjugate(K._cyclotomicSquare(r)), i), o = K.conjugate(K._cyclotomicExp(a, t)), s = K.conjugate(K._cyclotomicExp(o, t)), c = K.mul(K.conjugate(K._cyclotomicExp(s, t)), K._cyclotomicSquare(i)), l = K.conjugate(K._cyclotomicExp(c, t)), u = K.frobeniusMap(K.mul(i, s), 2), d = K.frobeniusMap(K.mul(o, r), 3), f = K.frobeniusMap(K.mul(c, K.conjugate(r)), 1), p = K.mul(K.mul(l, K.conjugate(a)), r);
		return K.mul(K.mul(K.mul(u, d), f), p);
	}
}), { G2psi: un, G2psi2: dn } = Zt(W, G, G.div(G.ONE, G.NONRESIDUE)), fn = Object.freeze({
	DST: "BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_NUL_",
	encodeDST: "BLS_SIG_BLS12381G2_XMD:SHA-256_SSWU_RO_NUL_",
	p: W.ORDER,
	m: 2,
	k: 128,
	expand: "xmd",
	hash: ce
}), pn = {
	p: G.ORDER,
	n: U.n,
	h: BigInt("0x5d543a95414e7f1091d50792876a202cd91de4547085abaa68a205b2e5a7ddfa628f1cb4d9e82ef21537e293a6691ae1616ec6e786f0c70cf1c38e31c7238e5"),
	a: G.ZERO,
	b: G.fromBigTuple([on, on]),
	Gx: G.fromBigTuple([BigInt("0x024aa2b2f08f0a91260805272dc51051c6e47ad4fa403b02b4510b647ae3d1770bac0326a805bbefd48056c8c121bdb8"), BigInt("0x13e02b6052719f607dacd3a088274f65596bd0d09920b61ab5da61bbdc7f5049334cf11213945d57e5ac7d055d042b7e")]),
	Gy: G.fromBigTuple([BigInt("0x0ce5d527727d6e118cc9cdc6da2e351aadfd9baa8cbdd3a76d429a695160d12c923ac9cc3baca289e193548608b82801"), BigInt("0x0606c4a02ea734cc32acd2b02bc28b99cb3e287e85a763af267492ab572e99ab3f370d275cec1da1aaa9075ff05f79be")])
}, mn = gn(W.toBytes(B), {
	infinity: !0,
	compressed: !0
});
function hn(e) {
	e = e.slice();
	let t = e[0] & 224, n = !!(t >> 7 & 1), r = !!(t >> 6 & 1), i = !!(t >> 5 & 1);
	return e[0] &= 31, {
		compressed: n,
		infinity: r,
		sort: i,
		value: e
	};
}
function gn(e, t) {
	if (e[0] & 224) throw Error("setMask: non-empty mask");
	return t.compressed && (e[0] |= 128), t.infinity && (e[0] |= 64), t.sort && (e[0] |= 32), e;
}
function _n(e, t, n) {
	let { BYTES: r, ORDER: i } = W, a = t.is0(), { x: o, y: s } = t.toAffine();
	if (n) {
		if (a) return mn.slice();
		let e = !!(s * V / i);
		return gn(D(o, r), {
			compressed: !0,
			sort: e
		});
	} else if (a) return b(Uint8Array.of(64), new Uint8Array(2 * r - 1));
	else return b(D(o, r), D(s, r));
}
function vn(e) {
	e.assertValidity();
	let { BYTES: t, ORDER: n } = W, { x: r, y: i } = e.toAffine();
	if (e.is0()) return mn.slice();
	let a = !!(i * V / n);
	return gn(D(r, t), {
		compressed: !0,
		sort: a
	});
}
function yn(e) {
	let { compressed: t, infinity: n, sort: r, value: i } = hn(e), { BYTES: a, ORDER: o } = W;
	if (i.length === 48 && t) {
		let e = E(i), t = W.create(e & O(W.BITS));
		if (n) {
			if (t !== B) throw Error("invalid G1 point: non-empty, at infinity, with compression");
			return {
				x: B,
				y: B
			};
		}
		let a = W.add(W.pow(t, an), W.create(U.b)), s = W.sqrt(a);
		if (!s) throw Error("invalid G1 point: compressed point");
		return s * V / o !== BigInt(r) && (s = W.neg(s)), {
			x: W.create(t),
			y: W.create(s)
		};
	} else if (i.length === 96 && !t) {
		let e = E(i.subarray(0, a)), t = E(i.subarray(a));
		if (n) {
			if (e !== B || t !== B) throw Error("G1: non-empty point at infinity");
			return q.G1.Point.ZERO.toAffine();
		}
		return {
			x: W.create(e),
			y: W.create(t)
		};
	} else throw Error("invalid G1 point: expected 48/96 bytes");
}
function bn(e) {
	let { infinity: t, sort: n, value: r } = hn(_e("signatureHex", e, 48)), i = W.ORDER, a = q.G1.Point, o = E(r);
	if (t) return a.ZERO;
	let s = W.create(o & O(W.BITS)), c = W.add(W.pow(s, an), W.create(U.b)), l = W.sqrt(c);
	if (!l) throw Error("invalid G1 point: compressed");
	let u = BigInt(n);
	l * V / i !== u && (l = W.neg(l));
	let d = a.fromAffine({
		x: s,
		y: l
	});
	return d.assertValidity(), d;
}
function xn(e, t, n) {
	let { BYTES: r, ORDER: i } = W, a = t.is0(), { x: o, y: s } = t.toAffine();
	if (n) {
		if (a) return b(mn, D(B, r));
		let e = !!(s.c1 === B ? s.c0 * V / i : s.c1 * V / i);
		return b(gn(D(o.c1, r), {
			compressed: !0,
			sort: e
		}), D(o.c0, r));
	} else {
		if (a) return b(Uint8Array.of(64), new Uint8Array(4 * r - 1));
		let { re: e, im: t } = G.reim(o), { re: n, im: i } = G.reim(s);
		return b(D(t, r), D(e, r), D(i, r), D(n, r));
	}
}
function Sn(e) {
	e.assertValidity();
	let { BYTES: t } = W;
	if (e.is0()) return b(mn, D(B, t));
	let { x: n, y: r } = e.toAffine(), { re: i, im: a } = G.reim(n), { re: o, im: s } = G.reim(r), c = !!((s > B ? s * V : o * V) / W.ORDER & rn), l = i;
	return b(gn(D(a, t), {
		sort: c,
		compressed: !0
	}), D(l, t));
}
function Cn(e) {
	let { BYTES: t, ORDER: n } = W, { compressed: r, infinity: i, sort: a, value: o } = hn(e);
	if (!r && !i && a || !r && i && a || a && i && r) throw Error("invalid encoding flag: " + (e[0] & 224));
	let s = (e, t, n) => E(e.slice(t, n));
	if (o.length === 96 && r) {
		if (i) {
			if (o.reduce((e, t) => e === 0 ? t : t + 1, 0) > 0) throw Error("invalid G2 point: compressed");
			return {
				x: G.ZERO,
				y: G.ZERO
			};
		}
		let e = s(o, 0, t), r = s(o, t, 2 * t), c = G.create({
			c0: W.create(r),
			c1: W.create(e)
		}), l = G.add(G.pow(c, an), pn.b), u = G.sqrt(l), d = u.c1 === B ? u.c0 * V / n : u.c1 * V / n ? rn : B;
		return u = a && d > 0 ? u : G.neg(u), {
			x: c,
			y: u
		};
	} else if (o.length === 192 && !r) {
		if (i) {
			if (o.reduce((e, t) => e === 0 ? t : t + 1, 0) > 0) throw Error("invalid G2 point: uncompressed");
			return {
				x: G.ZERO,
				y: G.ZERO
			};
		}
		let e = s(o, 0 * t, 1 * t), n = s(o, 1 * t, 2 * t), r = s(o, 2 * t, 3 * t), a = s(o, 3 * t, 4 * t);
		return {
			x: G.fromBigTuple([n, e]),
			y: G.fromBigTuple([a, r])
		};
	} else throw Error("invalid G2 point: expected 96/192 bytes");
}
function wn(e) {
	let { ORDER: t } = W, { infinity: n, sort: r, value: i } = hn(_e("signatureHex", e)), a = q.G2.Point, o = i.length / 2;
	if (o !== 48 && o !== 96) throw Error("invalid compressed signature length, expected 96/192 bytes");
	let s = E(i.slice(0, o)), c = E(i.slice(o));
	if (n) return a.ZERO;
	let l = W.create(s & O(W.BITS)), u = W.create(c), d = G.create({
		c0: u,
		c1: l
	}), f = G.add(G.pow(d, an), pn.b), p = G.sqrt(f);
	if (!p) throw Error("Failed to find a square root");
	let { re: m, im: h } = G.reim(p), g = BigInt(r), _ = h > B && h * V / t !== g, v = h === B && m * V / t !== g;
	(_ || v) && (p = G.neg(p));
	let y = a.fromAffine({
		x: d,
		y: p
	});
	return y.assertValidity(), y;
}
var q = qt({
	fields: {
		Fp: W,
		Fp2: G,
		Fp6: ln,
		Fp12: K,
		Fr: cn
	},
	G1: {
		...U,
		Fp: W,
		htfDefaults: {
			...fn,
			m: 1,
			DST: "BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_NUL_"
		},
		wrapPrivateKey: !0,
		allowInfinityPoint: !0,
		isTorsionFree: (e, t) => {
			let n = BigInt("0x5f19672fdf76ce51ba69c6076a0f77eaddb3a93be6f89688de17d813620a00022e01fffffffefffe"), r = new e(W.mul(t.X, n), t.Y, t.Z);
			return t.multiplyUnsafe(H).negate().multiplyUnsafe(H).equals(r);
		},
		clearCofactor: (e, t) => t.multiplyUnsafe(H).add(t),
		mapToCurve: kn,
		fromBytes: yn,
		toBytes: _n,
		ShortSignature: {
			fromBytes(e) {
				return a(e), bn(e);
			},
			fromHex(e) {
				return bn(e);
			},
			toBytes(e) {
				return vn(e);
			},
			toRawBytes(e) {
				return vn(e);
			},
			toHex(e) {
				return m(vn(e));
			}
		}
	},
	G2: {
		...pn,
		Fp: G,
		hEff: BigInt("0xbc69f08f2ee75b3584c6a0ea91b352888e2a8e9145ad7689986ff031508ffe1329c2f178731db956d82bf015d1212b02ec0ec69d7477c1ae954cbc06689f6a359894c0adebbf6b4e8020005aaa95551"),
		htfDefaults: { ...fn },
		wrapPrivateKey: !0,
		allowInfinityPoint: !0,
		mapToCurve: An,
		isTorsionFree: (e, t) => t.multiplyUnsafe(H).negate().equals(un(e, t)),
		clearCofactor: (e, t) => {
			let n = H, r = t.multiplyUnsafe(n).negate(), i = un(e, t), a = t.double();
			return a = dn(e, a), a = a.subtract(i), i = r.add(i), i = i.multiplyUnsafe(n).negate(), a = a.add(i), a = a.subtract(r), a.subtract(t);
		},
		fromBytes: Cn,
		toBytes: xn,
		Signature: {
			fromBytes(e) {
				return a(e), wn(e);
			},
			fromHex(e) {
				return wn(e);
			},
			toBytes(e) {
				return Sn(e);
			},
			toRawBytes(e) {
				return Sn(e);
			},
			toHex(e) {
				return m(Sn(e));
			}
		}
	},
	params: {
		ateLoopSize: H,
		r: U.n,
		xNegative: !0,
		twistType: "multiplicative"
	},
	htfDefaults: fn,
	hash: ce
}), Tn = yt(G, [
	[
		["0x5c759507e8e333ebb5b7a9a47d7ed8532c52d39fd3a042a88b58423c50ae15d5c2638e343d9c71c6238aaaaaaaa97d6", "0x5c759507e8e333ebb5b7a9a47d7ed8532c52d39fd3a042a88b58423c50ae15d5c2638e343d9c71c6238aaaaaaaa97d6"],
		["0x0", "0x11560bf17baa99bc32126fced787c88f984f87adf7ae0c7f9a208c6b4f20a4181472aaa9cb8d555526a9ffffffffc71a"],
		["0x11560bf17baa99bc32126fced787c88f984f87adf7ae0c7f9a208c6b4f20a4181472aaa9cb8d555526a9ffffffffc71e", "0x8ab05f8bdd54cde190937e76bc3e447cc27c3d6fbd7063fcd104635a790520c0a395554e5c6aaaa9354ffffffffe38d"],
		["0x171d6541fa38ccfaed6dea691f5fb614cb14b4e7f4e810aa22d6108f142b85757098e38d0f671c7188e2aaaaaaaa5ed1", "0x0"]
	],
	[
		["0x0", "0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaa63"],
		["0xc", "0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaa9f"],
		["0x1", "0x0"]
	],
	[
		["0x1530477c7ab4113b59a4c18b076d11930f7da5d4a07f649bf54439d87d27e500fc8c25ebf8c92f6812cfc71c71c6d706", "0x1530477c7ab4113b59a4c18b076d11930f7da5d4a07f649bf54439d87d27e500fc8c25ebf8c92f6812cfc71c71c6d706"],
		["0x0", "0x5c759507e8e333ebb5b7a9a47d7ed8532c52d39fd3a042a88b58423c50ae15d5c2638e343d9c71c6238aaaaaaaa97be"],
		["0x11560bf17baa99bc32126fced787c88f984f87adf7ae0c7f9a208c6b4f20a4181472aaa9cb8d555526a9ffffffffc71c", "0x8ab05f8bdd54cde190937e76bc3e447cc27c3d6fbd7063fcd104635a790520c0a395554e5c6aaaa9354ffffffffe38f"],
		["0x124c9ad43b6cf79bfbf7043de3811ad0761b0f37a1e26286b0e977c69aa274524e79097a56dc4bd9e1b371c71c718b10", "0x0"]
	],
	[
		["0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffa8fb", "0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffa8fb"],
		["0x0", "0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffa9d3"],
		["0x12", "0x1a0111ea397fe69a4b1ba7b6434bacd764774b84f38512bf6730d2a0f6b0f6241eabfffeb153ffffb9feffffffffaa99"],
		["0x1", "0x0"]
	]
].map((e) => e.map((e) => G.fromBigTuple(e.map(BigInt))))), En = yt(W, [
	[
		"0x11a05f2b1e833340b809101dd99815856b303e88a2d7005ff2627b56cdb4e2c85610c2d5f2e62d6eaeac1662734649b7",
		"0x17294ed3e943ab2f0588bab22147a81c7c17e75b2f6a8417f565e33c70d1e86b4838f2a6f318c356e834eef1b3cb83bb",
		"0xd54005db97678ec1d1048c5d10a9a1bce032473295983e56878e501ec68e25c958c3e3d2a09729fe0179f9dac9edcb0",
		"0x1778e7166fcc6db74e0609d307e55412d7f5e4656a8dbf25f1b33289f1b330835336e25ce3107193c5b388641d9b6861",
		"0xe99726a3199f4436642b4b3e4118e5499db995a1257fb3f086eeb65982fac18985a286f301e77c451154ce9ac8895d9",
		"0x1630c3250d7313ff01d1201bf7a74ab5db3cb17dd952799b9ed3ab9097e68f90a0870d2dcae73d19cd13c1c66f652983",
		"0xd6ed6553fe44d296a3726c38ae652bfb11586264f0f8ce19008e218f9c86b2a8da25128c1052ecaddd7f225a139ed84",
		"0x17b81e7701abdbe2e8743884d1117e53356de5ab275b4db1a682c62ef0f2753339b7c8f8c8f475af9ccb5618e3f0c88e",
		"0x80d3cf1f9a78fc47b90b33563be990dc43b756ce79f5574a2c596c928c5d1de4fa295f296b74e956d71986a8497e317",
		"0x169b1f8e1bcfa7c42e0c37515d138f22dd2ecb803a0c5c99676314baf4bb1b7fa3190b2edc0327797f241067be390c9e",
		"0x10321da079ce07e272d8ec09d2565b0dfa7dccdde6787f96d50af36003b14866f69b771f8c285decca67df3f1605fb7b",
		"0x6e08c248e260e70bd1e962381edee3d31d79d7e22c837bc23c0bf1bc24c6b68c24b1b80b64d391fa9c8ba2e8ba2d229"
	],
	[
		"0x8ca8d548cff19ae18b2e62f4bd3fa6f01d5ef4ba35b48ba9c9588617fc8ac62b558d681be343df8993cf9fa40d21b1c",
		"0x12561a5deb559c4348b4711298e536367041e8ca0cf0800c0126c2588c48bf5713daa8846cb026e9e5c8276ec82b3bff",
		"0xb2962fe57a3225e8137e629bff2991f6f89416f5a718cd1fca64e00b11aceacd6a3d0967c94fedcfcc239ba5cb83e19",
		"0x3425581a58ae2fec83aafef7c40eb545b08243f16b1655154cca8abc28d6fd04976d5243eecf5c4130de8938dc62cd8",
		"0x13a8e162022914a80a6f1d5f43e7a07dffdfc759a12062bb8d6b44e833b306da9bd29ba81f35781d539d395b3532a21e",
		"0xe7355f8e4e667b955390f7f0506c6e9395735e9ce9cad4d0a43bcef24b8982f7400d24bc4228f11c02df9a29f6304a5",
		"0x772caacf16936190f3e0c63e0596721570f5799af53a1894e2e073062aede9cea73b3538f0de06cec2574496ee84a3a",
		"0x14a7ac2a9d64a8b230b3f5b074cf01996e7f63c21bca68a81996e1cdf9822c580fa5b9489d11e2d311f7d99bbdcc5a5e",
		"0xa10ecf6ada54f825e920b3dafc7a3cce07f8d1d7161366b74100da67f39883503826692abba43704776ec3a79a1d641",
		"0x95fc13ab9e92ad4476d6e3eb3a56680f682b4ee96f7d03776df533978f31c1593174e4b4b7865002d6384d168ecdd0a",
		"0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001"
	],
	[
		"0x90d97c81ba24ee0259d1f094980dcfa11ad138e48a869522b52af6c956543d3cd0c7aee9b3ba3c2be9845719707bb33",
		"0x134996a104ee5811d51036d776fb46831223e96c254f383d0f906343eb67ad34d6c56711962fa8bfe097e75a2e41c696",
		"0xcc786baa966e66f4a384c86a3b49942552e2d658a31ce2c344be4b91400da7d26d521628b00523b8dfe240c72de1f6",
		"0x1f86376e8981c217898751ad8746757d42aa7b90eeb791c09e4a3ec03251cf9de405aba9ec61deca6355c77b0e5f4cb",
		"0x8cc03fdefe0ff135caf4fe2a21529c4195536fbe3ce50b879833fd221351adc2ee7f8dc099040a841b6daecf2e8fedb",
		"0x16603fca40634b6a2211e11db8f0a6a074a7d0d4afadb7bd76505c3d3ad5544e203f6326c95a807299b23ab13633a5f0",
		"0x4ab0b9bcfac1bbcb2c977d027796b3ce75bb8ca2be184cb5231413c4d634f3747a87ac2460f415ec961f8855fe9d6f2",
		"0x987c8d5333ab86fde9926bd2ca6c674170a05bfe3bdd81ffd038da6c26c842642f64550fedfe935a15e4ca31870fb29",
		"0x9fc4018bd96684be88c9e221e4da1bb8f3abd16679dc26c1e8b6e6a1f20cabe69d65201c78607a360370e577bdba587",
		"0xe1bba7a1186bdb5223abde7ada14a23c42a0ca7915af6fe06985e7ed1e4d43b9b3f7055dd4eba6f2bafaaebca731c30",
		"0x19713e47937cd1be0dfd0b8f1d43fb93cd2fcbcb6caf493fd1183e416389e61031bf3a5cce3fbafce813711ad011c132",
		"0x18b46a908f36f6deb918c143fed2edcc523559b8aaf0c2462e6bfe7f911f643249d9cdf41b44d606ce07c8a4d0074d8e",
		"0xb182cac101b9399d155096004f53f447aa7b12a3426b08ec02710e807b4633f06c851c1919211f20d4c04f00b971ef8",
		"0x245a394ad1eca9b72fc00ae7be315dc757b3b080d4c158013e6632d3c40659cc6cf90ad1c232a6442d9d3f5db980133",
		"0x5c129645e44cf1102a159f748c4a3fc5e673d81d7e86568d9ab0f5d396a7ce46ba1049b6579afb7866b1e715475224b",
		"0x15e6be4e990f03ce4ea50b3b42df2eb5cb181d8f84965a3957add4fa95af01b2b665027efec01c7704b456be69c8b604"
	],
	[
		"0x16112c4c3a9c98b252181140fad0eae9601a6de578980be6eec3232b5be72e7a07f3688ef60c206d01479253b03663c1",
		"0x1962d75c2381201e1a0cbd6c43c348b885c84ff731c4d59ca4a10356f453e01f78a4260763529e3532f6102c2e49a03d",
		"0x58df3306640da276faaae7d6e8eb15778c4855551ae7f310c35a5dd279cd2eca6757cd636f96f891e2538b53dbf67f2",
		"0x16b7d288798e5395f20d23bf89edb4d1d115c5dbddbcd30e123da489e726af41727364f2c28297ada8d26d98445f5416",
		"0xbe0e079545f43e4b00cc912f8228ddcc6d19c9f0f69bbb0542eda0fc9dec916a20b15dc0fd2ededda39142311a5001d",
		"0x8d9e5297186db2d9fb266eaac783182b70152c65550d881c5ecd87b6f0f5a6449f38db9dfa9cce202c6477faaf9b7ac",
		"0x166007c08a99db2fc3ba8734ace9824b5eecfdfa8d0cf8ef5dd365bc400a0051d5fa9c01a58b1fb93d1a1399126a775c",
		"0x16a3ef08be3ea7ea03bcddfabba6ff6ee5a4375efa1f4fd7feb34fd206357132b920f5b00801dee460ee415a15812ed9",
		"0x1866c8ed336c61231a1be54fd1d74cc4f9fb0ce4c6af5920abc5750c4bf39b4852cfe2f7bb9248836b233d9d55535d4a",
		"0x167a55cda70a6e1cea820597d94a84903216f763e13d87bb5308592e7ea7d4fbc7385ea3d529b35e346ef48bb8913f55",
		"0x4d2f259eea405bd48f010a01ad2911d9c6dd039bb61a6290e591b36e636a5c871a5c29f4f83060400f8b49cba8f6aa8",
		"0xaccbb67481d033ff5852c1e48c50c477f94ff8aefce42d28c0f9a88cea7913516f968986f7ebbea9684b529e2561092",
		"0xad6b9514c767fe3c3613144b45f1496543346d98adf02267d5ceef9a00d9b8693000763e3b90ac11e99b138573345cc",
		"0x2660400eb2e4f3b628bdd0d53cd76f2bf565b94e72927c1cb748df27942480e420517bd8714cc80d1fadc1326ed06f7",
		"0xe0fa1d816ddc03e6b24255e0d7819c171c40f65e273b853324efcd6356caa205ca2f570f13497804415473a1d634b8f",
		"0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001"
	]
].map((e) => e.map((e) => BigInt(e)))), Dn = Nt(W, {
	A: W.create(BigInt("0x144698a3b8e9433d693a02c96d4982b0ea985383ee66a8d8e8981aefd881ac98936f8da0e0f97f5cf428082d584c1d")),
	B: W.create(BigInt("0x12e2908d11688030018b12e8753eee3b2016c1f0f24f4070a0b9c14fcef35ef55a23215a316ceaa5d1cc48e98e172be0")),
	Z: W.create(BigInt(11))
}), On = Nt(G, {
	A: G.create({
		c0: W.create(B),
		c1: W.create(BigInt(240))
	}),
	B: G.create({
		c0: W.create(BigInt(1012)),
		c1: W.create(BigInt(1012))
	}),
	Z: G.create({
		c0: W.create(BigInt(-2)),
		c1: W.create(BigInt(-1))
	})
});
function kn(e) {
	let { x: t, y: n } = Dn(W.create(e[0]));
	return En(t, n);
}
function An(e) {
	let { x: t, y: n } = On(G.fromBigTuple(e));
	return Tn(t, n);
}
function jn(e, t, n) {
	return o(e), n === void 0 && (n = new Uint8Array(e.outputLen)), Ct(e, y(n), y(t));
}
var Mn = /* @__PURE__ */ Uint8Array.from([0]), Nn = /* @__PURE__ */ Uint8Array.of();
function Pn(e, t, n, r = 32) {
	o(e), i(r);
	let a = e.outputLen;
	if (r > 255 * a) throw Error("Length should be <= 255*HashLen");
	let s = Math.ceil(r / a);
	n === void 0 && (n = Nn);
	let c = new Uint8Array(s * a), u = Ct.create(e, t), d = u._cloneInto(), f = new Uint8Array(u.outputLen);
	for (let e = 0; e < s; e++) Mn[0] = e + 1, d.update(e === 0 ? Nn : f).update(n).update(Mn).digestInto(f), c.set(f, a * e), u._cloneInto(d);
	return u.destroy(), d.destroy(), l(f, Mn), c.slice(0, r);
}
var Fn = (e, t, n, r, i) => Pn(e, jn(e, t, n), r, i), In = 48, Ln = class e {
	#e;
	#t;
	static random() {
		return new e(q.utils.randomSecretKey());
	}
	static deserialize(t) {
		if (t.length !== 32) throw Error("Invalid size for transport secret key");
		return new e(t);
	}
	publicKeyBytes() {
		return this.#t.toBytes(!0);
	}
	serialize() {
		return this.#e;
	}
	constructor(e) {
		this.#e = e;
		let t = q.G1.Point.BASE.multiply(q.G1.Point.Fn.fromBytes(this.#e));
		this.#t = t;
	}
};
function Rn(e) {
	let t = e.length, n = new Uint8Array(8 + t);
	for (let e = 7; e >= 0; e--) n[e] = t & 255, t >>>= 8;
	return n.set(e, 8), n;
}
var zn = /* @__PURE__ */ ((e) => (e.KEY_1 = "key_1", e.TEST_KEY_1 = "test_key_1", e))(zn || {}), Bn = /* @__PURE__ */ ((e) => (e.KEY_1 = "key_1", e.TEST_KEY_1 = "test_key_1", e.DFX_TEST_KEY = "dfx_test_key", e))(Bn || {});
function Vn(e) {
	let t = new Uint8Array(e.length / 2);
	for (let n = 0; n < e.length; n += 2) t[n / 2] = parseInt(e.substring(n, n + 2), 16);
	return t;
}
var Hn = class e {
	#e;
	static deserialize(t) {
		return new e(q.G2.Point.fromHex(t));
	}
	deriveCanisterKey(e) {
		let t = this.publicKeyBytes(), n = Wn(new Uint8Array([...Rn(t), ...Rn(e)]), "ic-vetkd-bls12-381-g2-canister-id"), r = q.G2.Point.BASE.multiply(n);
		return new Un(this.#e.add(r));
	}
	publicKeyBytes() {
		return this.#e.toBytes(!0);
	}
	static productionKey(t = "key_1") {
		if (t == "key_1") return e.deserialize(Vn("a9caf9ae8af0c7c7272f8a122133e2e0c7c0899b75e502bda9e109ca8193ded3ef042ed96db1125e1bdaad77d8cc60d917e122fe2501c45b96274f43705edf0cfd455bc66c3c060faa2fcd15486e76351edf91fecb993797273bbc8beaa47404"));
		if (t == "test_key_1") return e.deserialize(Vn("ad86e8ff845912f022a0838a502d763fdea547c9948f8cb20ea7738dd52c1c38dcb4c6ca9ac29f9ac690fc5ad7681cb41922b8dffbd65d94bff141f5fb5b6624eccc03bf850f222052df888cf9b1e47203556d7522271cbb879b2ef4b8c2bfb1"));
		throw Error("Unknown MasterPublicKeyId value for productionKey");
	}
	static pocketicKey(t = "key_1") {
		if (t == "key_1") return e.deserialize(Vn("8c800b5cff00463d26e8167369168827f1e48f4d8d60f71dd6a295580f65275b5f5f8e6a792c876b2c72492136530d0710a27522ee63977a76216c3cef9e70bfcb45b88736fc62142e7e0737848ce06cbb1f45a4a6a349b142ae5cf7853561e0"));
		if (t == "test_key_1") return e.deserialize(Vn("9069b82c7aae418cef27678291e7f2cb1a008a500eceba7199bffca12421b07c158987c6a22618af3d1958738b2835691028801f7663d311799733286c557c8979184bb62cb559a4d582fca7d2e48b860f08ed6641aef66a059ec891889a6218"));
		if (t == "dfx_test_key") return e.deserialize(Vn("b181c14cf9d04ba45d782c0067a44b0aaa9fc2acf94f1a875f0dae801af4f80339a7e6bf8b09fcf993824c8df3080b3f1409b688ca08cbd44d2cb28db9899f4aa3b5f06b9174240448e10be2f01f9f80079ea5431ce2d11d1c8d1c775333315f"));
		throw Error("Unknown PocketIcMasterPublicKeyId value for pocketicKey");
	}
	constructor(e) {
		this.#e = e;
	}
}, Un = class e {
	#e;
	static deserialize(t) {
		return new e(q.G2.Point.fromHex(t));
	}
	deriveSubKey(t) {
		if (t.length === 0) return this;
		{
			let n = this.publicKeyBytes(), r = Wn(new Uint8Array([...Rn(n), ...Rn(t)]), "ic-vetkd-bls12-381-g2-context"), i = q.G2.Point.BASE.multiply(r);
			return new e(this.getPoint().add(i));
		}
	}
	publicKeyBytes() {
		return this.#e.toBytes(!0);
	}
	getPoint() {
		return this.#e;
	}
	constructor(e) {
		this.#e = e;
	}
};
function Wn(e, t) {
	return q.G2.hashToScalar(e, { DST: t });
}
function Gn(e) {
	if (typeof e == "string") return new TextEncoder().encode(e);
	let t = new Uint8Array(e.length);
	return t.set(e), t;
}
function Kn(e, t) {
	let n = new TextEncoder().encode(e), r = Gn(t), i = new Uint8Array(n.length + r.length);
	return i.set(n, 0), i.set(r, n.length), i;
}
function qn(e, t, n) {
	return Fn(ce, e, /* @__PURE__ */ new Uint8Array(), t, n);
}
function Jn(e, t, n) {
	let r = e.publicKeyBytes(), i = new Uint8Array([...r, ...t]), a = q.shortSignatures.hash(i, "BLS_SIG_BLS12381G1_XMD:SHA-256_SSWU_RO_AUG_");
	return q.shortSignatures.verify(n, a, e.getPoint());
}
var Yn = class e {
	#e;
	#t;
	signatureBytes() {
		return this.#t;
	}
	serialize() {
		return this.#t;
	}
	deriveSymmetricKey(e, t) {
		return qn(this.#t, e, t);
	}
	async asDerivedKeyMaterial() {
		return tr.setup(this.#t);
	}
	static deserialize(t) {
		return new e(q.G1.Point.fromHex(t));
	}
	getPoint() {
		return this.#e;
	}
	constructor(e) {
		this.#e = e, this.#t = new Uint8Array(e.toBytes(!0));
	}
}, Xn = 12, Zn = 2, Qn = "IC GCMv2", $n = new TextEncoder().encode(Qn), er = 8, tr = class e {
	#e;
	#t;
	constructor(e, t) {
		this.#e = e, this.#t = t;
	}
	static async fromCryptoKey(t) {
		let n = {
			name: "HKDF",
			hash: "SHA-256",
			info: new TextEncoder().encode("ic-vetkd-bls12-381-g2-derived-key-material"),
			salt: /* @__PURE__ */ new Uint8Array()
		}, r = await crypto.subtle.deriveKey(n, t, {
			name: "AES-GCM",
			length: 256
		}, !0, ["encrypt"]), i = await crypto.subtle.exportKey("raw", r), a = await crypto.subtle.importKey("raw", i, { name: "HKDF" }, !1, ["deriveKey", "deriveBits"]);
		return new e(a, t);
	}
	static async setup(t) {
		let n = await globalThis.crypto.subtle.importKey("raw", t, "HKDF", !1, ["deriveKey", "deriveBits"]);
		return e.fromCryptoKey(n);
	}
	getCryptoKey() {
		return this.#t;
	}
	async deriveAesGcmCryptoKey(e, t) {
		let n = {
			name: "HKDF",
			hash: "SHA-256",
			length: 256,
			info: Kn("ic-vetkd-bls12-381-g2-aes-gcm-v" + t.toString() + "-", e),
			salt: /* @__PURE__ */ new Uint8Array()
		};
		return globalThis.crypto.subtle.deriveKey(n, this.#e, {
			name: "AES-GCM",
			length: 256
		}, !1, ["encrypt", "decrypt"]);
	}
	async encryptMessage(e, t, n) {
		let r = await this.deriveAesGcmCryptoKey(t, Zn), i = globalThis.crypto.getRandomValues(new Uint8Array(Xn)), a = Kn(Qn, n), o = new Uint8Array(await globalThis.crypto.subtle.encrypt({
			name: "AES-GCM",
			iv: i,
			additionalData: a
		}, r, Gn(e)));
		return new Uint8Array([
			...$n,
			...i,
			...o
		]);
	}
	async decryptMessage(e, t, n) {
		if (e.length < 36) throw Error("Invalid ciphertext, too short to possibly be valid");
		if (!rr(e.slice(0, er), $n)) if (n.length == 0) {
			let n = e.slice(0, Xn), r = e.slice(Xn), i = {
				name: "HKDF",
				hash: "SHA-256",
				length: 256,
				info: Gn(t),
				salt: /* @__PURE__ */ new Uint8Array()
			}, a = await globalThis.crypto.subtle.deriveKey(i, this.#t, {
				name: "AES-GCM",
				length: 256
			}, !1, ["decrypt"]);
			try {
				let e = await globalThis.crypto.subtle.decrypt({
					name: "AES-GCM",
					iv: n
				}, a, r);
				return new Uint8Array(e);
			} catch {
				throw Error("Decryption failed");
			}
		} else throw Error("Unknown header for AES-GCM encrypted ciphertext");
		let r = Kn(Qn, n), i = e.slice(er, 20), a = e.slice(20), o = await this.deriveAesGcmCryptoKey(t, Zn);
		try {
			let e = await globalThis.crypto.subtle.decrypt({
				name: "AES-GCM",
				iv: i,
				additionalData: r
			}, o, a);
			return new Uint8Array(e);
		} catch {
			throw Error("Decryption failed");
		}
	}
}, nr = class e {
	#e;
	#t;
	#n;
	static deserialize(t) {
		if (t.length !== 192) throw Error("Invalid EncryptedVetKey serialization");
		let n = q.G1.Point.fromHex(t.subarray(0, In)), r = q.G2.Point.fromHex(t.subarray(In, 144)), i = q.G1.Point.fromHex(t.subarray(144));
		return new e(n, r, i);
	}
	decryptAndVerify(e, t, n) {
		let r = q.G1.Point.BASE, i = q.G2.Point.BASE.negate(), a = q.fields.Fp12.ONE, o = q.pairingBatch([{
			g1: this.#e,
			g2: i
		}, {
			g1: r,
			g2: this.#t
		}]);
		if (!q.fields.Fp12.eql(o, a)) throw Error("Invalid VetKey");
		let s = this.#n.subtract(this.#e.multiply(q.G1.Point.Fn.fromBytes(e.serialize())));
		if (Jn(t, n, s)) return new Yn(s);
		throw Error("Invalid VetKey");
	}
	constructor(e, t, n) {
		this.#e = e, this.#t = t, this.#n = n;
	}
};
new Uint8Array([
	73,
	67,
	32,
	73,
	66,
	69,
	0,
	1
]);
function rr(e, t) {
	if (e.length !== t.length) return !1;
	let n = 0;
	for (let r = 0; r < e.length; ++r) n |= e[r] ^ t[r];
	return n == 0;
}
var ir = "abcdefghijklmnopqrstuvwxyz234567", ar = Object.create(null);
for (let e = 0; e < 32; e++) ar[ir[e]] = e;
ar[0] = ar.o, ar[1] = ar.i;
function or(e) {
	let t = 0, n = 0, r = "";
	function i(e) {
		return t < 0 ? n |= e >> -t : n = e << t & 248, t > 3 ? (t -= 8, 1) : (t < 4 && (r += ir[n >> 3], t += 5), 0);
	}
	for (let t = 0; t < e.length;) t += i(e[t]);
	return r + (t < 0 ? ir[n >> 3] : "");
}
function sr(e) {
	let t = 0, n = 0, r = new Uint8Array(e.length * 4 / 3 | 0), i = 0;
	function a(e) {
		let a = ar[e.toLowerCase()];
		if (a === void 0) throw Error(`Invalid character: ${JSON.stringify(e)}`);
		a <<= 3, n |= a >>> t, t += 5, t >= 8 && (r[i++] = n, t -= 8, n = t > 0 ? a << 5 - t & 255 : 0);
	}
	for (let t of e) a(t);
	return r.slice(0, i);
}
var cr = new Uint32Array([
	0,
	1996959894,
	3993919788,
	2567524794,
	124634137,
	1886057615,
	3915621685,
	2657392035,
	249268274,
	2044508324,
	3772115230,
	2547177864,
	162941995,
	2125561021,
	3887607047,
	2428444049,
	498536548,
	1789927666,
	4089016648,
	2227061214,
	450548861,
	1843258603,
	4107580753,
	2211677639,
	325883990,
	1684777152,
	4251122042,
	2321926636,
	335633487,
	1661365465,
	4195302755,
	2366115317,
	997073096,
	1281953886,
	3579855332,
	2724688242,
	1006888145,
	1258607687,
	3524101629,
	2768942443,
	901097722,
	1119000684,
	3686517206,
	2898065728,
	853044451,
	1172266101,
	3705015759,
	2882616665,
	651767980,
	1373503546,
	3369554304,
	3218104598,
	565507253,
	1454621731,
	3485111705,
	3099436303,
	671266974,
	1594198024,
	3322730930,
	2970347812,
	795835527,
	1483230225,
	3244367275,
	3060149565,
	1994146192,
	31158534,
	2563907772,
	4023717930,
	1907459465,
	112637215,
	2680153253,
	3904427059,
	2013776290,
	251722036,
	2517215374,
	3775830040,
	2137656763,
	141376813,
	2439277719,
	3865271297,
	1802195444,
	476864866,
	2238001368,
	4066508878,
	1812370925,
	453092731,
	2181625025,
	4111451223,
	1706088902,
	314042704,
	2344532202,
	4240017532,
	1658658271,
	366619977,
	2362670323,
	4224994405,
	1303535960,
	984961486,
	2747007092,
	3569037538,
	1256170817,
	1037604311,
	2765210733,
	3554079995,
	1131014506,
	879679996,
	2909243462,
	3663771856,
	1141124467,
	855842277,
	2852801631,
	3708648649,
	1342533948,
	654459306,
	3188396048,
	3373015174,
	1466479909,
	544179635,
	3110523913,
	3462522015,
	1591671054,
	702138776,
	2966460450,
	3352799412,
	1504918807,
	783551873,
	3082640443,
	3233442989,
	3988292384,
	2596254646,
	62317068,
	1957810842,
	3939845945,
	2647816111,
	81470997,
	1943803523,
	3814918930,
	2489596804,
	225274430,
	2053790376,
	3826175755,
	2466906013,
	167816743,
	2097651377,
	4027552580,
	2265490386,
	503444072,
	1762050814,
	4150417245,
	2154129355,
	426522225,
	1852507879,
	4275313526,
	2312317920,
	282753626,
	1742555852,
	4189708143,
	2394877945,
	397917763,
	1622183637,
	3604390888,
	2714866558,
	953729732,
	1340076626,
	3518719985,
	2797360999,
	1068828381,
	1219638859,
	3624741850,
	2936675148,
	906185462,
	1090812512,
	3747672003,
	2825379669,
	829329135,
	1181335161,
	3412177804,
	3160834842,
	628085408,
	1382605366,
	3423369109,
	3138078467,
	570562233,
	1426400815,
	3317316542,
	2998733608,
	733239954,
	1555261956,
	3268935591,
	3050360625,
	752459403,
	1541320221,
	2607071920,
	3965973030,
	1969922972,
	40735498,
	2617837225,
	3943577151,
	1913087877,
	83908371,
	2512341634,
	3803740692,
	2075208622,
	213261112,
	2463272603,
	3855990285,
	2094854071,
	198958881,
	2262029012,
	4057260610,
	1759359992,
	534414190,
	2176718541,
	4139329115,
	1873836001,
	414664567,
	2282248934,
	4279200368,
	1711684554,
	285281116,
	2405801727,
	4167216745,
	1634467795,
	376229701,
	2685067896,
	3608007406,
	1308918612,
	956543938,
	2808555105,
	3495958263,
	1231636301,
	1047427035,
	2932959818,
	3654703836,
	1088359270,
	936918e3,
	2847714899,
	3736837829,
	1202900863,
	817233897,
	3183342108,
	3401237130,
	1404277552,
	615818150,
	3134207493,
	3453421203,
	1423857449,
	601450431,
	3009837614,
	3294710456,
	1567103746,
	711928724,
	3020668471,
	3272380065,
	1510334235,
	755167117
]);
function lr(e) {
	let t = -1;
	for (let n = 0; n < e.length; n++) t = cr[(e[n] ^ t) & 255] ^ t >>> 8;
	return (t ^ -1) >>> 0;
}
var ur = "__principal__", dr = 2, fr = 4, pr = "aaaaa-aa", mr = class e {
	static anonymous() {
		return new this(new Uint8Array([fr]));
	}
	static managementCanister() {
		return this.fromText(pr);
	}
	static selfAuthenticating(e) {
		let t = le(e);
		return new this(new Uint8Array([...t, dr]));
	}
	static from(t) {
		if (typeof t == "string") return e.fromText(t);
		if (Object.getPrototypeOf(t) === Uint8Array.prototype) return new e(t);
		if (e.isPrincipal(t)) return new e(t._arr);
		throw Error(`Impossible to convert ${JSON.stringify(t)} to Principal.`);
	}
	static fromHex(e) {
		return new this(_(e));
	}
	static fromText(e) {
		let t = e;
		if (e.includes("__principal__")) {
			let n = JSON.parse(e);
			"__principal__" in n && (t = n[ur]);
		}
		let n = sr(t.toLowerCase().replace(/-/g, ""));
		n = n.slice(4, n.length);
		let r = new this(n);
		if (r.toText() !== t) throw Error(`Principal "${r.toText()}" does not have a valid checksum (original value "${t}" may not be a valid Principal ID).`);
		return r;
	}
	static fromUint8Array(e) {
		return new this(e);
	}
	static isPrincipal(t) {
		return t instanceof e || typeof t == "object" && !!t && "_isPrincipal" in t && t._isPrincipal === !0 && "_arr" in t && t._arr instanceof Uint8Array;
	}
	constructor(e) {
		this._arr = e, this._isPrincipal = !0;
	}
	isAnonymous() {
		return this._arr.byteLength === 1 && this._arr[0] === fr;
	}
	toUint8Array() {
		return this._arr;
	}
	toHex() {
		return m(this._arr).toUpperCase();
	}
	toText() {
		let e = /* @__PURE__ */ new ArrayBuffer(4);
		new DataView(e).setUint32(0, lr(this._arr));
		let t = new Uint8Array(e), n = or(new Uint8Array([...t, ...this._arr])).match(/.{1,5}/g);
		if (!n) throw Error();
		return n.join("-");
	}
	toString() {
		return this.toText();
	}
	toJSON() {
		return { [ur]: this.toText() };
	}
	compareTo(e) {
		for (let t = 0; t < Math.min(this._arr.length, e._arr.length); t++) {
			if (this._arr[t] < e._arr[t]) return "lt";
			if (this._arr[t] > e._arr[t]) return "gt";
		}
		return this._arr.length < e._arr.length ? "lt" : this._arr.length > e._arr.length ? "gt" : "eq";
	}
	ltEq(e) {
		let t = this.compareTo(e);
		return t == "lt" || t == "eq";
	}
	gtEq(e) {
		let t = this.compareTo(e);
		return t == "gt" || t == "eq";
	}
}, hr = (e) => {
	let t = /* @__PURE__ */ new Uint8Array(4);
	return new DataView(t.buffer).setUint32(0, e.length), Cr(t, e);
};
function gr(e) {
	let t = mr.fromText(e.canister), n = mr.fromText(e.owner);
	if (t.isAnonymous() || n.isAnonymous() || !t.toUint8Array().length || !n.toUint8Array().length || e.vault.length !== 16 || e.nonce.length !== 32 || !e.key_name || J.encode(e.key_name).length > 64) throw Error("InvalidContext");
	return {
		canister: t.toText(),
		owner: n.toText(),
		vault: new Uint8Array(e.vault),
		nonce: new Uint8Array(e.nonce),
		key_name: e.key_name
	};
}
function _r(e) {
	let t = gr(e);
	return Cr(...[
		mr.fromText(t.canister).toUint8Array(),
		mr.fromText(t.owner).toUint8Array(),
		t.vault,
		t.nonce,
		J.encode(t.key_name)
	].map(hr));
}
function vr(e, t, n, r, i = 0) {
	if (t.length !== 16 || !Number.isSafeInteger(i) || i < 0 || i > 4294967295) throw Error("InvalidInput");
	let a = /* @__PURE__ */ new Uint8Array(4);
	return new DataView(a.buffer).setUint32(0, i), Cr(...[
		J.encode("kinic-vault/document/v3"),
		_r(e),
		t,
		wr(n),
		J.encode(r),
		a
	].map(hr));
}
var yr = (e, t) => e.length === t.length && e.every((e, n) => e === t[n]);
async function br(e, t, n, r, i) {
	let a = gr(e), o = _r(a), s = Or(a.key_name, i).deriveCanisterKey(mr.fromText(a.canister).toUint8Array()).deriveSubKey(J.encode("kinic-vault/ii-only/v1"));
	if (!yr(o, n.input) || !yr(s.publicKeyBytes(), t) || !yr(t, n.public_key)) throw Error("InvalidKeyContext");
	let c = nr.deserialize(n.encrypted_key).decryptAndVerify(r, s, o).deriveSymmetricKey("kinic-vault/root/v3", 32);
	try {
		return await Tr(c);
	} finally {
		c.fill(0);
	}
}
var xr = /* @__PURE__ */ t({
	TransportSecretKey: () => Ln,
	anchoredMaster: () => Or,
	concat: () => Cr,
	contextInput: () => _r,
	copyVaultContext: () => gr,
	documentAAD: () => vr,
	importKey: () => Tr,
	open: () => Dr,
	randomBytes: () => Y,
	seal: () => Er,
	u64: () => wr,
	utf8: () => J,
	verifiedRoot: () => br
}), J = new TextEncoder(), Y = (e) => {
	if (!Number.isSafeInteger(e) || e < 0 || e > 10485776) throw Error("InvalidInput");
	let t = new Uint8Array(e);
	for (let n = 0; n < e; n += 65536) crypto.getRandomValues(t.subarray(n, Math.min(e, n + 65536)));
	return t;
}, Sr = (e) => new Uint8Array(e).buffer, Cr = (...e) => {
	let t = new Uint8Array(e.reduce((e, t) => e + t.length, 0)), n = 0;
	for (let r of e) t.set(r, n), n += r.length;
	return t;
};
function wr(e) {
	if (e < 0n || e >= 1n << 64n) throw Error("InvalidInput");
	let t = /* @__PURE__ */ new Uint8Array(8);
	return new DataView(t.buffer).setBigUint64(0, e), t;
}
async function Tr(e) {
	if (e.length !== 32) throw Error("InvalidInput");
	return crypto.subtle.importKey("raw", Sr(e), "AES-GCM", !1, ["encrypt", "decrypt"]);
}
async function Er(e, t, n) {
	let r = Y(12);
	return {
		version: 3,
		nonce: r,
		ciphertext: new Uint8Array(await crypto.subtle.encrypt({
			name: "AES-GCM",
			iv: Sr(r),
			additionalData: Sr(n),
			tagLength: 128
		}, e, Sr(t)))
	};
}
async function Dr(e, t, n) {
	if (t.version !== 3 || t.nonce.length !== 12 || t.ciphertext.length < 16) throw Error("InvalidEnvelope");
	return new Uint8Array(await crypto.subtle.decrypt({
		name: "AES-GCM",
		iv: Sr(t.nonce),
		additionalData: Sr(n),
		tagLength: 128
	}, e, Sr(t.ciphertext)));
}
function Or(e, t) {
	if (e !== "test_key_1" && e !== "key_1") throw Error("UnsupportedKey");
	return t ? Hn.pocketicKey(e === "key_1" ? Bn.KEY_1 : Bn.TEST_KEY_1) : Hn.productionKey(e === "key_1" ? zn.KEY_1 : zn.TEST_KEY_1);
}
function kr(e) {
	let t = 0, n = () => {
		for (; /\s/.test(e[t] ?? "x");) t++;
	};
	function r() {
		let n = t++;
		for (; t < e.length;) {
			let r = e[t++];
			if (r === "\"") return JSON.parse(e.slice(n, t));
			r === "\\" && t++;
		}
		throw Error("InvalidJSON");
	}
	function i(a) {
		if (a > 32) throw Error("InvalidJSON");
		n();
		let o = e[t];
		if (o === "\"") {
			r();
			return;
		}
		if (o === "{" || o === "[") {
			t++, n();
			let s = o === "{" ? "}" : "]", c = /* @__PURE__ */ new Set();
			if (e[t] === s) {
				t++;
				return;
			}
			for (; t < e.length;) {
				if (o === "{") {
					if (n(), e[t] !== "\"") throw Error("InvalidJSON");
					let i = r();
					if (c.has(i)) throw Error("DuplicateField");
					if (c.add(i), n(), e[t++] !== ":") throw Error("InvalidJSON");
				}
				if (i(a + 1), n(), e[t] === s) {
					t++;
					return;
				}
				if (e[t++] !== ",") throw Error("InvalidJSON");
			}
			throw Error("InvalidJSON");
		}
		let s = t;
		for (; t < e.length && !/[\s,\]}]/.test(e[t]);) t++;
		if (t === s) throw Error("InvalidJSON");
		JSON.parse(e.slice(s, t));
	}
	if (i(0), n(), t !== e.length) throw Error("InvalidJSON");
	return JSON.parse(e);
}
var Ar = /* @__PURE__ */ t({
	b64: () => X,
	decryptDocument: () => Lr,
	decryptDocumentV3: () => Lr,
	encryptDocument: () => Fr,
	encryptDocumentV3: () => Fr,
	hash: () => Pr,
	pack: () => Mr,
	readManifest: () => Ir,
	readManifestV3: () => Ir,
	unb64: () => jr,
	unpack: () => Nr
}), X = (e) => {
	let t = "";
	for (let n of e) t += String.fromCharCode(n);
	return btoa(t).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
}, jr = (e) => {
	if (!/^[A-Za-z0-9_-]*$/.test(e)) throw Error("InvalidEncoding");
	let t = Uint8Array.from(atob(e.replaceAll("-", "+").replaceAll("_", "/")), (e) => e.charCodeAt(0));
	if (X(t) !== e) throw Error("InvalidEncoding");
	return t;
}, Mr = (e) => ({
	version: e.version,
	nonce: X(e.nonce),
	ciphertext: X(e.ciphertext)
}), Nr = (e) => ({
	version: e.version,
	nonce: jr(e.nonce),
	ciphertext: jr(e.ciphertext)
}), Pr = async (e) => new Uint8Array(await crypto.subtle.digest("SHA-256", new Uint8Array(e).buffer));
async function Fr(e, t, n, r, i, a) {
	if (a.length > 10 * 1024 * 1024 || i.kind !== "attachment" && a.length > 256 * 1024 || i.title.length > 512) throw Error("SizeLimit");
	let o = Y(32), s = await Tr(o), c = await Er(e, o, vr(t, n, r, "dek"));
	o.fill(0);
	let l = J.encode(JSON.stringify(i));
	if (l.length > 8192) throw Error("SizeLimit");
	let u = await Er(s, l, vr(t, n, r, "metadata")), d = [], f = [];
	for (let e = 0; e < Math.max(1, Math.ceil(a.length / 1048576)); e++) {
		let i = await Er(s, a.subarray(e * 1048576, (e + 1) * 1048576), vr(t, n, r, "chunk", e));
		d.push(i.ciphertext), f.push(X(i.nonce));
	}
	return {
		manifest: J.encode(JSON.stringify({
			version: 3,
			dek: Mr(c),
			metadata: Mr(u),
			nonces: f
		})),
		chunks: d,
		hashes: await Promise.all(d.map(Pr))
	};
}
async function Ir(e, t, n, r, i) {
	if (i.length > 65536) throw Error("InvalidManifest");
	let a = kr(new TextDecoder("utf-8", { fatal: !0 }).decode(i));
	if (a.version !== 3 || !Array.isArray(a.nonces) || a.nonces.length < 1 || a.nonces.length > 10) throw Error("InvalidManifest");
	let o = await Dr(e, Nr(a.dek), vr(t, n, r, "dek")), s = await Tr(o);
	o.fill(0);
	let c = JSON.parse(new TextDecoder("utf-8", { fatal: !0 }).decode(await Dr(s, Nr(a.metadata), vr(t, n, r, "metadata"))));
	if (![
		"note",
		"credential",
		"attachment"
	].includes(c.kind) || typeof c.title != "string") throw Error("InvalidMetadata");
	return {
		manifest: a,
		key: s,
		metadata: c
	};
}
async function Lr(e, t, n, r, i, a, o) {
	let s = await Ir(e, t, n, r, i);
	if (a.length !== s.manifest.nonces.length || o.length !== a.length) throw Error("MissingChunk");
	let c = [];
	for (let e = 0; e < a.length; e++) {
		if (X(await Pr(a[e])) !== X(o[e])) throw Error("CorruptChunk");
		c.push(await Dr(s.key, {
			version: 3,
			nonce: jr(s.manifest.nonces[e]),
			ciphertext: a[e]
		}, vr(t, n, r, "chunk", e)));
	}
	return {
		metadata: s.metadata,
		plaintext: Cr(...c)
	};
}
var Rr = class {
	cleanups = /* @__PURE__ */ new Set();
	binding;
	controller = new AbortController();
	generation = 0;
	root;
	lastActivity = Date.now();
	hiddenAt;
	urls = /* @__PURE__ */ new Set();
	onLock = () => {};
	get signal() {
		return this.controller.signal;
	}
	addLockCleanup(e) {
		return this.cleanups.add(e), () => this.cleanups.delete(e);
	}
	capture() {
		return this.generation;
	}
	check(e) {
		if (this.expire(), e !== this.generation) throw Error("Locked");
	}
	bindRoot(e, t) {
		this.binding = gr(t), this.root = e;
	}
	requireContext(e) {
		if (!this.root || !this.binding || !Z(_r(this.binding), _r(e))) throw this.lock(), Error("TargetChanged");
		return gr(this.binding);
	}
	lock() {
		this.generation++, this.controller.abort(), this.controller = new AbortController();
		for (let e of this.cleanups) try {
			e();
		} catch {}
		this.binding = void 0, this.root = void 0;
		for (let e of this.urls) URL.revokeObjectURL(e);
		this.urls.clear(), this.lastActivity = Date.now(), this.hiddenAt = this.hiddenAt === void 0 ? void 0 : Date.now(), this.onLock();
	}
	expire(e = Date.now()) {
		(e - this.lastActivity >= 3e5 || this.hiddenAt !== void 0 && e - this.hiddenAt >= 6e4) && this.lock();
	}
	activity() {
		this.expire(), this.lastActivity = Date.now();
	}
	visible(e) {
		this.expire(), this.hiddenAt = e ? this.hiddenAt ?? Date.now() : void 0;
	}
	download(e, t) {
		let n = URL.createObjectURL(new Blob([new Uint8Array(e).buffer]));
		this.urls.add(n);
		let r = document.createElement("a");
		r.href = n, r.download = t, r.click(), setTimeout(() => {
			URL.revokeObjectURL(n), this.urls.delete(n);
		}, 3e4);
	}
};
function Z(e, t) {
	return e.length === t.length && e.every((e, n) => e === t[n]);
}
var Q = (e) => new Uint8Array(e);
function $(e) {
	if ("Ok" in e) return e.Ok;
	throw Error(e.Err && typeof e.Err == "object" ? Object.keys(e.Err)[0] : "RequestFailed");
}
var zr = class {
	session = new Rr();
	actor;
	identity;
	canister;
	local;
	live = !0;
	header;
	pinnedPublicKey;
	creating;
	keyAttempt;
	request = { kind: "idle" };
	saveState = { kind: "idle" };
	cleanupState = { kind: "idle" };
	constructor(e) {
		if (e.identity.getPrincipal().isAnonymous()) throw Error("Unauthorized");
		this.actor = e.actor, this.identity = e.identity, this.canister = e.canister, this.local = e.local, this.session.addLockCleanup(() => {
			this.keyAttempt = void 0, this.pinnedPublicKey = void 0, this.request = { kind: "idle" }, this.cleanupState = { kind: "idle" }, this.pendingSave?.chunks.forEach((e) => e.fill(0)), this.saveState = { kind: "idle" };
		});
	}
	destroy() {
		this.live && (this.live = !1, this.session.lock(), this.header = void 0, this.creating = void 0);
	}
	checkLive() {
		if (!this.live) throw Error("NotSignedIn");
	}
	context(e) {
		return gr({
			canister: this.canister,
			owner: this.identity.getPrincipal().toText(),
			vault: Q(e.id),
			nonce: Q(e.nonce),
			key_name: e.key_name
		});
	}
	async reconcilePurchase(e) {
		this.checkLive();
		let t = this.session.capture(), n = this.identity.getPrincipal().toText(), r = new Uint8Array(e), i = await this.actor.reconcile_purchase(r);
		if (this.session.check(t), this.checkLive(), n !== this.identity.getPrincipal().toText()) throw Error("TargetChanged");
		let a = $(i);
		if (a.payment.wallet.toText() !== n || !Z(Q(a.payment.request.operation), r)) throw Error("InvalidReceipt");
		return a;
	}
	async listVaults() {
		this.checkLive();
		let e = this.session.capture(), t = $(await this.actor.list_vaults());
		return this.session.check(e), t;
	}
	async create() {
		this.checkLive(), (!this.creating || this.header && !Z(Q(this.header.id), this.creating.vault)) && (this.session.lock(), this.header = void 0);
		let e = this.session.capture(), t = this.creating ??= {
			vault: Y(16),
			operation: Y(16)
		}, n = $(await this.actor.create_vault(t));
		if (this.session.check(e), !Z(Q(n.id), t.vault)) throw Error("TargetChanged");
		return this.header = structuredClone(n), this.creating = void 0, structuredClone(n);
	}
	async open(e) {
		this.checkLive(), (!this.header || !Z(Q(this.header.id), Q(e.id))) && (this.session.lock(), this.header = structuredClone(e));
		let t = this.session.capture(), n = async () => {
			let n = await this.actor.get_vault_header(e.id);
			if (this.session.check(t), "Err" in n && ("NotFound" in n.Err || "Conflict" in n.Err)) throw this.session.lock(), Error("TargetChanged");
			return structuredClone($(n));
		}, r = await n();
		if (this.session.check(t), !Z(Q(r.id), Q(e.id)) || !("Active" in r.state)) throw this.session.lock(), Error("TargetChanged");
		let i;
		try {
			i = this.context(r);
		} catch {
			throw this.session.lock(), Error("TargetChanged");
		}
		if (this.session.root) {
			if (this.session.requireContext(i), !this.pinnedPublicKey || !Z(this.pinnedPublicKey, Q(r.public_key))) throw this.session.lock(), Error("TargetChanged");
			this.header = r;
			return;
		}
		let a = this.keyAttempt ??= {
			vault: Q(r.id),
			operation: Y(16),
			transport: Ln.random()
		};
		if (!Z(a.vault, Q(r.id))) throw Error("TargetChanged");
		let o = $(await this.actor.derive_vault_key({
			vault: a.vault,
			operation: a.operation,
			transport: a.transport.publicKeyBytes()
		}));
		this.session.check(t);
		let s = await br(i, Q(r.public_key), {
			input: Q(o.input),
			public_key: Q(o.public_key),
			encrypted_key: Q(o.encrypted_key)
		}, a.transport, this.local);
		this.session.check(t);
		let c = await n();
		this.session.check(t);
		try {
			if (!("Active" in c.state) || !Z(Q(c.public_key), Q(r.public_key)) || !Br(i, this.context(c))) throw Error("TargetChanged");
		} catch {
			throw this.session.lock(), Error("TargetChanged");
		}
		this.session.bindRoot(s, i), this.pinnedPublicKey = Q(r.public_key), this.header = structuredClone(c), this.keyAttempt = void 0;
	}
	async refreshHeader() {
		this.checkLive();
		let e = this.session.capture();
		if (!this.header) throw Error("Locked");
		let t = await this.actor.get_vault_header(this.header.id);
		if (this.session.check(e), "Err" in t && ("NotFound" in t.Err || "Conflict" in t.Err)) throw this.session.lock(), Error("TargetChanged");
		let n = $(t);
		if (!("Active" in n.state)) throw this.session.lock(), Error("TargetChanged");
		let r;
		try {
			r = this.context(n);
		} catch {
			throw this.session.lock(), Error("TargetChanged");
		}
		if (this.session.requireContext(r), !this.pinnedPublicKey || !Z(this.pinnedPublicKey, Q(n.public_key))) throw this.session.lock(), Error("TargetChanged");
		return this.header = structuredClone(n), structuredClone(n);
	}
	async checkedContext() {
		let e = this.session.capture(), t = await this.refreshHeader();
		return this.session.check(e), this.session.requireContext(this.context(t));
	}
	async mutate(e, t = Y(16)) {
		this.checkLive();
		let n = structuredClone({
			action: e,
			operation: t
		}), r = this.request;
		if (r.kind !== "idle" && Vr(r.mutation) !== Vr(n)) throw Error("ResolvePendingMutation");
		if (r.kind === "sending") throw Error("MutationInProgress");
		let i = r.kind === "idle" ? n : r.mutation, a = this.session.capture(), o = {
			kind: "sending",
			mutation: i
		};
		this.request = o;
		try {
			let e = await this.actor.mutate(i);
			return this.session.check(a), this.request = { kind: "idle" }, $(e);
		} finally {
			this.request === o && (this.request = {
				kind: "ambiguous",
				mutation: i
			});
		}
	}
	async retryMutation() {
		if (this.request.kind === "idle") throw Error("NoPendingMutation");
		let { mutation: e } = this.request;
		return this.mutate(e.action, Q(e.operation));
	}
	get pendingSave() {
		return "job" in this.saveState ? this.saveState.job : void 0;
	}
	get hasPendingSave() {
		return !!this.pendingSave;
	}
	async save(e, t, n, r = () => {}) {
		if (this.saveState.kind !== "idle") throw Error("SavePending");
		if (this.request.kind !== "idle") throw Error("ResolvePendingMutation");
		let i = { kind: "preparing" };
		this.saveState = i;
		let a = this.session.addLockCleanup(() => t.fill(0));
		try {
			let r = this.session.capture(), i = await this.checkedContext();
			this.session.check(r);
			let a = n ? Q(n.revision.object) : Y(16), o = n?.revision.revision ?? 0n, s = await Fr(this.session.root, i, a, o + 1n, e, t);
			this.session.check(r);
			let c = {
				vault: Q(i.vault),
				object: a,
				expected_revision: o,
				operation: Y(16),
				plain_size: BigInt(t.length),
				manifest: s.manifest,
				chunk_hashes: s.hashes
			};
			this.saveState = {
				kind: "ready",
				job: {
					request: c,
					chunks: s.chunks,
					phase: -1,
					operation: Y(16),
					ticket: r
				}
			};
		} finally {
			a(), this.saveState === i && (this.saveState = { kind: "idle" });
		}
		return this.resumeSave(r);
	}
	async resumeSave(e = () => {}) {
		let t = this.pendingSave;
		if (!t) throw Error("NoPendingSave");
		if (this.saveState.kind !== "ready") throw Error("SaveInProgress");
		let n = {
			kind: "sending",
			job: t
		};
		this.saveState = n;
		try {
			for (await this.checkedContext(), this.session.check(t.ticket); t.phase <= t.chunks.length;) {
				let n = t.phase === -1 ? { BeginRevision: t.request } : t.phase < t.chunks.length ? { PutChunk: {
					upload: t.request.operation,
					index: t.phase,
					bytes: t.chunks[t.phase]
				} } : { CommitRevision: { upload: t.request.operation } }, r = await this.mutate(n, t.operation);
				if (this.session.check(t.ticket), t.phase === -1 && !("Upload" in r) || t.phase >= 0 && t.phase < t.chunks.length && !("Done" in r) || t.phase === t.chunks.length && !("Revision" in r) || "Upload" in r && !Z(Q(r.Upload.id), Q(t.request.operation))) throw Error("InvalidReceipt");
				if ("Revision" in r) {
					if (!Z(Q(r.Revision.vault), Q(t.request.vault)) || !Z(Q(r.Revision.object), Q(t.request.object)) || r.Revision.revision !== t.request.expected_revision + 1n) throw Error("InvalidReceipt");
					t.revision = r.Revision;
				}
				t.phase++, t.operation = Y(16), e(Math.round(Math.min(t.chunks.length, Math.max(0, t.phase)) / t.chunks.length * 100));
			}
			let n = t.revision;
			if (!n) throw Error("InvalidReceipt");
			return this.saveState = { kind: "idle" }, n;
		} finally {
			this.saveState === n && (this.saveState = {
				kind: "ready",
				job: t
			});
		}
	}
	async items() {
		let e = this.session.capture(), t = await this.checkedContext();
		this.session.check(e);
		let n = [], r = /* @__PURE__ */ new Uint8Array();
		do {
			let i = $(await this.actor.list_objects(t.vault, r));
			this.session.check(e);
			for (let r of i.entries) {
				let i = r;
				if (r.deleted) {
					let t = $(await this.actor.list_history(r.vault, r.object, 18446744073709551615n));
					this.session.check(e);
					let a = t.entries.find((e) => !e.deleted);
					if (!a) {
						n.push({
							revision: r,
							metadata: {
								kind: "note",
								title: "Deleted document"
							}
						});
						continue;
					}
					i = a;
				}
				let a = await Ir(this.session.root, t, Q(i.object), i.revision, Q(i.manifest));
				this.session.check(e);
				let o = a.metadata.title;
				if (a.metadata.kind === "note" && !r.deleted) {
					let t = await this.read(r);
					try {
						this.session.check(e), o += " " + new TextDecoder().decode(t.plaintext);
					} finally {
						t.plaintext.fill(0);
					}
				}
				n.push({
					revision: r,
					metadata: a.metadata,
					searchText: o
				});
			}
			r = i.next[0] ? Q(i.next[0]) : /* @__PURE__ */ new Uint8Array();
		} while (r.length);
		return n;
	}
	async read(e) {
		let t = this.session.capture(), n = await this.checkedContext();
		if (this.session.check(t), !Z(n.vault, Q(e.vault))) throw Error("TargetChanged");
		let r = [];
		for (let n = 0; n < e.chunk_hashes.length; n++) r.push(Q($(await this.actor.get_chunk(e.vault, e.object, e.revision, n)))), this.session.check(t);
		let i = await Lr(this.session.root, n, Q(e.object), e.revision, Q(e.manifest), r, e.chunk_hashes.map(Q));
		try {
			return this.session.check(t), i;
		} catch (e) {
			throw i.plaintext.fill(0), e;
		}
	}
	async deleteObject(e) {
		if (this.saveState.kind !== "idle") throw Error("SavePending");
		let t = this.session.capture(), n = await this.checkedContext();
		if (this.session.check(t), !Z(n.vault, Q(e.vault))) throw Error("TargetChanged");
		return this.mutate({ DeleteObject: {
			vault: e.vault,
			object: e.object,
			expected_revision: e.revision
		} });
	}
	async purgeObject(e) {
		if (this.saveState.kind !== "idle") throw Error("SavePending");
		let t = this.session.capture(), n = await this.checkedContext();
		if (this.session.check(t), !Z(n.vault, Q(e.vault))) throw Error("TargetChanged");
		return this.mutate({ PurgeObject: {
			vault: e.vault,
			object: e.object,
			expected_revision: e.revision
		} });
	}
	async history(e, t = 18446744073709551615n) {
		let n = this.session.capture(), r = await this.checkedContext();
		if (this.session.check(n), !Z(r.vault, Q(e.vault))) throw Error("TargetChanged");
		let i = $(await this.actor.list_history(e.vault, e.object, t));
		return this.session.check(n), i;
	}
	async quota() {
		let e = this.session.capture(), t = await this.checkedContext();
		this.session.check(e);
		let n = $(await this.actor.get_quota(t.vault));
		return this.session.check(e), n;
	}
	async pendingUploads(e = /* @__PURE__ */ new Uint8Array()) {
		this.checkLive();
		let t = this.session.capture(), n = $(await this.actor.list_pending_uploads(e));
		return this.session.check(t), n;
	}
	async uploadStatus(e) {
		this.checkLive();
		let t = this.session.capture(), n = $(await this.actor.get_upload_status(e));
		return this.session.check(t), n;
	}
	async cancelSave() {
		let e = this.pendingSave;
		if (!e) throw Error("NoPendingSave");
		if (this.saveState.kind !== "ready") throw Error("SaveInProgress");
		let t = {
			kind: "cancelling",
			job: e
		};
		this.saveState = t;
		let n = this.cleanupState;
		try {
			let r = this.session.capture();
			this.request.kind !== "idle" && (await this.retryMutation(), this.session.check(r));
			let i = await this.uploadStatus(Q(e.request.operation));
			if (this.session.check(r), "Pending" in i) {
				if (!Z(Q(i.Pending.request.vault), Q(e.request.vault))) throw Error("TargetChanged");
				await this.cancelUpload(Q(e.request.vault), Q(e.request.operation), i.Pending.cancel_job[0] ? Q(i.Pending.cancel_job[0]) : void 0);
			}
			return this.session.check(r), e.chunks.forEach((e) => e.fill(0)), this.saveState === t && (this.saveState = { kind: "idle" }), this.cleanupState === n && n.kind === "cancel" && Z(n.vault, Q(e.request.vault)) && Z(n.upload, Q(e.request.operation)) && (this.cleanupState = { kind: "idle" }), i;
		} finally {
			this.saveState === t && (this.saveState = {
				kind: "ready",
				job: e
			});
		}
	}
	async cancelUpload(e, t, n) {
		this.checkLive(), this.cleanupState.kind === "idle" && (this.cleanupState = {
			kind: "cancel",
			vault: Q(e),
			upload: Q(t),
			job: n ? Q(n) : Y(16),
			operation: Y(16)
		});
		let r = this.cleanupState;
		if (r.kind !== "cancel" || !Z(r.vault, e) || !Z(r.upload, t) || n && !Z(r.job, n)) throw Error("ResolvePendingMutation");
		try {
			await this.cleanup(r);
		} catch (e) {
			throw this.request.kind === "idle" && this.cleanupState === r && (this.cleanupState = { kind: "idle" }), e;
		}
	}
	async deleteVault(e) {
		this.checkLive();
		let t = this.session.capture();
		this.cleanupState.kind === "idle" && (this.cleanupState = {
			kind: "delete",
			vault: Q(e),
			operation: Y(16)
		});
		let n = this.cleanupState;
		if (n.kind !== "delete" || !Z(n.vault, e)) throw Error("ResolvePendingMutation");
		try {
			await this.cleanup(n);
		} catch (e) {
			throw this.request.kind === "idle" && this.cleanupState === n && (this.cleanupState = { kind: "idle" }), e;
		}
		this.session.check(t), this.header && Z(Q(this.header.id), e) && (this.session.lock(), this.header = void 0);
	}
	async cleanup(e) {
		let t = this.session.capture();
		for (;;) {
			let n = e.kind === "cancel" ? { CancelUpload: {
				vault: e.vault,
				upload: e.upload,
				job: e.job
			} } : { DeleteVault: { vault: e.vault } }, r = await this.mutate(n, e.operation);
			if (this.session.check(t), !("Progress" in r)) throw Error("InvalidReceipt");
			if (r.Progress) {
				this.cleanupState = { kind: "idle" };
				return;
			}
			e.operation = Y(16);
		}
	}
	async collect() {
		try {
			return await this.mutate({ Collect: null }, this.request.kind !== "idle" && "Collect" in this.request.mutation.action ? Q(this.request.mutation.operation) : void 0);
		} catch (e) {
			if (e instanceof Error && e.message === "NotFound") return;
			throw e;
		}
	}
};
function Br(e, t) {
	return e.canister === t.canister && e.owner === t.owner && e.key_name === t.key_name && Z(e.vault, t.vault) && Z(e.nonce, t.nonce);
}
function Vr(e) {
	return JSON.stringify(e, (e, t) => typeof t == "bigint" ? `${t}n` : t instanceof Uint8Array ? X(t) : t);
}
export { zr as VaultClient, Q as bytes, xr as cryptoLib, Ar as documents, $ as ok };
